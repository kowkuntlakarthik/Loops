﻿using System;
namespace Variables
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Console.WriteLine("Variable");
            Console.WriteLine("Varibales are containers for storing data values");
            Console.WriteLine("There are different type of variables to store values");
            Console.WriteLine();
            //Integer values
            Console.WriteLine("Integer value");
            Console.WriteLine("int is used to store integer values i.e., Whole numbers in +ve & -ve values");
            Console.WriteLine("Ex: -1 & +1");
            Console.WriteLine();
            //Decimal values
            Console.WriteLine("Double value");
            Console.WriteLine("Double is used to store decimal numbers, at the end of the value need to mention D, if we use Double variable");
            Console.WriteLine("Ex: -1.4586D");
            Console.WriteLine();
            //Characeter values
            Console.WriteLine("Char value");
            Console.WriteLine("stores a single character with single quotation around that character");
            Console.WriteLine("Ex: 'a' , 'b', 'c' ");
            Console.WriteLine();
            //String value
            Console.WriteLine("String value");
            Console.WriteLine("stores in the form of a text surrounded with double quotation");
            Console.WriteLine("");
            //Boolean values
            Console.WriteLine("Boolean values");
            Console.WriteLine("Stores values in two states i.e., true or false");
            Console.WriteLine();
            //syntax
            Console.WriteLine("Syntax to declare a variable and value");
            Console.WriteLine("type variablename = value");
            Console.WriteLine(); */
            Console.WriteLine("declaring variables with values");
            //integer value
            /*Console.WriteLine("Integer value");
            int intval = 8;
            Console.WriteLine(intval);
            //another method to declare a variable
            int intvalue;
            intvalue = 16;
            Console.WriteLine(intvalue);
            Console.WriteLine();*/
            //Double value
            /*Console.WriteLine("Double value");
            double vald = 1.5678D;
            Console.WriteLine(vald);
            //another method to declare double value
            double valued;
            valued = 8.8968D;
            Console.WriteLine(valued); */
            //char value
            /*Console.WriteLine("Character value");
            char c = 'a';
            Console.WriteLine(c);
            //another menthod to declare a char value
            char b;
            b = 'B';
            Console.WriteLine(b); */
            //String value
            /*Console.WriteLine("declaring a String value");
            string name = "learn";
            Console.WriteLine(name);
            //another method to declare a string value
            string names;
            names = "c sharp";
            Console.WriteLine(names); */
            //Boolean value
            /*Console.WriteLine("Boolean values");
            bool boolv = true;
            Console.WriteLine(boolv);
            //another menthod to declare a boolean value
            bool boolvalue;
            boolvalue = false;
            Console.WriteLine(boolvalue);*/
            //float values
            /* Console.WriteLine("Float values");
            float floatv = 0.1234f;
            Console.WriteLine(floatv);
            //another method to declare a float value
            float floatvalue;
            floatvalue = 2.6898f;
            Console.WriteLine(floatvalue); */
            //long values
            /*Console.WriteLine("Long values");
            long longv = 987654321098765432;
            longv = 9876543210;
            Console.WriteLine(longv);*/
            //Constant variable
            //Console.WriteLine("Constant variable");
            /*Console.WriteLine("Long values");
            const long longv = 987654321098765432;
            //longv = 9876543210;
            Console.WriteLine(longv);
            const string name = "abcdefgh";
            //name = akmksmmksam;
            Console.WriteLine(name); */

            /*Console.WriteLine("Display variables");
            string name_1 = "Karthik";
            Console.WriteLine("Kowkuntla " + name_1);
            //another method to declare a display variable
            string firstname = "Karthik ";
            string lastname = "Kowkuntla";
            string fullname = firstname + lastname;
            Console.WriteLine(fullname); */

            Console.WriteLine("Multiple Variables");
            int x = 10, y = 15, z = 20;
            Console.WriteLine(x + y + z); 

            int a, b, c, d;
            a = b = c = 20;
            d = a + b + c;
            Console.WriteLine(d);








        }

    }
}