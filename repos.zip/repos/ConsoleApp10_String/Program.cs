﻿using System;
namespace stringmethod
{
    class stringmethod
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Strings");
            /*Console.WriteLine("Find the length of given text");
            Console.Write("Enter any text to find length: ");
            string text = Console.ReadLine();
            Console.WriteLine("The lenght of a string: " + text.Length);
            Console.WriteLine("\nChange text to upper case letters");
            Console.WriteLine("Text in upper case letters: " + text.ToUpper());
            Console.WriteLine("Text in Lower case letters: " + text.ToLower()); */

            /*Console.WriteLine("String Concatnation");
            Console.Write("Enter First name: ");
            String name1 = Console.ReadLine();
            Console.Write("Enter Last name: ");
            string name2 = Console.ReadLine();
            //string name3 = string.Concat(name1, name2);
            Console.WriteLine("Full Name: " + string.Concat(name1, name2));

            Console.WriteLine("with numbers");
            Console.Write("Enter value: ");
            string n1 = Console.ReadLine();
            Console.Write("Enter value: ");
            string n2 = Console.ReadLine();
            Console.WriteLine("Value: "+ string.Concat(n1, n2)); */

            /*Console.WriteLine();
            Console.WriteLine("String Interpolation");
            Console.Write("Enter users first name: ");
            string name1 = Console.ReadLine();
            Console.Write("Enter user last name: ");
            string name2 = Console.ReadLine();
            //string name3 = $"User full name: {name1} {name2}";
            //Console.WriteLine("String interpolation: " + name3);
            Console.WriteLine("String Interpolation: " + $"User full name: {name1} {name2}"); */

            /*Console.WriteLine("Access String");
            string name = "Hello csharp";
            Console.WriteLine(name[0]);
            Console.WriteLine("index number of the given letter: ");
            Console.WriteLine(name.IndexOf("p")); */

            //finding the index number and letter by using input
            Console.WriteLine("Finding index number and position");
            Console.WriteLine("\nIndex Letter");
            Console.Write("Enter Name: ");
            string sname = Console.ReadLine();
            Console.Write("Enter index number to find it's letter: ");
            int posn = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Index number: " + sname[posn]);

            Console.WriteLine("\nIndex Number");
            Console.Write("Enter Letter: ");
            int snameletter = sname.IndexOf(Console.ReadLine());
            Console.WriteLine("Letter: " + snameletter);


        }
    }
}

