﻿using System;
using System.Reflection.Metadata;
namespace strings
{
    class Strings
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Index number");
            Console.Write("Enter name: ");
            string name = Console.ReadLine();
            Console.Write("Enter pos number: ");
            int pos = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Index number: " + name[pos]);

            Console.WriteLine("Index letter");
            Console.Write("Letter: ");
            int cnum = name.IndexOf(Console.ReadLine());
            Console.WriteLine("index letter: " + cnum);




        }
    }
}