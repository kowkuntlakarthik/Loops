﻿using System;
namespace stringmethod
{
    class stringmethod
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Strings");
            //finding the index number and letter by using input
            Console.WriteLine("Finding index number and position");
            Console.WriteLine("\nIndex Letter");
            Console.Write("Enter Name: ");
            string sname = Console.ReadLine();
            Console.Write("Enter index number to find it's letter: ");
            int posn = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Index number: " + sname[posn]);

            Console.WriteLine("\nIndex Number");
            Console.Write("Enter Letter: ");
            int snameletter = sname.IndexOf(Console.ReadLine());
            Console.WriteLine("Letter: " + snameletter);


        }
    }
}