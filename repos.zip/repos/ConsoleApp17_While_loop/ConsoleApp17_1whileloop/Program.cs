﻿using System;
namespace whileloop
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Console.WriteLine("While Loop");
            int a = 1;
            while (a < 10)
            {
                Console.WriteLine(a);
                a++;
            }*/
            Console.WriteLine("While Loop");
            Console.Write("\nEnter number: ");
            int i = int.Parse(Console.ReadLine());
            Console.Write("Enter limit number: ");
            int j = int.Parse(Console.ReadLine());
            while(i <= j)
            {
                Console.WriteLine(i);
                i++;
            }
        }
    }
}