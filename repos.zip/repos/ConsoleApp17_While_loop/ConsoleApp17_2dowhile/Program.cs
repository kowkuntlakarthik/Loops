﻿/*using System;
namespace dowhileloop
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Do While Loop");
            Console.Write("\nEnter Number: ");
            int i = Convert.ToInt16(Console.ReadLine());
            Console.Write("\nEnter Limit: ");
            int j = int.Parse(Console.ReadLine());
            do
            {
                
                Console.WriteLine(i);
                i++;
            }
            while (i <= j);
            
        }
    }
}*/
using System;
namespace dowhileloop
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Do While Loop");
            Console.Write("Enter integer: ");
            double i = double.Parse(Console.ReadLine());
            Console.Write("Enter limit: ");
            double j = double.Parse(Console.ReadLine());
            do
            {
                Console.WriteLine(i);
                i++;
            }
            while (i <= j);
        }
    }
}