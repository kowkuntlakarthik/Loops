﻿using System;
namespace named_arguments
{
    class Program
    {
        /*static void Name_arg(string child1, string child2, string child3)
        {
            Console.WriteLine("The youngest child: " + child2);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Named Arguments");
            Name_arg("ofndsn", "snonnnmksd", "asnnoasms");
        }*/
        static void Named_a()
        {
            Console.Write("Enter First name: ");
            string fname = Console.ReadLine();
            Console.Write("Enter Middle name: ");
            string mname = Console.ReadLine();
            Console.Write("Enter last name: ");
            string lname = Console.ReadLine();
            string tname = fname + " " + mname + " " + lname;
            Console.WriteLine("Full Name: " + tname);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Named Arguments");
            Named_a();
            Named_a();
            Named_a();

        }
    }
}