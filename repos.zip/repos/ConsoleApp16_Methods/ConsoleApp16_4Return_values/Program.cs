﻿using System;
namespace rvalue
{
    class Program
    {
        /*static int rvalue(int x , int y)
        {
            return x + y;
        }
        static void Main(string[] args)
        {
            
            Console.Write("Value: " + rvalue(5, 3));
        }*/
        /*static double rvalue1(double a, double b)
        {
            return a + b;
        }
        static void Main(string[] args)
        {
            double c = rvalue1(5.15, 2.34);
            
            Console.WriteLine("value of c: " + c);
        }*/
        static int returnint()
        {
            Console.Write("Enter value of x: ");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter value of y: ");
            int y = Convert.ToInt32(Console.ReadLine());
            return x + y;
        }
        static double returndouble()
        {
            Console.Write("Enter value of a: ");
            double a = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value of b: ");
            double b = Convert.ToDouble(Console.ReadLine());
            return a + b;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Return value method");
            Console.WriteLine("Value: " + returnint());
            double c = returndouble();
            Console.WriteLine("Value of a & b: " + c.ToString("00.000"));
        }

    }
}