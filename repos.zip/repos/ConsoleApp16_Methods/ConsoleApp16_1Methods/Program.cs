﻿using System;
namespace Mymethods
{
    class methodfunction
    {
        static void Mymethods0()
        {
            Console.WriteLine("A method is a block of code which only executes when it is called");
        }
        static void Mymethods1()
        {
            Console.WriteLine("\nyou can pass the data, known as parameters in to a method");
        }
        static void Mymethods2()
        {
            Console.WriteLine("\nMethods are use to perform certain operation and they are also known as functions");
        }
        static void Mymethods3()
        {
            Console.WriteLine("\nA Method can be called muntiple times");
        }
        static void Mymethods4()
        {
            Console.WriteLine("\nMymethods() is the name of the method");
        }
        static void Mymethods5()
        {
            Console.WriteLine("\nstatic means that the method belongs to the program class and not an object to the program class");
        }
        static void Mymethods6()
        {
            Console.WriteLine("\nvoid means that the method function does not any return value");
        }
        static void Main()
        {
            Console.WriteLine("C# Methods");
            Mymethods0();
            Mymethods1();
            Mymethods2();
            Mymethods3();
            Mymethods4();
            Mymethods5();
            Mymethods6();
        }

    }
}