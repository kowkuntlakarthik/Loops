﻿using System;
using System.Security.Cryptography.X509Certificates;
namespace Parameter
{
    class MethodParameter
    {
        /*static void parameter1()
        {
            Console.Write("Enter name: ");
            string fname = Console.ReadLine();
            Console.Write("\nEnter age: ");
            int age = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Student name: " + fname + " Student age: " + age);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Mathods Parameter");
            parameter1();

        } */
        static void parameter(string sname, int age)
        {
            Console.WriteLine(sname + " age is " + age);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Method Parameter");
            parameter("A", 1);
            parameter("B", 2);
            parameter("C", 3);
            parameter("D", 4);
        }
    }
}