﻿using System;
namespace Dparameter
{
    class parameters_methods
    {
       
        static void Dparameter()
        {
            Console.Write("Enter State name: ");
            string state = Console.ReadLine();
            //Console.WriteLine("Country name: " + country);
       /* }
        static void state()
        {*/
            Console.Write("Enter Distric name: ");
            string distric = Console.ReadLine();
            Console.WriteLine("\nState & Distric name: " + state + " , " + distric);
        }
        static void Main(string[] args)
        {
           
            Console.WriteLine("State & distric names");
            Dparameter();

        }
        
    }
}