﻿using System;
namespace application
{
    class Program
    {
        static void Main(String[] args)
        {
            Console.WriteLine("Student details");
            Console.Write("\nEnter Student name: ");
            string sname = Console.ReadLine();
            Console.Write("Enter class: ");
            string sclass = Console.ReadLine();
            Console.Write("Enter Section: ");
            string ssection = Console.ReadLine();
            Console.Write("Enter roll number: ");
            string sroll = Console.ReadLine();
            Console.Write("Enter summative exam: ");
            string sexam = Console.ReadLine();
            Console.WriteLine("\nSecured marks in exam");
            Console.Write("Marks in Telugu: ");
            double telugu = Convert.ToDouble(Console.ReadLine());
            Console.Write("Marks in Hindi: ");
            double hindi = Convert.ToDouble(Console.ReadLine());
            Console.Write("Marks in English: ");
            double english = Convert.ToDouble(Console.ReadLine());
            Console.Write("Marks in Maths: ");
            double maths = Convert.ToDouble(Console.ReadLine());
            Console.Write("Marks in science: ");
            double science = Convert.ToDouble(Console.ReadLine());
            Console.Write("Marks in Social: ");
            double social = Convert.ToDouble(Console.ReadLine());
            double obtainedm = telugu + hindi + english + maths + science + social;
            Console.WriteLine(sname + " obtained marks in exam: " + obtainedm);
            const int totalm = 600;
            Console.WriteLine("Total marks: " + totalm);
            Console.WriteLine("Percentage calculation");
            double percent = ((double)obtainedm / totalm) * 100;
            Console.WriteLine("Percentage secured: " + percent.ToString("00.00") + "%");
            Console.WriteLine("Rank");
            if (percent > 85)
            {
                Console.WriteLine(sname + " Secured Distinct with " + percent.ToString("00.00") + "%");
            }
            else if (percent > 75 && percent < 85)
            {
                Console.WriteLine(sname + " Secured First class with " + percent.ToString("00.00") + "%");
            }
            else if(percent > 60 && percent < 75)
            {
                Console.WriteLine(sname + " Secured Second class with " + percent.ToString("00.00") + "%");
            }
            else if(percent > 45 && percent < 60)
            {
                Console.WriteLine(sname + " secured Third class with " + percent.ToString("00.00") + "%");
            }
            else if(percent >30 && percent < 45)
            {
                Console.WriteLine(sname + " secured Fourth class with " + percent.ToString("00.00") + "%");
            }
            else
            {
                Console.WriteLine(sname + " Secured percentage " + percent.ToString("00.00") + "%" + " appear for next year board exams");
            }


        }
    }
}