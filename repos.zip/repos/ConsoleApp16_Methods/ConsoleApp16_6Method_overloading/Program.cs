﻿using System;
namespace overloading
{
    class Program
    {
        static int Moverload(int x, int y)
        {
            return x + y;
        }
        static double Moverload(double x, double y)
        {
            return x - y;
        }
        static void Main(string[] args)
        {
            int mynum = Moverload(5, 3);//"0"
            double mynum1 = Moverload(1.3, 1.1);
            Console.WriteLine("int: " + mynum);
            Console.WriteLine("double: " + mynum1.ToString());  //with out tostring, value 0.01999999999
        }
    }
}
/*using System;
namespace MethodOverloading
{
    class Program
    {
        static int OverloadM()
        {
            Console.Write("Enter value of x: ");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter value of y: ");
            int y = Convert.ToInt32(Console.ReadLine());
            return x + y;
        }
        static double OverLoadM()
        {
            Console.Write("Enter Value of x: ");
            double x = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value of y: ");
            double y = Convert.ToDouble(Console.ReadLine());
            return x - y;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Methods Overloading");
            int z = OverloadM();
            double z1 = OverloadM();  //doubt
            Console.WriteLine("int value: " + z);
            Console.WriteLine("Double Value: " + z1);   //doubt
        }
    }
}*/
