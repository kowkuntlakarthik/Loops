﻿using System;
using System.ComponentModel.Design;
using System.Reflection.Metadata;
using System.Transactions;
namespace Ifconditions
{
    class Ifconditions
    {
        static void Main(string[] args)
        {
            Console.WriteLine("If Conditional statements");
            Console.Write("Enter Value of a: ");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Value of b: ");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter value of c: ");
            int c = Convert.ToInt32(Console.ReadLine());
            /*Console.WriteLine("\nIF");
            if (a < b)
            {
                Console.WriteLine("A is less than B");
            }
            else if (a > b)
            {
                Console.WriteLine("A is greater than B");
            }
            else
            {
                Console.WriteLine("A and B values are equal");
            }*/
            Console.WriteLine("\nShort hand if else Ternary Operators");
            string shorthand = (a > b) ? "A value is greater than B" : "A value is smaller than B";//: "A and B values are same";
            Console.WriteLine("Result: " + shorthand);
            
        }
    }
}