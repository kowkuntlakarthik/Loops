﻿using System;
namespace Helloworld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("C#");
            Console.WriteLine("Output");
            Console.WriteLine("Printing values on to the screeen");
            Console.WriteLine("Giving space after output in the screen");
            Console.WriteLine("Next Print the text in the same line");
            Console.Write("Printing");
            Console.Write(" the text in the same line");
            Console.WriteLine(" without entering the new line");
            Console.WriteLine("Next line entering");
            Console.WriteLine("Doing Math operations");
            Console.WriteLine(3 + 3);
            Console.WriteLine(3 - 3);
            Console.WriteLine(3 / 3);
            Console.WriteLine(3 * 3);
            Console.WriteLine(3 % 3);

        }
    }
}