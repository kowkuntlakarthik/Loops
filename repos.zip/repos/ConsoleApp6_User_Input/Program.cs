﻿using System;

namespace userInput
{
    class UserInput
    {
        static void Main(string[] args)
        {
            Console.WriteLine("User Imput");
            Console.WriteLine("Reading values form the User");
            Console.WriteLine("Enter name of a User: ");
            String user1 = Console.ReadLine();
            Console.WriteLine("The name of the User: " + user1);
            //Enter details of the User
            Console.WriteLine("Enter age of user: ");
            int age = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("User Age : " + age);
            //Educational details
            Console.WriteLine("Enter educational detials of user: ");
            string edu_details = Console.ReadLine();
            Console.WriteLine("Educational details of user: " + edu_details);
            //Enter Marks
            Console.Write("Enter marks in Telugu: ");
            double Telugu = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter marks in Hindi: ");
            double Hindi = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter marks in English: ");
            double English = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter marks in Maths: ");
            double Maths = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter marks in Science: ");
            double Science = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter marks in Social: ");
            double Social = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("obtained marks in Telugu: " + Telugu);
            Console.WriteLine("obtained marks in Hindi: " + Hindi);
            Console.WriteLine("obtained marks in English: " + English);
            Console.WriteLine("obtained marks in Maths: " + Maths);
            Console.WriteLine("obtained marks in Science: " + Science);
            Console.WriteLine("obtained marks in Social: " + Social);
            double Total = Telugu + Hindi + English + Maths + Science + Social;
            Console.WriteLine("Total Marks: " + Total);
            //grade
            Console.WriteLine("Enter Grade: ");
            string grade1 = Console.ReadLine();
            //char grade = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("user Grade: " + grade1);
        }
    }
}