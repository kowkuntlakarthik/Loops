﻿using System;
namespace Exam_result
{
    class Exam_result
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Tenth Exam results");
            //Student details
            Console.Write("\nStudent name: ");
            string sname = Console.ReadLine();
            Console.Write("Class: ");
            string sclass = Console.ReadLine();
            Console.Write("Section: ");
            string ssection = Console.ReadLine();
            Console.Write("Roll number: ");
            string sroll = Console.ReadLine();
            Console.Write("Unit test number: ");
            string stest = Console.ReadLine();
            //Marks
            Console.WriteLine("\nMarks Obtaines");
            Console.Write("Marks in Telugu: ");
            double telugu = Convert.ToDouble(Console.ReadLine());
            Console.Write("Marks in Hindi: ");
            double hindi = Convert.ToDouble(Console.ReadLine());
            Console.Write("Marks in English: ");
            double english = Convert.ToDouble(Console.ReadLine());
            Console.Write("Marks in Maths: ");
            double maths = Convert.ToDouble(Console.ReadLine());
            Console.Write("Marks in science: ");
            double science = Convert.ToDouble(Console.ReadLine());
            Console.Write("Marks in Social: ");
            double social = Convert.ToDouble(Console.ReadLine());
            
            double mobtained = telugu + hindi + english + maths + science + social;
            Console.WriteLine("Obtained marks: " + mobtained);
            const double mtotal = 600;
            Console.WriteLine("\nTotal marks:  " + mtotal);
            //Percentage
            double percent = ((double)mobtained / mtotal) * 100;
            Console.WriteLine("\nSecured percentage: " + percent.ToString("00.00") + "%");
            //student grade
            if (percent > 75)
            {
                Console.WriteLine(sname + " in " + sclass + " class exam" + stest + " secured DISTINCTION");
            }
            else if (percent > 60 && percent < 75)
            {
                Console.WriteLine(sname + " in " + sclass + " class exam " + stest + " secured FIRST CLASS");
            }
            else if (percent > 50 && percent < 60)
            {
                Console.WriteLine(sname + " in " + sclass + " class exam " + stest + " secured SECOND CLASS");
            }
            else if (percent > 35 && percent < 50)
            {
                Console.WriteLine(sname + " in " + sclass + " class exam " + stest + " secured THIRD CLASS");
            }
            else if (percent > 20 && percent < 35)
            {
                Console.WriteLine(sname + " in " + sclass + " class exam " + stest + " secured FOURTH CLASS");
            }
            else
            {
                Console.WriteLine(sname + " in " + sclass + " class exam " +  stest + " did not secured qualification marks. Study well and appear for next exam");
            }
                

        }
    }
}