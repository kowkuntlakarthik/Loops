﻿using System;
namespace Typecasting
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Type Casting");
            /*Console.WriteLine("Implicit Casting");
            int myint = 8;
            double mydouble = myint;
            Console.WriteLine(myint);
            Console.WriteLine(mydouble); */

            /*Console.WriteLine("Explicit castying");
            double mydouble = 8.4568d;
            int myint = (int)mydouble;
            Console.WriteLine(myint);
            Console.WriteLine(mydouble);*/

            int myint = 8;
            double mydouble = 8.4678;
            char mychar = 'a';
            bool mybool = true;
            string mystring = "name";
            /*Console.WriteLine(myint);
            Console.WriteLine(mydouble);
            Console.WriteLine(mychar);
            Console.WriteLine(mybool);*/
            Console.WriteLine(Convert.ToInt16(mydouble));
            Console.WriteLine(Convert.ToString(mychar));
            Console.WriteLine(Convert.ToDouble(myint));
            
        }
    }
}