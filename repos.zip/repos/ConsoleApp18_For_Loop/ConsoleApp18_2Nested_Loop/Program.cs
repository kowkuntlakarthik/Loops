﻿using System;
namespace nestedloop
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Nested Loops");
            for (int i = 0; i <= 2; ++i)
            {
                Console.WriteLine("\nOuter loop: " + i);
                for (int j = 0; j <= 3; j++)
                {
                    Console.WriteLine(" Inner loop: " + j);
                }
            }
        }
    }
}