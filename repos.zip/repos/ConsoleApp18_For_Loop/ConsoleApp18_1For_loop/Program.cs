﻿/*using System;
namespace ForLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("For Loop");
            for (int i = 0; i <= 10; ++i)
            {
                Console.WriteLine(i);
            }
        }
    }
}*/
/*using System;
namespace forloop
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("For Loops");
            for (double d = 1; d <= 100; d = d + 2)
            {
                Console.WriteLine(d);
            }
        }
    }
}*/
using System;
namespace Forloop
{
    class Program
    {
        static void forloop()
        {
            Console.WriteLine("Loops in Methods");
            for (int i = 0; i <= 10; i++)
            {
                Console.WriteLine(i);
            }
        }
        static void forloop1()
        {
            Console.WriteLine("printing Odd numbers");
            for (int i = 1; i <= 100; i = i + 2)
            {
                Console.WriteLine(i);
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("For Loops");
            forloop();
            Console.WriteLine("Odd Numbers");
            forloop1();
        }
    }
}