﻿using System;
namespace Booleanoperaions
{
    class Booleanoperations
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Boolean Operations");
            Console.Write("Enter value of a: ");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Value of b: ");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Boolean Operations");
            Console.WriteLine(a == b);
            Console.WriteLine(a != b);
            Console.WriteLine(a > b);
            Console.WriteLine(a < b);
            Console.WriteLine("\nIf");
            if (a > b)
            {
                Console.WriteLine("a is bigger");
            }
            else
            {
                Console.WriteLine("B is bigger");
            }

        }
    }
}