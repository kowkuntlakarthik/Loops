﻿using System;
namespace Comparison_operator
{
    class Comparison_operator
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Comparison Operator");
            Console.Write("Enter value of a: ");
            double a = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value of b: ");
            double b = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine(a == b);
            Console.WriteLine(a != b);
            Console.WriteLine(a > b);
            Console.WriteLine(a < b);
            Console.WriteLine(a >= b);
            Console.WriteLine(a <= b);
            Console.WriteLine("\nLogical Operator");
            Console.Write("Enter value of c: ");
            double c = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Value of d: ");
            double d = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine(a < b && c < d);
            Console.WriteLine(a > c || d < b);
            Console.WriteLine(!(a < b && c < d));

        }
    }
}
