﻿using System;
namespace Operators
{
    class Program
    {
        static void Main(String[] args)
        {
            Console.WriteLine("\nOperators");
            Console.Write("Enter Value a: ");
            Double a = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Value b: ");
            double b = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Arthimatic Operators");
            Console.WriteLine(a + b);
            double c = Convert.ToDouble(a - b);
            Console.WriteLine(c);
            Console.WriteLine(a * b);
            Console.WriteLine(a / b);
            Console.WriteLine(a % b);
            /*a++;
            b--;
            Console.WriteLine(a);
            Console.WriteLine(b); */
            Console.WriteLine("Assignment Operator");
            Console.WriteLine(a += 4);
            Console.WriteLine(b -= 2);
            Console.WriteLine(a *= 3);
            Console.WriteLine(a /= 2);
            Console.WriteLine(a %= 2);
            Console.Write("Enter value of d: ");
            int d = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(d &= 3);
            Console.WriteLine(d |= 2);
            Console.Write("Enter value of e: ");
            int e = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(e ^= 5);
            Console.WriteLine(e >>= 5);
            Console.WriteLine(e <<= 5);

        }
    }
}