﻿using System;
namespace substring
{
    class substring
    {
        static void Main(string[] args)
        {
            /*Console.WriteLine("Sub string");
            Console.Write("Enter name: ");
            string fname = Console.ReadLine();
            int cpos = fname.IndexOf("k");
            string lname = fname.Substring(cpos);
            Console.WriteLine("Last name: " + lname); */

            Console.Write("Enter Name: ");
            string sname1 = Console.ReadLine();
            Console.Write("Enter Letter: ");
            int sname2 = sname1.IndexOf(Console.ReadLine());
            string sname3 = sname1.Substring(sname2);
            Console.WriteLine("Enter last name: " + sname3);

        }
        
    }
}