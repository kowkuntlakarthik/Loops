﻿using System;
using System.Transactions;
namespace Math_Operations
{
    class Math_Operations
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Math Operations");
            Console.Write("Enter Value a: ");
            double a = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Value of b: ");
            double b = Convert.ToDouble(Console.ReadLine());
            Console.Write("Minimum number: ");
            Console.WriteLine(Math.Min(a, b));
            /*Console.WriteLine("Maximum number: ", Math.Max(a, b));
            Console.WriteLine("Absolute Number: ", Math.Abs(a));
            Console.WriteLine("Square root number: ", Math.Sqrt(b));
            Console.WriteLine("Number rounding off: ", Math.Round(a));*/
            Console.Write("Maximum Number: ");
            Console.WriteLine(Math.Max(a, b));
            Console.Write("Square root number: ");
            Console.WriteLine(Math.Sqrt(a));
            Console.Write("Enter Value of c: ");
            double c = Convert.ToDouble(Console.ReadLine());
            Console.Write("Absolute number: ");
            Console.WriteLine(Math.Abs(c));
            Console.Write("Round off number: ");
            Console.WriteLine(Math.Round(c));

        }
    }
}