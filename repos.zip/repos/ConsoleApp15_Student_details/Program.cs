﻿//Student exam results
using System;
namespace student
{
    class Student
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Student Exam results");
            Console.Write("Enter Student name: "); //Student name
            string sname = Console.ReadLine();
            Console.Write("Enter student class: "); //Class
            string sclass = Console.ReadLine();
            Console.Write("Enter Section: ");
            //char section = Convert.ToString(Console.ReadLine());  
            string section = Console.ReadLine();
            Console.Write("Enter Roll number: ");
            string sroll = Console.ReadLine(); //Roll number is Alphanumeric
            Console.Write("Enter summative exam number: ");
            string summative = Console.ReadLine();
            Console.WriteLine("Marks Obtained");
            Console.Write("Telugu Marks: ");
            double telugu = Convert.ToDouble(Console.ReadLine());
            Console.Write("Hindi Marks: ");
            double hindi = Convert.ToDouble(Console.ReadLine());
            Console.Write("English Marks: ");
            double english = Convert.ToDouble(Console.ReadLine());
            Console.Write("Maths Marks: ");
            double maths = Convert.ToDouble(Console.ReadLine());
            Console.Write("Science Marks: ");
            double science = Convert.ToDouble(Console.ReadLine());
            Console.Write("Social Marks: ");
            double social = Convert.ToDouble(Console.ReadLine());
            double obtainedm = telugu + hindi + english + maths + science + social;
            Console.WriteLine("\nObtained Marks: " + obtainedm);
            const double totalm = 600;
            Console.WriteLine("Total Marks: " + totalm);
            double percent = ((double)obtainedm / totalm) * 100;
            Console.WriteLine("Percentage: " + percent.ToString("00.00") + "%");
            Console.WriteLine();
            if (percent > 75)
            {
                Console.WriteLine(sname + " in " + summative + " summative exams secured Distinction");
            }
            else if(percent > 60)// || percent < 75)
            {
                Console.WriteLine(sname + " in " + summative + " summative exams secured First Class");
            }
            else if(percent > 45)// || percent < 60)
            {
                Console.WriteLine(sname + " in " + summative + " summative exams secured Second Class");
            }
            else if(percent > 25)// || percent < 45)
            {
                Console.WriteLine(sname + " in " + summative + " summative exams secured Third Class");
            }
            else if(percent >= 10)// || percent < 25)
            {
                Console.WriteLine(sname + " in " + summative + " summative exams secured Fourth Class");
            }
            else
            {
                Console.WriteLine(sname + " in " + summative + " summative exams did not qualified. Study well and reappear for next exam");
            }
            

        }
    }
}