﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;
using NXOpen.UF;
using NXOpenUI;
using NXOpen.Utilities;

namespace Block._500._600._800.wcs
{
    internal class Code
    {
        public static void CodeMethod()
        {

            NXOpen.Session theSession = NXOpen.Session.GetSession();
            NXOpen.Part workPart = theSession.Parts.Work;
            NXOpen.Part displayPart = theSession.Parts.Display;


            NXOpen.Features.Feature nullNXOpen_Features_Feature = null;
            NXOpen.Features.BlockFeatureBuilder blockFeatureBuilder1;
            blockFeatureBuilder1 = workPart.Features.CreateBlockFeatureBuilder(nullNXOpen_Features_Feature);



            NXOpen.Point3d originPoint1 = new NXOpen.Point3d(500, 600, 800);
            blockFeatureBuilder1.SetOriginAndLengths(originPoint1, "50", "80", "65");

            NXOpen.Features.Feature feature1;
            feature1 = blockFeatureBuilder1.CommitFeature();

            blockFeatureBuilder1.Destroy();
        }
    }
}