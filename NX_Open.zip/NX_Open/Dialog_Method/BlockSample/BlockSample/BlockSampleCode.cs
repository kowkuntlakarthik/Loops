﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;
using NXOpen.UF;
using NXOpenUI;
using NXOpen.Utilities;

namespace BlockSample
{
    public class BlockSampleCode
    {
        public static void Main(string[] args)
        {
            Code.CodeMethod(new Point3d(0, 0, 0), "100", "100", "100");
            Code.CodeMethod(new Point3d(100, 71.77, 778), "99", "77", "66");
            Code.CodeMethod(new Point3d(987, 630, 919), "55", "44", "22");
            Code.CodeMethod(new Point3d(379, 973, 90), "66", "33", "55");
            Code.CodeMethod(new Point3d(-150, -200, -75), "64.5", "150.8", "89.7");
        }

    }
}
