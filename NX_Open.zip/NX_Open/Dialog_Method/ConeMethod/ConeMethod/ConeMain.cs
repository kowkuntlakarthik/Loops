﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;
using NXOpenUI;
using NXOpen.UF;
using NXOpen.Utilities;

namespace ConeMethod
{
    public class ConeMain
    {
        public static void Main(string[] args)
        {
            ConeCode.ConeMethodCode(new Vector3d(-1, 0, 0), new Point3d(-50, -500, -100), 50, 30, 60);
            ConeCode.ConeMethodCode(new Vector3d(0, 1, 0), new Point3d(50, 100, 80), 100, 50, 60);
            ConeCode.ConeMethodCode(new Vector3d(0, 0, 1), new Point3d(100, -50, -800), 90, 20, 50);
            ConeCode.ConeMethodCode(new Vector3d(1, 0, 0), new Point3d(-150, 300, 75), 99.85678, 62.5, 70);
            ConeCode.ConeMethodCode(new Vector3d(0, -1, 0), new Point3d(510, -150, -180), 69.151, 5.1510, 60.5181);

        }
    }
}
