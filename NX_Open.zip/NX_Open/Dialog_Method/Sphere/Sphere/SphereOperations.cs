﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;
using NXOpenUI;
using NXOpen.UF;
using NXOpen.Utilities;

namespace Sphere
{
    internal class SphereOperations
    {
        public static Point3d originPoint;
        public static void Sphere(Point3d originPoint, double sphdia)
        {
            try
            {

                NXOpen.Session theSession = NXOpen.Session.GetSession();
                NXOpen.Part workPart = theSession.Parts.Work;
                NXOpen.Part displayPart = theSession.Parts.Display;

                NXOpen.Features.Sphere nullNXOpen_Features_Sphere = null;
                NXOpen.Features.SphereBuilder sphereBuilder1;
                sphereBuilder1 = workPart.Features.CreateSphereBuilder(nullNXOpen_Features_Sphere);

                NXOpen.Point coordinates = workPart.Points.CreatePoint(originPoint);

                sphereBuilder1.CenterPoint = coordinates;

                sphereBuilder1.Diameter.SetFormula(sphdia.ToString());

                NXOpen.NXObject nXObject1;
                nXObject1 = sphereBuilder1.Commit();

                sphereBuilder1.Destroy();
            }
            catch (Exception ex) 
            {
                UI.GetUI().NXMessageBox.Show("Error in Sphere creation.Please check values. ", NXMessageBox.DialogType.Error, ex.Message);

            }

        }
        public static int GetUnloadOption(string arg)
        {
            //return System.Convert.ToInt32(Session.LibraryUnloadOption.Explicitly);
            return System.Convert.ToInt32(Session.LibraryUnloadOption.Immediately);
            // return System.Convert.ToInt32(Session.LibraryUnloadOption.AtTermination);
        }

    }
}
