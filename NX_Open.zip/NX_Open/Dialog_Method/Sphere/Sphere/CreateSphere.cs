﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;
using NXOpenUI;
using NXOpen.UF;
using NXOpen.Utilities;

namespace Sphere
{
    public class CreateSphere
    {
        public static void Main(string[] args)
        {
            SphereOperations.Sphere(new Point3d(100, 100, 100), 100);
            SphereOperations.Sphere(new Point3d(50, 500, -100), 200);
            SphereOperations.Sphere(new Point3d(-100, -1000, -600), 62.261);
            SphereOperations.Sphere(new Point3d(84, -584.1848, 75.560), 84);
            SphereOperations.Sphere(new Point3d(-48, -20.489, 190), 28.29);
        }
    }
}
