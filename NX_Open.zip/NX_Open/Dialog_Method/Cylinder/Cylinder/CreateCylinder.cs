﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;
using NXOpenUI;
using NXOpen.UF;
using NXOpen.Utilities;

namespace Cylinder
{
    public class CreateCylinder
    {
        public static void Main(string[] args)
        {
            CylinderOperations.Cylindercreation(new Point3d(100, 100, 100), new Vector3d(0, 0, 1), 50, 100);
            CylinderOperations.Cylindercreation(new Point3d(50.1558, 90.158, -100), new Vector3d(1, 0, 0), 10, 500);
            CylinderOperations.Cylindercreation(new Point3d(-54.1848, 100.848, 24.5184), new Vector3d(0, 1, 0), 150, 10);
            CylinderOperations.Cylindercreation(new Point3d(288.58, -518.188, 184.18448), new Vector3d(-1, 0, 0), 25.188, 48.1848);
            CylinderOperations.Cylindercreation(new Point3d(0, 0, 0), new Vector3d(0, 0, -1), 285.118, 948.848);

        }
    }
}
