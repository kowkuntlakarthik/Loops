﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;
using NXOpenUI;
using NXOpen.Utilities;
using NXOpen.UF;

namespace ConeCreation
{
    internal class ConeJournalCode
    {
        public static void ConeCode()
        {
            NXOpen.Session theSession = NXOpen.Session.GetSession();
            NXOpen.Part workPart = theSession.Parts.Work;
            NXOpen.Part displayPart = theSession.Parts.Display;

            NXOpen.Features.Cone nullNXOpen_Features_Cone = null;
            NXOpen.Features.ConeBuilder coneBuilder1;
            coneBuilder1 = workPart.Features.CreateConeBuilder(nullNXOpen_Features_Cone);

            coneBuilder1.BaseDiameter.SetFormula("50");

            coneBuilder1.TopDiameter.SetFormula("20");

            coneBuilder1.Height.SetFormula("25");

            NXOpen.NXObject nXObject1;
            nXObject1 = coneBuilder1.Commit();

           coneBuilder1.Destroy();

            
        }
    }
}
