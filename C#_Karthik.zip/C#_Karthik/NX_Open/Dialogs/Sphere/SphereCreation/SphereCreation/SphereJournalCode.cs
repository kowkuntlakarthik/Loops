﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SphereCreation
{
    internal class SphereJournalCode
    {
        public static void SphereCode()
        {
            NXOpen.Session theSession = NXOpen.Session.GetSession();
            NXOpen.Part workPart = theSession.Parts.Work;
            NXOpen.Part displayPart = theSession.Parts.Display;
            // ----------------------------------------------
            //   Menu: Insert->Design Feature->Sphere...
            // ----------------------------------------------
            NXOpen.Session.UndoMarkId markId1;
            markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start");

            NXOpen.Features.Sphere nullNXOpen_Features_Sphere = null;
            NXOpen.Features.SphereBuilder sphereBuilder1;
            sphereBuilder1 = workPart.Features.CreateSphereBuilder(nullNXOpen_Features_Sphere);

            sphereBuilder1.Diameter.SetFormula("100");

            theSession.SetUndoMarkName(markId1, "Sphere Dialog");

            NXOpen.Unit unit1;
            unit1 = sphereBuilder1.Diameter.Units;

            NXOpen.Expression expression1;
            expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1);

            NXOpen.Session.UndoMarkId markId2;
            markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Sphere");

            theSession.DeleteUndoMark(markId2, null);

            NXOpen.Session.UndoMarkId markId3;
            markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Sphere");

            NXOpen.NXObject nXObject1;
            nXObject1 = sphereBuilder1.Commit();

            theSession.DeleteUndoMark(markId3, null);

            theSession.SetUndoMarkName(markId1, "Sphere");

            NXOpen.Expression expression2 = sphereBuilder1.Diameter;
            sphereBuilder1.Destroy();

            workPart.MeasureManager.SetPartTransientModification();

            workPart.Expressions.Delete(expression1);

            workPart.MeasureManager.ClearPartTransientModification();
        }
    }
}
