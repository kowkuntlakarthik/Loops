﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlockCreation
{
    internal class BlockJournalCode
    {
        public static void BlockCode()
        {
            NXOpen.Session theSession = NXOpen.Session.GetSession();
            NXOpen.Part workPart = theSession.Parts.Work;
            NXOpen.Part displayPart = theSession.Parts.Display;
            // ----------------------------------------------
            //   Menu: Insert->Design Feature->Block...
            // ----------------------------------------------
            NXOpen.Session.UndoMarkId markId1;
            markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start");

            NXOpen.Features.Feature nullNXOpen_Features_Feature = null;
            NXOpen.Features.BlockFeatureBuilder blockFeatureBuilder1;
            blockFeatureBuilder1 = workPart.Features.CreateBlockFeatureBuilder(nullNXOpen_Features_Feature);

            NXOpen.Body[] targetBodies1 = new NXOpen.Body[1];
            NXOpen.Body nullNXOpen_Body = null;
            targetBodies1[0] = nullNXOpen_Body;
            blockFeatureBuilder1.BooleanOption.SetTargetBodies(targetBodies1);

            blockFeatureBuilder1.BooleanOption.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create;

            NXOpen.Body[] targetBodies2 = new NXOpen.Body[1];
            targetBodies2[0] = nullNXOpen_Body;
            blockFeatureBuilder1.BooleanOption.SetTargetBodies(targetBodies2);

            blockFeatureBuilder1.BooleanOption.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create;

            theSession.SetUndoMarkName(markId1, "Block Dialog");

            NXOpen.Point3d coordinates1 = new NXOpen.Point3d(0.0, 0.0, 0.0);
            NXOpen.Point point1;
            point1 = workPart.Points.CreatePoint(coordinates1);

            blockFeatureBuilder1.OriginPoint = point1;

            NXOpen.Unit unit1 = ((NXOpen.Unit)workPart.UnitCollection.FindObject("MilliMeter"));
            NXOpen.Expression expression1;
            expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1);

            NXOpen.Session.UndoMarkId markId2;
            markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Block");

            theSession.DeleteUndoMark(markId2, null);

            NXOpen.Session.UndoMarkId markId3;
            markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Block");

            blockFeatureBuilder1.Type = NXOpen.Features.BlockFeatureBuilder.Types.OriginAndEdgeLengths;

            blockFeatureBuilder1.OriginPoint = point1;

            NXOpen.Point3d originPoint1 = new NXOpen.Point3d(0.0, 0.0, 0.0);
            blockFeatureBuilder1.SetOriginAndLengths(originPoint1, "100", "100", "100");

            blockFeatureBuilder1.SetBooleanOperationAndTarget(NXOpen.Features.Feature.BooleanType.Create, nullNXOpen_Body);

            NXOpen.Features.Feature feature1;
            feature1 = blockFeatureBuilder1.CommitFeature();

            theSession.DeleteUndoMark(markId3, null);

            theSession.SetUndoMarkName(markId1, "Block");

            blockFeatureBuilder1.Destroy();

            workPart.MeasureManager.SetPartTransientModification();

            workPart.Expressions.Delete(expression1);

            workPart.MeasureManager.ClearPartTransientModification();
        }
    }
}
