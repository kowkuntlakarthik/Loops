﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConeCreation
{
    internal class ConeJournalCode
    {
        public static void ConeCode()
        {
            NXOpen.Session theSession = NXOpen.Session.GetSession();
            NXOpen.Part workPart = theSession.Parts.Work;
            NXOpen.Part displayPart = theSession.Parts.Display;
            // ----------------------------------------------
            //   Menu: Insert->Design Feature->Cone...
            // ----------------------------------------------
            NXOpen.Session.UndoMarkId markId1;
            markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start");

            NXOpen.Features.Cone nullNXOpen_Features_Cone = null;
            NXOpen.Features.ConeBuilder coneBuilder1;
            coneBuilder1 = workPart.Features.CreateConeBuilder(nullNXOpen_Features_Cone);

            coneBuilder1.BaseDiameter.SetFormula("50");

            coneBuilder1.TopDiameter.SetFormula("0");

            coneBuilder1.Height.SetFormula("25");

            coneBuilder1.HalfAngle.SetFormula("45");

            theSession.SetUndoMarkName(markId1, "Cone Dialog");

            NXOpen.Unit unit1;
            unit1 = coneBuilder1.TopDiameter.Units;

            NXOpen.Expression expression1;
            expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1);

            NXOpen.Session.UndoMarkId markId2;
            markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Cone");

            theSession.DeleteUndoMark(markId2, null);

            NXOpen.Session.UndoMarkId markId3;
            markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Cone");

            NXOpen.NXObject nXObject1;
            nXObject1 = coneBuilder1.Commit();

            theSession.DeleteUndoMark(markId3, null);

            theSession.SetUndoMarkName(markId1, "Cone");

            NXOpen.Expression expression2 = coneBuilder1.TopDiameter;
            NXOpen.Expression expression3 = coneBuilder1.Height;
            NXOpen.Expression expression4 = coneBuilder1.HalfAngle;
            NXOpen.Expression expression5 = coneBuilder1.BaseDiameter;
            coneBuilder1.Destroy();

            workPart.MeasureManager.SetPartTransientModification();

            workPart.Expressions.Delete(expression1);

            workPart.MeasureManager.ClearPartTransientModification();
        }
    }
}
