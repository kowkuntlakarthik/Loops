﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CylinderCreation
{
    internal class CylinderJournalcode
    {
        public static void Cylindercode()
        {
            NXOpen.Session theSession = NXOpen.Session.GetSession();
            NXOpen.Part workPart = theSession.Parts.Work;
            NXOpen.Part displayPart = theSession.Parts.Display;
            // ----------------------------------------------
            //   Menu: Insert->Design Feature->Cylinder...
            // ----------------------------------------------
            NXOpen.Session.UndoMarkId markId1;
            markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start");

            NXOpen.Features.Feature nullNXOpen_Features_Feature = null;
            NXOpen.Features.CylinderBuilder cylinderBuilder1;
            cylinderBuilder1 = workPart.Features.CreateCylinderBuilder(nullNXOpen_Features_Feature);

            NXOpen.Body[] targetBodies1 = new NXOpen.Body[1];
            NXOpen.Body nullNXOpen_Body = null;
            targetBodies1[0] = nullNXOpen_Body;
            cylinderBuilder1.BooleanOption.SetTargetBodies(targetBodies1);

            cylinderBuilder1.BooleanOption.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create;

            cylinderBuilder1.Diameter.SetFormula("50");

            cylinderBuilder1.Height.SetFormula("100");

            theSession.SetUndoMarkName(markId1, "Cylinder Dialog");

            NXOpen.Unit unit1;
            unit1 = cylinderBuilder1.Height.Units;

            NXOpen.Expression expression1;
            expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1);

            NXOpen.Session.UndoMarkId markId2;
            markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Cylinder");

            theSession.DeleteUndoMark(markId2, null);

            NXOpen.Session.UndoMarkId markId3;
            markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Cylinder");

            NXOpen.NXObject nXObject1;
            nXObject1 = cylinderBuilder1.Commit();

            theSession.DeleteUndoMark(markId3, null);

            theSession.SetUndoMarkName(markId1, "Cylinder");

            NXOpen.Expression expression2 = cylinderBuilder1.Height;
            NXOpen.Expression expression3 = cylinderBuilder1.Diameter;
            cylinderBuilder1.Destroy();

            workPart.MeasureManager.SetPartTransientModification();

            workPart.Expressions.Delete(expression1);

            workPart.MeasureManager.ClearPartTransientModification();
        }
    }
}
