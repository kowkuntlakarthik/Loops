namespace WinFormsApp1_Calculator
{
    public partial class Calculator_design : Form
    {
        public Calculator_design()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }
    }
}
