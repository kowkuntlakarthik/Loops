﻿namespace WinFormsApp1_Calculator
{
    partial class Calculator_design
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            number_1 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            button21 = new Button();
            button22 = new Button();
            button23 = new Button();
            button24 = new Button();
            textBox1 = new TextBox();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(7, 233);
            button1.Name = "button1";
            button1.Size = new Size(71, 52);
            button1.TabIndex = 0;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(84, 233);
            button2.Name = "button2";
            button2.Size = new Size(71, 52);
            button2.TabIndex = 0;
            button2.Text = "button1";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(161, 233);
            button3.Name = "button3";
            button3.Size = new Size(71, 52);
            button3.TabIndex = 0;
            button3.Text = "button1";
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(7, 291);
            button4.Name = "button4";
            button4.Size = new Size(71, 52);
            button4.TabIndex = 0;
            button4.Text = "button1";
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Location = new Point(84, 291);
            button5.Name = "button5";
            button5.Size = new Size(71, 52);
            button5.TabIndex = 0;
            button5.Text = "button1";
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(161, 291);
            button6.Name = "button6";
            button6.Size = new Size(71, 52);
            button6.TabIndex = 0;
            button6.Text = "button1";
            button6.UseVisualStyleBackColor = true;
            // 
            // number_1
            // 
            number_1.Location = new Point(7, 349);
            number_1.Name = "number_1";
            number_1.Size = new Size(71, 52);
            number_1.TabIndex = 0;
            number_1.Text = "1";
            number_1.UseVisualStyleBackColor = true;
            number_1.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(84, 349);
            button8.Name = "button8";
            button8.Size = new Size(71, 52);
            button8.TabIndex = 0;
            button8.Text = "button1";
            button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Location = new Point(161, 349);
            button9.Name = "button9";
            button9.Size = new Size(71, 52);
            button9.TabIndex = 0;
            button9.Text = "button1";
            button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Location = new Point(7, 407);
            button10.Name = "button10";
            button10.Size = new Size(71, 52);
            button10.TabIndex = 0;
            button10.Text = "button1";
            button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            button11.Location = new Point(84, 407);
            button11.Name = "button11";
            button11.Size = new Size(71, 52);
            button11.TabIndex = 0;
            button11.Text = "button1";
            button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            button12.Location = new Point(161, 407);
            button12.Name = "button12";
            button12.Size = new Size(71, 52);
            button12.TabIndex = 0;
            button12.Text = "button1";
            button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            button13.Location = new Point(238, 233);
            button13.Name = "button13";
            button13.Size = new Size(71, 52);
            button13.TabIndex = 0;
            button13.Text = "button1";
            button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            button14.Location = new Point(238, 291);
            button14.Name = "button14";
            button14.Size = new Size(71, 52);
            button14.TabIndex = 0;
            button14.Text = "button1";
            button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            button15.Location = new Point(238, 349);
            button15.Name = "button15";
            button15.Size = new Size(71, 52);
            button15.TabIndex = 0;
            button15.Text = "button1";
            button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            button16.Location = new Point(238, 407);
            button16.Name = "button16";
            button16.Size = new Size(71, 52);
            button16.TabIndex = 0;
            button16.Text = "button1";
            button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            button17.Location = new Point(7, 117);
            button17.Name = "button17";
            button17.Size = new Size(71, 52);
            button17.TabIndex = 0;
            button17.Text = "button1";
            button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            button18.Location = new Point(84, 117);
            button18.Name = "button18";
            button18.Size = new Size(71, 52);
            button18.TabIndex = 0;
            button18.Text = "button1";
            button18.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            button19.Location = new Point(7, 175);
            button19.Name = "button19";
            button19.Size = new Size(71, 52);
            button19.TabIndex = 0;
            button19.Text = "button1";
            button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            button20.Location = new Point(161, 117);
            button20.Name = "button20";
            button20.Size = new Size(71, 52);
            button20.TabIndex = 0;
            button20.Text = "button1";
            button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            button21.Location = new Point(238, 117);
            button21.Name = "button21";
            button21.Size = new Size(71, 52);
            button21.TabIndex = 0;
            button21.Text = "button1";
            button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            button22.Location = new Point(84, 175);
            button22.Name = "button22";
            button22.Size = new Size(71, 52);
            button22.TabIndex = 0;
            button22.Text = "button1";
            button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            button23.Location = new Point(161, 175);
            button23.Name = "button23";
            button23.Size = new Size(71, 52);
            button23.TabIndex = 0;
            button23.Text = "button1";
            button23.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            button24.Location = new Point(238, 175);
            button24.Name = "button24";
            button24.Size = new Size(71, 52);
            button24.TabIndex = 0;
            button24.Text = "button1";
            button24.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(6, 11);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(299, 96);
            textBox1.TabIndex = 1;
            // 
            // Calculator_design
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(320, 463);
            Controls.Add(textBox1);
            Controls.Add(button16);
            Controls.Add(button12);
            Controls.Add(button15);
            Controls.Add(button11);
            Controls.Add(button9);
            Controls.Add(button24);
            Controls.Add(button14);
            Controls.Add(button23);
            Controls.Add(button8);
            Controls.Add(button6);
            Controls.Add(button22);
            Controls.Add(button10);
            Controls.Add(button21);
            Controls.Add(button5);
            Controls.Add(button13);
            Controls.Add(button20);
            Controls.Add(number_1);
            Controls.Add(button19);
            Controls.Add(button3);
            Controls.Add(button18);
            Controls.Add(button4);
            Controls.Add(button17);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Calculator_design";
            Text = "Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button number_1;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private Button button21;
        private Button button22;
        private Button button23;
        private Button button24;
        private TextBox textBox1;
    }
}
