﻿namespace UI_Calculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            CE_clear = new Button();
            clear = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            EqaulsTo = new Button();
            button17 = new Button();
            button18 = new Button();
            button20 = new Button();
            textBox_Result = new TextBox();
            labelCurrentOperation = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(12, 80);
            button1.Name = "button1";
            button1.Size = new Size(58, 53);
            button1.TabIndex = 0;
            button1.Text = "7";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button3_Click;
            // 
            // button2
            // 
            button2.Location = new Point(76, 80);
            button2.Name = "button2";
            button2.Size = new Size(58, 53);
            button2.TabIndex = 1;
            button2.Text = "8";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button3_Click;
            // 
            // button3
            // 
            button3.Location = new Point(140, 80);
            button3.Name = "button3";
            button3.Size = new Size(58, 53);
            button3.TabIndex = 2;
            button3.Text = "9";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(204, 80);
            button4.Name = "button4";
            button4.Size = new Size(58, 53);
            button4.TabIndex = 3;
            button4.Text = "/";
            button4.UseVisualStyleBackColor = true;
            button4.Click += operator_click;
            // 
            // CE_clear
            // 
            CE_clear.Location = new Point(268, 80);
            CE_clear.Name = "CE_clear";
            CE_clear.Size = new Size(58, 53);
            CE_clear.TabIndex = 4;
            CE_clear.Text = "CE";
            CE_clear.UseVisualStyleBackColor = true;
            CE_clear.Click += CE_clear_Click;
            // 
            // clear
            // 
            clear.Location = new Point(268, 139);
            clear.Name = "clear";
            clear.Size = new Size(58, 53);
            clear.TabIndex = 9;
            clear.Text = "C";
            clear.UseVisualStyleBackColor = true;
            clear.Click += clear_Click;
            // 
            // button7
            // 
            button7.Location = new Point(204, 139);
            button7.Name = "button7";
            button7.Size = new Size(58, 53);
            button7.TabIndex = 8;
            button7.Text = "*";
            button7.UseVisualStyleBackColor = true;
            button7.Click += operator_click;
            // 
            // button8
            // 
            button8.Location = new Point(140, 139);
            button8.Name = "button8";
            button8.Size = new Size(58, 53);
            button8.TabIndex = 7;
            button8.Text = "6";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button3_Click;
            // 
            // button9
            // 
            button9.Location = new Point(76, 139);
            button9.Name = "button9";
            button9.Size = new Size(58, 53);
            button9.TabIndex = 6;
            button9.Text = "5";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button3_Click;
            // 
            // button10
            // 
            button10.Location = new Point(12, 139);
            button10.Name = "button10";
            button10.Size = new Size(58, 53);
            button10.TabIndex = 5;
            button10.Text = "4";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button3_Click;
            // 
            // button12
            // 
            button12.Location = new Point(204, 198);
            button12.Name = "button12";
            button12.Size = new Size(58, 53);
            button12.TabIndex = 13;
            button12.Text = "-";
            button12.UseVisualStyleBackColor = true;
            button12.Click += operator_click;
            // 
            // button13
            // 
            button13.Location = new Point(140, 198);
            button13.Name = "button13";
            button13.Size = new Size(58, 53);
            button13.TabIndex = 12;
            button13.Text = "3";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button3_Click;
            // 
            // button14
            // 
            button14.Location = new Point(76, 198);
            button14.Name = "button14";
            button14.Size = new Size(58, 53);
            button14.TabIndex = 11;
            button14.Text = "2";
            button14.UseVisualStyleBackColor = true;
            button14.Click += button3_Click;
            // 
            // button15
            // 
            button15.Location = new Point(12, 198);
            button15.Name = "button15";
            button15.Size = new Size(58, 53);
            button15.TabIndex = 10;
            button15.Text = "1";
            button15.UseVisualStyleBackColor = true;
            button15.Click += button3_Click;
            // 
            // EqaulsTo
            // 
            EqaulsTo.Location = new Point(268, 198);
            EqaulsTo.Name = "EqaulsTo";
            EqaulsTo.RightToLeft = RightToLeft.No;
            EqaulsTo.Size = new Size(58, 112);
            EqaulsTo.TabIndex = 19;
            EqaulsTo.Text = "=";
            EqaulsTo.UseVisualStyleBackColor = true;
            EqaulsTo.Click += EqaulsTo_Click;
            // 
            // button17
            // 
            button17.Location = new Point(204, 257);
            button17.Name = "button17";
            button17.Size = new Size(58, 53);
            button17.TabIndex = 18;
            button17.Text = "+";
            button17.UseVisualStyleBackColor = true;
            button17.Click += operator_click;
            // 
            // button18
            // 
            button18.Location = new Point(140, 257);
            button18.Name = "button18";
            button18.Size = new Size(58, 53);
            button18.TabIndex = 17;
            button18.Text = ".";
            button18.UseVisualStyleBackColor = true;
            button18.Click += button3_Click;
            // 
            // button20
            // 
            button20.Location = new Point(12, 257);
            button20.Name = "button20";
            button20.Size = new Size(122, 53);
            button20.TabIndex = 15;
            button20.Text = "0";
            button20.UseVisualStyleBackColor = true;
            button20.Click += button3_Click;
            // 
            // textBox_Result
            // 
            textBox_Result.Location = new Point(12, 40);
            textBox_Result.Multiline = true;
            textBox_Result.Name = "textBox_Result";
            textBox_Result.Size = new Size(314, 34);
            textBox_Result.TabIndex = 20;
            textBox_Result.Text = "0";
            textBox_Result.TextAlign = HorizontalAlignment.Right;
            // 
            // labelCurrentOperation
            // 
            labelCurrentOperation.AutoSize = true;
            labelCurrentOperation.ForeColor = SystemColors.ButtonShadow;
            labelCurrentOperation.Location = new Point(12, 9);
            labelCurrentOperation.Name = "labelCurrentOperation";
            labelCurrentOperation.Size = new Size(0, 21);
            labelCurrentOperation.TabIndex = 21;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(337, 318);
            Controls.Add(labelCurrentOperation);
            Controls.Add(textBox_Result);
            Controls.Add(EqaulsTo);
            Controls.Add(button17);
            Controls.Add(button18);
            Controls.Add(button20);
            Controls.Add(button12);
            Controls.Add(button13);
            Controls.Add(button14);
            Controls.Add(button15);
            Controls.Add(clear);
            Controls.Add(button7);
            Controls.Add(button8);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(CE_clear);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Font = new Font("Calibri", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button CE_clear;
        private Button clear;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button EqaulsTo;
        private Button button17;
        private Button button18;
        private Button button20;
        private TextBox textBox_Result;
        private Label labelCurrentOperation;
    }
}
