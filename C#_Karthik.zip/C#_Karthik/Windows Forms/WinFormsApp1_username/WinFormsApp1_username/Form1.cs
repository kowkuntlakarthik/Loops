namespace WinFormsApp1_username
{
    public partial class User_Details : Form
    {
        string username = string.Empty;
        string password = string.Empty;
        public User_Details()
        {
            
            username = Console.ReadLine();
            password = Console.ReadLine();

            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txt_enterusername_TextChanged(object sender, EventArgs e)
        {
           
            txt_enterusername.Text = username;

        }

        private void txt_enterpassword_TextChanged(object sender, EventArgs e)
        {
            txt_enterpassword.Text = password;
           

        }

        private void button_OK_Click(object sender, EventArgs e)
        {
            


        }

        private void button_Cancel_Click(object sender, EventArgs e)

        {
            this.Close();

        }

        private void btn_Reset_Click(object sender, EventArgs e)
        {

        }
    }
}
