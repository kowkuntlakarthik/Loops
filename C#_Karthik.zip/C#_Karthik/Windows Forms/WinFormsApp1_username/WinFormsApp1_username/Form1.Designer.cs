﻿namespace WinFormsApp1_username
{
    partial class User_Details
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbl_username = new Label();
            lbl_Password = new Label();
            txt_enterusername = new TextBox();
            txt_enterpassword = new TextBox();
            button_OK = new Button();
            button_Cancel = new Button();
            btn_Reset = new Button();
            SuspendLayout();
            // 
            // lbl_username
            // 
            lbl_username.AutoSize = true;
            lbl_username.Location = new Point(29, 86);
            lbl_username.Name = "lbl_username";
            lbl_username.Size = new Size(75, 20);
            lbl_username.TabIndex = 0;
            lbl_username.Text = "Username";
            lbl_username.Click += label1_Click;
            // 
            // lbl_Password
            // 
            lbl_Password.AutoSize = true;
            lbl_Password.Location = new Point(29, 137);
            lbl_Password.Name = "lbl_Password";
            lbl_Password.Size = new Size(70, 20);
            lbl_Password.TabIndex = 1;
            lbl_Password.Text = "Password";
            // 
            // txt_enterusername
            // 
            txt_enterusername.Location = new Point(140, 85);
            txt_enterusername.Multiline = true;
            txt_enterusername.Name = "txt_enterusername";
            txt_enterusername.Size = new Size(322, 34);
            txt_enterusername.TabIndex = 2;
            txt_enterusername.TextChanged += txt_enterusername_TextChanged;
            // 
            // txt_enterpassword
            // 
            txt_enterpassword.Location = new Point(140, 134);
            txt_enterpassword.Multiline = true;
            txt_enterpassword.Name = "txt_enterpassword";
            txt_enterpassword.Size = new Size(319, 34);
            txt_enterpassword.TabIndex = 3;
            txt_enterpassword.TextChanged += txt_enterpassword_TextChanged;
            // 
            // button_OK
            // 
            button_OK.Location = new Point(68, 207);
            button_OK.Name = "button_OK";
            button_OK.Size = new Size(94, 29);
            button_OK.TabIndex = 4;
            button_OK.Text = "OK";
            button_OK.UseVisualStyleBackColor = true;
            button_OK.Click += button_OK_Click;
            // 
            // button_Cancel
            // 
            button_Cancel.Location = new Point(201, 209);
            button_Cancel.Name = "button_Cancel";
            button_Cancel.Size = new Size(94, 29);
            button_Cancel.TabIndex = 5;
            button_Cancel.Text = "Cancel";
            button_Cancel.UseVisualStyleBackColor = true;
            button_Cancel.Click += button_Cancel_Click;
            // 
            // btn_Reset
            // 
            btn_Reset.Location = new Point(342, 209);
            btn_Reset.Name = "btn_Reset";
            btn_Reset.Size = new Size(94, 29);
            btn_Reset.TabIndex = 6;
            btn_Reset.Text = "Reset";
            btn_Reset.UseVisualStyleBackColor = true;
            btn_Reset.Click += btn_Reset_Click;
            // 
            // User_Details
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(548, 267);
            Controls.Add(btn_Reset);
            Controls.Add(button_Cancel);
            Controls.Add(button_OK);
            Controls.Add(txt_enterpassword);
            Controls.Add(txt_enterusername);
            Controls.Add(lbl_Password);
            Controls.Add(lbl_username);
            Name = "User_Details";
            Text = "User Details";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_username;
        private Label lbl_Password;
        private TextBox txt_enterusername;
        private TextBox txt_enterpassword;
        private Button button_OK;
        private Button button_Cancel;
        private Button btn_Reset;
    }
}
