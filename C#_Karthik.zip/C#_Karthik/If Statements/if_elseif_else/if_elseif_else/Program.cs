﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace ConditionalSatatements
{
    internal class Program
    {
        static void Main(string[] args)
        {

            /*//Today Class..
            //Decision Making Statements.......
            //If and if-else and if else if and nested statements..
 
            //Swich Statements.........
            //bool isCheck = false;
 
            //if(isCheck)
            //{
            //    Console.WriteLine("Kisohre studygin M_Tech");
            //}
            //else
            //{
            //    Console.WriteLine("Kishore is not Studying in M_Tech");
            //}
 
            ////if-els if -else if -else if...
            //for (int i = 1; i < 20; i++)
            //{
            //    if(i == 1)
            //    {
            //        Console.WriteLine("1 is Printing..");
            //    }
            //    else if (i == 5)
            //    {
            //        Console.WriteLine("5 is Printing..");
            //    }
            //    else if (i == 9)
            //    {
            //        Console.WriteLine("9 is Printing..");
            //    }
            //    else if (i == 15)
            //    {
            //        Console.WriteLine("15 is Printing..");
            //    }
            //}
            ////Nested if Statements..
            //for (int i = 1; i < 20; i++)
            //{
            //    if (i == 1)
            //    {
            //        for (int j = 0; j < 5; j++)
            //        {
            //            Console.WriteLine("Printing the Second Loop J:"+ j);
            //        }
            //    }
            //    else if (i == 1)
            //    {
            //        for (int k = 0; k < 3; k++)
            //        {
            //            Console.WriteLine("Printing the Second Loop k:" + k);
            //        }
            //    }
            //    else
            //    {
            //        Console.WriteLine("Pring the i Values here I : " + i);
            //    }
            //}
            */
            //Nested If If Else if Conndtions..
            for (int i = 1; i < 20; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (i == 1)
                    {
                        if (j == 1)
                        {
                            for (int k = 0; k < 5; k++)
                            {
                                Console.WriteLine("Printing the Second Loop K:" + k);
                            }
                        }
                        else
                        {
                            Console.WriteLine("Printing the Second Loop J:" + j);
                        }
                    }
                }
                if (i == 5)
                {
                    for (int n = 0; n < 5; n++)
                    {
                        Console.WriteLine("Printing the Second Loop n:" + n);
                    }

                }
            }

            ///Swtich Statement...
            ///

        }
    }
}