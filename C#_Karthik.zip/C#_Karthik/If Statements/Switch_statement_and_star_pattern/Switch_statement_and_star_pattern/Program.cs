﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace SwitchStatements
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Switch Statement...
            //Printing the Days..
            //Program.SwitchMethod(3,10,30);
            //Program.SwitchMethod(1,23,50);

            DimondPattern();
        }
        public static void SwitchMethod(int nIndex, int value1 = 0, int value2 = 0)
        {
            switch (nIndex)
            {
                case 0:
                    Addition(value1, value2);
                    break;

                case 1:
                    Substraction(value1, value2);
                    break;

                case 2:
                    Mulitplication();
                    break;

                case 3:
                    Devision();
                    break;
                default:
                    break;
            }
        }
        public static void Addition(int value1, int value2)
        {

        }
        public static void Substraction(int value1, int value2)
        {

        }
        public static void Mulitplication()
        {

        }
        public static void Devision()
        {

        }

        public static void DimondPattern()
        {
            int nIndex1 = 3;
            int nIndex2 = 5;

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (j <= nIndex1 || nIndex2 <= j)
                    {
                        Console.Write(" ");
                    }
                    else
                    {
                        Console.Write("*");
                    }
                }
                nIndex1--;
                nIndex2++;
                Console.WriteLine();
            }

            nIndex1 = 0;
            nIndex2 = 8;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (j <= nIndex1 || nIndex2 <= j)
                    {
                        Console.Write(" ");
                    }
                    else
                    {
                        Console.Write("*");
                    }
                }
                nIndex1++;
                nIndex2--;
                Console.WriteLine();
            }

        }
    }
}