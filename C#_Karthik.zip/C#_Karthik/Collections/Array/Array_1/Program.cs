﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Array_Colletions");

            int[] array1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
            

            int value1 = array1[0];
            int value2 = array1[1];
            int value3 = array1[2];
            int value4 = array1[3];
            int value5 = array1[4];
            int value6 = array1[5];
            int value7 = array1[6];
            int value8 = array1[7];
            int value9 = array1[8];
            int value10 = array1[9];
            int value11 = array1[10];
            int value12 = array1[11];
            int value13 = array1[12];
            int value14 = array1[13];
            int value15 = array1[14];

            Console.WriteLine("Value 1: " + value1);
            Console.WriteLine("Value 2: " + value2);
            Console.WriteLine("Value 3: " + value3);
            Console.WriteLine("Value 4: " + value4);
            Console.WriteLine("Value 5: " + value5);
            Console.WriteLine("Value 6: " + value6);
            Console.WriteLine("Value 7: " + value7);
            Console.WriteLine("Value 8: " + value8);
            Console.WriteLine("Value 9: " + value9);
            Console.WriteLine("Value 10: " + value10);
            Console.WriteLine("Value 11: " + value11);
            Console.WriteLine("Value 12: " + value12);
            Console.WriteLine("Value 13: " + value13);
            Console.WriteLine("Value 14: " + value14);
            Console.WriteLine("Value 15: " + value15);




        }
    }
}
