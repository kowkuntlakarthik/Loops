﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Array_Colletions");

            int[] array1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
            for (int i = 0; i < array1.Length; i++)
            {
                Console.WriteLine("Array value: " + array1[i]);
            }

            //below code will throw error, because arrays values defined upto index 9. to handle this situation we go with length(Ex: array1.Length)
            /*for(int i = 0; i <= 10; i++)
            {
                Console.WriteLine("Array value: " + array1[i]);
            }*/


            Console.WriteLine();
            char[] array2 = { 'a', 'b', 'c', 'd', 'e' };
            for(int i = 0; i< array2.Length; i++)
            {
                Console.WriteLine("Array2 value: " + array2[i]);
            }

        }
    }
}
