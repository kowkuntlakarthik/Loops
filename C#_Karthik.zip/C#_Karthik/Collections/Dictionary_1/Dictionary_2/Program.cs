﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionary_1
{
    internal class Program
    {
        public static int key;
        static void Main(string[] args)
        {

            // Dictionary_1 -> storing values by taking user input.
            
            Console.WriteLine("Dictionary values");

            Dictionary<int, double> dictionaryvalues = new Dictionary<int, double>();
            Console.Write("Enter required number of values to be store in Dictionary: ");
            int count = Convert.ToInt32(Console.ReadLine());
            
            

            for (int i = 1; i <= count; i++)
            {

                Console.Write("\nEnter " + i + " Key number: ");
                key = Convert.ToInt32(Console.ReadLine());

                
                
                Console.Write("Enter value for " + i + " Key :");
                double value = Convert.ToDouble(Console.ReadLine());

                
                if (dictionaryvalues.ContainsKey(key))
                {
                    Console.WriteLine("Entered Key " + key + " already exist. Please enter different key number and assign value to key");
                    i--;
                }
                dictionaryvalues[key] = value;


            }
            //Printing all dictionary values
            foreach (var rkeyvalue in dictionaryvalues)
            {

                //Console.WriteLine($"Displaying values: {rkeyvalue.Key} , {rkeyvalue.Value}"); // this line is working
                //Console.WriteLine($"Displaying values: {rkeyvalue.key} , {rkeyvalue.value}"); //why we need to give captical Key, Value
                Console.WriteLine("\nDisplay all values: " + (rkeyvalue.Key, rkeyvalue.Value));

            }

            //Printing the value for the entered key
            Console.Write("\nEnter Dictionary key value between 1 to " + count + ": ");
            int d = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Dictionary key value: " + d);
                                               
            
            if (d <= dictionaryvalues.Count)  
            {
                Console.WriteLine("Dictionary value for the entered " + d + " key: " + dictionaryvalues[d]);

            }
            else                                                            
            {
                Console.WriteLine("Entered " + d + " key value does not exist. Please check and enter Key value again.");
            }

        
        }


    }
}

