﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionary_1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            // Dictionary_1 -> storing values by taking user input.
        
            Console.WriteLine("Dictionary values");

            Dictionary<int, double> dictionaryvalues = new Dictionary<int, double>();
            Console.Write("Enter number of values want to store in Dictionary: ");
            int count = Convert.ToInt32(Console.ReadLine());
            

            

            for (int i = 1; i <= count; i++)
            {

                Console.Write("\nEnter " + i + " Key number: ");
                int key = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter value for " + i + " Key :");
                double value = Convert.ToDouble(Console.ReadLine());

                if (dictionaryvalues.ContainsKey(key))  
                {
                    Console.WriteLine("Entered Key " + key + " already exist. Please enter different key number and assign value to key");
                    i--;
                }
                dictionaryvalues[key] = value;


            }
            foreach (var rkeyvalue in dictionaryvalues)
            {

                //Console.WriteLine($"Displaying values: {rkeyvalue.Key} , {rkeyvalue.Value}"); // this line is working
                //Console.WriteLine($"Displaying values: {rkeyvalue.key} , {rkeyvalue.value}"); //why we need to give captical Key, Value
                Console.WriteLine("\nDisplay all values: " + (rkeyvalue.Key , rkeyvalue.Value));

            }

            Console.Write("\nEnter Dictionary key value between 1 to 5: ");
            double d = dictionaryvalues[Convert.ToInt32(Console.ReadLine())];
            Console.WriteLine("Value assigned for the entered key is: " + d);

        }
        



        
    }
}

