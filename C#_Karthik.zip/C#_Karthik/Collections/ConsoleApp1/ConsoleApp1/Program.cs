﻿using System;
using System.Collections.Generic;

namespace DictionaryExample
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Dictionary Collections - Dynamic Input");
            Console.WriteLine("Dictionary can store key (int) and value (double)\n");

            Dictionary<int, double> dictionaryvalue = new Dictionary<int, double>();

            // Ask how many entries the user wants to add
            Console.Write("How many key-value pairs do you want to add? ");
            int count = Convert.ToInt32(Console.ReadLine());

            // Loop to read each pair from the console
            for (int i = 0; i < count; i++)
            {
                Console.Write($"\nEnter key {i + 1} (integer): ");
                int key = Convert.ToInt32(Console.ReadLine());

                Console.Write($"Enter value for key {key} (double): ");
                double value = Convert.ToDouble(Console.ReadLine());

                // Add to dictionary (with duplicate key handling)
                if (dictionaryvalue.ContainsKey(key))
                {
                    Console.WriteLine($"Key {key} already exists. Overwriting the old value.");
                }
                dictionaryvalue[key] = value; // This will add or overwrite
            }

            // Display all entries
            Console.WriteLine("\n--- All entries in the dictionary ---");
            foreach (var pair in dictionaryvalue)
            {
                Console.WriteLine($"Key: {pair.Key} => Value: {pair.Value}");
            }

            // Search for a specific key
            Console.Write("\nEnter a key to lookup its value: ");
            int searchKey = Convert.ToInt32(Console.ReadLine());

            if (dictionaryvalue.TryGetValue(searchKey, out double foundValue))
            {
                Console.WriteLine($"Value for key {searchKey}: {foundValue}");
            }
            else
            {
                Console.WriteLine($"Key {searchKey} not found in the dictionary.");
            }

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}