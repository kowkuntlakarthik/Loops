﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionary
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Dictionary Collections");
            Console.WriteLine("Dictionary can store 2 data types");

            Dictionary<int, double> dictionaryvalue = new Dictionary<int, double>();
            dictionaryvalue.Add(1, 1.125);
            dictionaryvalue.Add(2, 2.125);
            dictionaryvalue.Add(3, 3.125);
            dictionaryvalue.Add(4, 4.125);
            dictionaryvalue.Add(5, 5.125);

            Console.Write("Enter Dictionary key value between 1 to 5: ");
            double d = dictionaryvalue[Convert.ToInt32(Console.ReadLine())];
            Console.WriteLine("Dictionary key value: " + d);
            
        }
    }
}
