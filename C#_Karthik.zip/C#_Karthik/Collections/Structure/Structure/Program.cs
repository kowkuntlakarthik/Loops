﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Structure.Program;

namespace Structure
{
    internal class Program
    {
        public struct StudentInfo
        {
            public string Name;
            public int ID;
            public int Floor;
            public int section;
            public int standard;
            public int passedOut;
        }
        static void Main(string[] args)
        {
            StudentInfo studentInfo1 = new StudentInfo();
            studentInfo1.Name = "Test";
            studentInfo1.ID = 48;
            studentInfo1.Floor = 1;
            studentInfo1.standard = 5;
            studentInfo1.section = 2;
            studentInfo1.passedOut = 2025;

            List<StudentInfo> listOfStudentInfo = new List<StudentInfo>();

            listOfStudentInfo.Add(studentInfo1);

            for (int i = 0; i < listOfStudentInfo.Count; i++)
            {
                Console.WriteLine(listOfStudentInfo[i].Name);
                Console.WriteLine(listOfStudentInfo[i].ID);
                Console.WriteLine(listOfStudentInfo[i].Floor);
                Console.WriteLine(listOfStudentInfo[i].standard);
                Console.WriteLine(listOfStudentInfo[i].section);
                Console.WriteLine(listOfStudentInfo[i].passedOut);
            }

        }
    }
}
