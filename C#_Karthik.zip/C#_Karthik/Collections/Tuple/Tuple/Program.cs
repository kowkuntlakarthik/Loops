﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tuple
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Tuple Collections");
            //       name   age class section floor , rank, result
            Tuple < String, int, int, char, int, int , bool> tupleinfo = new Tuple<string, int, int, char, int, int, bool> ("Test", 10, 2, 'a', 1, 5, true);

            Console.WriteLine("Printing the info");
            Console.WriteLine("Student name: " + tupleinfo.Item1);
            Console.WriteLine("Age: " + tupleinfo.Item2);
            Console.WriteLine("Class: " + tupleinfo.Item3);
            Console.WriteLine("Section: " + tupleinfo.Item4);
            Console.WriteLine("Floor: " + tupleinfo.Item5);
            Console.WriteLine("Rank: " + tupleinfo.Item6);
            Console.WriteLine("Result: " + tupleinfo.Item7);

        }

    }
}
