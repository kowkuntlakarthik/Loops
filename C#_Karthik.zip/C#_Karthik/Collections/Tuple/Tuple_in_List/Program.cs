﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tuple_in_List
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Tuple in List");
            List<Tuple<String, int, int, char, int, int, bool>> tuplelist = new List<Tuple<String, int, int, char, int, int, bool>>();

            Tuple<String, int, int, char, int, int, bool> tupleinfo = new Tuple<string, int, int, char, int, int, bool>("Test", 10, 2, 'a', 1, 5, true);


            tuplelist.Add(tupleinfo);

            for(int i = 0; i< tuplelist.Count; i++)
            {
                string first = tuplelist[i].Item1;
                int second = tuplelist[i].Item2;
                int third = tuplelist[i].Item3;
                char fourth = tuplelist[i].Item4;
                int  fifth = tuplelist[i].Item5;
                int sixth = tuplelist[i].Item6;
                bool seventh = tuplelist[i].Item7;

                Console.WriteLine(first);
                Console.WriteLine(second);
                Console.WriteLine(third);
                Console.WriteLine(fourth);
                Console.WriteLine(fifth);
                Console.WriteLine(sixth);
                Console.WriteLine(seventh);
            }



        }
    }
}
