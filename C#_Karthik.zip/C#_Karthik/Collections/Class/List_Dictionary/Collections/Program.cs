﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collection_Topic
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ////List,Dictionary,Array,Tuple,Structures,Class..

            ////List - we can store the only one datatype...
            ////Dictionary - We can store the 2 datatypes..
            ////Array - We can store only one datatyape.
            ////Tuple concet- upto 7 data we can store..

            ////More datatypes information store then we can go with Class ,Structores...

            ////list..
            //List<int> lisOfInfor = new List<int>();
            ////Storing the data into list..
            //for (int i = 0; i < 10; i++)
            //{
            //    lisOfInfor.Add(i);
            //}

            //int requiruedVal = lisOfInfor[8];

            ////Retrive the List information..

            ////for (int i = 0; i < lisOfInfor.Count; i++)
            ////{
            ////    Console.WriteLine("Retirving Info "+  lisOfInfor[i]);
            ////}

            //foreach (var iInfo in lisOfInfor)
            //{
            //    Console.WriteLine("Retirving Info " + iInfo);
            //}

            ////List

            List<char> listOfCharcters = new List<char>();

            char a = 'a';
            char b = 'h';

            listOfCharcters.Add(a);
            listOfCharcters.Add(b);
            listOfCharcters.Add('G');
            listOfCharcters.Add('I');
            listOfCharcters.Add('R');
            listOfCharcters.Add('A');
            listOfCharcters.Add('R');
            listOfCharcters.Add('K');
            listOfCharcters.Add('A');

            foreach (var iInfor in listOfCharcters)
            {
                Console.WriteLine("Retirving Info Char " + iInfor);

            }


            ///

            //Assembly....Top Node

            //List<string> listOfAssemblies = new List<string>();
            //List<string> listOfParts = new List<string>();

            //Assembly read and segregate the data and store it..

            //Dictionary. Contains the KeyVal Pairs...
            //Key, Value
            Dictionary<int, List<string>> keyValuePairs = new Dictionary<int, List<string>>();


            //keyValuePairs.Add(1, 1);
            //keyValuePairs.Add(5, 3);
            //keyValuePairs.Add(2, 1);
            //keyValuePairs.Add(8, 5);
            //keyValuePairs.Add(90, 9);
            //keyValuePairs.Add(9, 5);

            //string value = keyValuePairs[5];//9,5,Empty,,2,

        }
    }
}