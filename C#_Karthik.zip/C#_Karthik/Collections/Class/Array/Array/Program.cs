﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array_Concept
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Array Concept....
            //DataType and Array Symbol,Varialbe Name,=,give size of the array..
            //int[] array2 = new int[]{25,26,23 };
            //int[] array3 = new int[2] {1,2 };

            int[] array1 = { 10, 20, 56, 45, 78, 96, 23 };
            int[] array2 = new int[] { 25, 26, 23, 56, 89 };
            int[] array3 = new int[2] { 1, 2 };
            int[] array4 = new int[4];
            array4[0] = 10;
            array4[1] = 20;
            array4[2] = 30;
            array4[3] = 40;

            for (int i = 0; i < array4.Length; i++)
            {
                Console.WriteLine(array4[i]);
            }
            //[0,1,2,3,4,5,6]
            //REtriving the Info by using For Loop..
            //Console.WriteLine("First.......");

            //for (int i = 0; i < 10; i++)//Work,7th i
            //{
            //    Console.WriteLine(array1[i]);
            //}
            //Console.WriteLine("Second ");
            //for (int i = 0; i < array2.Length; i++)
            //{
            //    Console.WriteLine(array2[i]);
            //}
            //Console.WriteLine("Third ");

            //for (int i = 0; i < array3.Length; i++)
            //{
            //    Console.WriteLine(array3[i]);
            //}
            //Console.WriteLine("Fourth ");

            //for (int i = 0; i < array4.Length; i++)
            //{
            //    Console.WriteLine(array4[i]);
            //}
            //int value1  = array1[2];
            //int value2  = array1[4];
            //int value3  = array1[6];

            //int value1 = array1[0];
            //int value2 = array1[1];
            //int value3 = array1[2];
            //int value4 = array1[3];
            //int value5 = array1[4];
            //int value6 = array1[5];
            //int value7 = array1[6];
            //Console.WriteLine(value1);
            //Console.WriteLine(value2);
            //Console.WriteLine(value3);
            //Console.WriteLine(value4);
            //Console.WriteLine(value5);
            //Console.WriteLine(value6);
            //Console.WriteLine(value7);
        }
    }
}