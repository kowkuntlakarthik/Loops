﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace TupleConcept
{
    internal class Program
    {
        public struct StudentInfo
        {
            public string Name;
            public int ID;
            public int Floar;
            public char sectionName;
            public int standard;
            public int passedOut;
        }
        static void Main(string[] args)
        {
            //Today Concept is Tuple and Structure...

            //List - It will allow only one data type - It will start from one[0st index]-count
            //List - We can store the Multiple Duplicates..
            //Array- It will allow one datatype-It will start from Zero[0th index]-Length
            //Array - We can store the Multiple Dupllicates..
            //Dictionary - It will allow Two Datatypes.-It will start from one[1st index]-count
            //Dictionary - We coudn't able to store the Key Duplicates..
            //Tuple - It will allow the 7 datatypes..- It will start from one[1st index]
            //Tuple - We can store the muliptle duplicates..
            //Structures - We can store the multiple datatypes..
            //Structres- We can store the Muliple duplicates..

            /* //Tuple Concept..
             List<Tuple<double, int, int, double, bool, string, char>> listOfTuple = new List<Tuple<double, int, int, double, bool, string, char>>();
 
             Tuple<double, int, int, double, bool, string, char> tuple = new Tuple<double, int, int, double, bool, string, char>
             (20.2, 52, 45, 23.02, true, "Sample", 'A');
 
             Tuple<double, int, int, double, bool, string, char> tuple1 = new Tuple<double, int, int, double, bool, string, char>
           (20.2, 52, 45, 23.02, true, "Sample", 'A');
 
             Tuple<double, int, int, double, bool, string, char> tuple2 = new Tuple<double, int, int, double, bool, string, char>
           (20.2, 52, 45, 23.02, true, "Sample", 'A');
 
             Tuple<double, int, int, double, bool, string, char> tuple3 = new Tuple<double, int, int, double, bool, string, char>
          (20.2, 52, 45, 23.02, true, "Sample", 'A');
 
             Tuple<double, int, int, double, bool, string, char> tuple4 = new Tuple<double, int, int, double, bool, string, char>
          (20.2, 52, 45, 23.02, true, "Sample", 'A');
 
 
             listOfTuple.Add(tuple);
             listOfTuple.Add(tuple1);
             listOfTuple.Add(tuple2);
             listOfTuple.Add(tuple3);
             listOfTuple.Add(tuple4);
 
             Console.WriteLine("For Loop................................................");
             for (int i = 0; i < listOfTuple.Count; i++)
             {
                 double first  = listOfTuple[i].Item1;
                 int secomnd   = listOfTuple[i].Item2;
                 int third     = listOfTuple[i].Item3;
                 double fourth = listOfTuple[i].Item4;
                 bool five     = listOfTuple[i].Item5;
                 string sixth  = listOfTuple[i].Item6;
                 char seventh  = listOfTuple[i].Item7;
 
                 Console.WriteLine(first);
                 Console.WriteLine(secomnd);
                 Console.WriteLine(third);
                 Console.WriteLine(fourth);
                 Console.WriteLine(five);
                 Console.WriteLine(sixth);
                 Console.WriteLine(seventh);
 
                 Console.WriteLine("=====================================================");
             }
 
             Console.WriteLine("For Each Loop..............................");
             foreach (var inforTuple in listOfTuple)
             {
                 double first  = inforTuple.Item1;
                 int secomnd   = inforTuple.Item2;
                 int third     = inforTuple.Item3;
                 double fourth = inforTuple.Item4;
                 bool five     = inforTuple.Item5;
                 string sixth  = inforTuple.Item6;
                 char seventh  = inforTuple.Item7;
 
                 Console.WriteLine(first);
                 Console.WriteLine(secomnd);
                 Console.WriteLine(third);
                 Console.WriteLine(fourth);
                 Console.WriteLine(five);
                 Console.WriteLine(sixth);
                 Console.WriteLine(seventh);
 
                 Console.WriteLine("=====================================================");
             }*/

            /*Structure Cocept...*/

            StudentInfo studentInfo1 = new StudentInfo();
            StudentInfo studentInfo2 = new StudentInfo();
            StudentInfo studentInfo3 = new StudentInfo();

            //Data Storing...
            studentInfo1.Name = "Ravi";
            studentInfo1.ID = 135;
            studentInfo1.Floar = 2;
            studentInfo1.sectionName = 'A';
            studentInfo1.standard = 10;
            studentInfo1.passedOut = 2015;

            studentInfo2.Name = "Ramkumar";
            studentInfo2.ID = 125;
            studentInfo2.Floar = 12;
            studentInfo2.sectionName = 'C';
            studentInfo2.standard = 9;
            studentInfo2.passedOut = 2014;

            studentInfo3.Name = "Kishore";
            studentInfo3.ID = 120;
            studentInfo3.Floar = 10;
            studentInfo3.sectionName = 'B';
            studentInfo3.standard = 10;
            studentInfo3.passedOut = 2015;

            List<StudentInfo> listOfStudentInfo = new List<StudentInfo>();

            listOfStudentInfo.Add(studentInfo1);
            listOfStudentInfo.Add(studentInfo2);
            listOfStudentInfo.Add(studentInfo3);

            //Retriving the information from the list and printing...
            for (int i = 0; i < listOfStudentInfo.Count; i++)
            {
                Console.WriteLine(listOfStudentInfo[i].Name);
                Console.WriteLine(listOfStudentInfo[i].ID);
                Console.WriteLine(listOfStudentInfo[i].Floar);
                Console.WriteLine(listOfStudentInfo[i].sectionName);
                Console.WriteLine(listOfStudentInfo[i].standard);
                Console.WriteLine(listOfStudentInfo[i].passedOut);
            }
        }
    }
}