﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace List
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("List Collections");

            List<int> listinfo = new List<int>();
            for(int i = 0; i < 10; i++)
            {
                listinfo.Add(i);
            }

            Console.WriteLine("Printing the List values");
            for(int i = 0; i < listinfo.Count; i++)
            {
                Console.WriteLine("Value: " + listinfo[i]);
            }

            Console.WriteLine("\nforeach loop");
            foreach(int linfo in listinfo)
            {
                Console.WriteLine("List value: " + linfo);
            }

        }
    }
}
