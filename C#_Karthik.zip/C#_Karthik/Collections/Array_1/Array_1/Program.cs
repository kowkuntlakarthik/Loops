﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;

namespace Array_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Printing array values using user input");

            Console.Write("\nEnter how many values need to be store: ");
            int count = Convert.ToInt32(Console.ReadLine());
            //int j = 0;
            double[] array1 = new double[count];

            for(int i = 0; i < count; i++)
            {
                Console.Write("Enter value for the " + i + " index: ");
                array1[i] = Convert.ToDouble(Console.ReadLine());
            }
            Console.WriteLine("------------------------------------------------------------");
            //foreach
            Console.WriteLine("foreach loop");
            foreach (var arrayvalue in array1)
            {
                Console.WriteLine("Array values: " + arrayvalue);
            }
            Console.WriteLine("------------------------------------------------------------");
            //for loop
            Console.WriteLine("for loop");
            for (int i = 0; i < array1.Length; i++)
            {
                Console.WriteLine("Array values: " + array1[i]);
            }
            Console.WriteLine("------------------------------------------------------------");

            //Printing the number by using the index position
            Console.WriteLine("Find the number for the required index number");
            searchAgain:
            Console.Write("\nEnter index between " + (count - count) + " to " + (count - 1) + ": ");
            int index = Convert.ToInt32(Console.ReadLine());
            if(index >= 0 && index <= count)
            {
                Console.WriteLine("Number at the " + index + " index position: " + array1[index]);
            }
            else
            {
                Console.WriteLine("Entered index " + index + " could not be found in the Array list.Please check and enter again.");
                goto searchAgain;
            }
            

            Console.WriteLine("------------------------------------------------------------");

            //Printing the index position by using the number                      // again in this code i need to use searchAgain goto. how to use it?
            
            Console.WriteLine("Find the index for entered number");
            
            Console.Write("Enter number for any index position " + (count - count) + " to " + (count - 1) + " from the above mentioned input data: ");
            //Console.Write("\nEnter number between " + (count - count) + " to " + (count - 1) + ": ");
            //Console.Write("\n Enter number between " + array1[0] + " to" + array1[count - 1] + ": ");
            int number = Convert.ToInt32(Console.ReadLine());
            int result = Array.IndexOf(array1, number);
            if (result != -1)
            {
                Console.WriteLine("index position for the entered number " + number + " is: " + Array.IndexOf(array1, number));
            }
            else
            {
                Console.WriteLine("Entered number " + number + " could not be found in the Array list. Please check and enter again.");
                
            }

            
            
            
        }
    }
}
