﻿/*
       *
      ***
     *****
    *******
   *********
  *********** 
 *************
***************
*/
using System;

namespace starpattern8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Star pattern 8");
            for(int i = 1; i <= 15; i=i+2 )
            {
                for(int j = 15; j > i; j = j -2)
                {
                    Console.Write(" ");
                }
                for(int k = 1; k <= i; k++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }
    }
}