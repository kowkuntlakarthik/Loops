﻿/*    
       *
      ***
     *****
    *******
   *********
  *********** 
 *************
***************
 *************
  ***********
   *********
    *******
     *****
      ***
       *
*/
using System;
namespace starpattern3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Star Pattern 3");
            for ( int i = 1; i <= 15; i = i + 2)
            {
                for (int j = 15; j > i; j = j-2)
                {
                    Console.Write(" ");
                }
                for(int k = 1; k <= i; k++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            } 
            for (int l = 13; l >= 1; l = l - 2)
            {
                for (int m = 1; m < 15 - l; m = m + 2)
                {
                    Console.Write(" ");
                }
                for (int n = 1; n <= l; n++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();

            }



        }
    }
}