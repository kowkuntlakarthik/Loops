﻿using System;

namespace forloopstar1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("star pattern 1");
            for (int i = 8; i >= 1; i--)
            {
                for (int j = 1; j <= i; j++)
                {
                    //Console.Write("*" + " ");
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }
    }
}

/* 
 ********
 *******
 ******
 *****
 ****
 ***
 **
 *  */