﻿/*
 * 
 **
 ***
 ****
 *****
 ******
 *******
 ********  */

using System;

namespace starpattern2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Star Pattern 2");
            for(int i = 1; i <= 8; i++)
            {
                for(int j = 1; j <= i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }
    }
}


