﻿/*
1 2 3 4 5
1 2 3 4
1 2 3
1 2
1
*/
using System;

namespace dowhile2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number Pattern 2");
            int i = 5;
            do
            {
                int j = 1;
                do
                {
                    Console.Write(j + " ");
                    j++;
                }
                while (j <= i);
                i--;
                Console.WriteLine();
            }
            while (i >= 1);

        }
       

    }
}