﻿/*
1 2 3 4 5
2 3 4 5
3 4 5
4 5
5
*/
using System;

namespace dowhile1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number pattern 1");
            int i = 1;
            do
            {
                int j = i;
                do
                {
                    Console.Write(j + " ");
                    j++;
                }
                while (j <= 5);
                i++;
                Console.WriteLine();
            }
            while (i <= 5);

        }
    }
}