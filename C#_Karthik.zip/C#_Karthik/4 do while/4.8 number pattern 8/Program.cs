﻿/*
1 1 1 1 1
2 2 2 2
3 3 3
4 4
5
*/
using System;

namespace dowhile8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number pattern 8");
            int i = 1;
            do
            {
                int j = 5;
                do
                {
                    Console.Write(i + " ");
                    j--;
                }
                while (j >= i);
                i++;
                Console.WriteLine();
            }
            while (i <= 5);

        }
    }
}