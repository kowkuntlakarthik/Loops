﻿/*
1
2 2
3 3 3
4 4 4 4
5 5 5 5 5
*/
using System;

namespace dowhile5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number pattern 5");
            int i = 1;
            do
            {
                int j = 1;
                do
                {
                    Console.Write(i + " ");
                    j++;
                }
                while (j <= i);
                i++;
                Console.WriteLine();
            }
            while (i <= 5);
        }
    }
}