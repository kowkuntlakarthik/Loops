﻿/*
5
4 4
3 3 3
2 2 2 2
1 1 1 1 1
*/
using System;

namespace dowhile6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number pattern 6");
            int i = 5;
            do
            {
                int j = 5;
                do
                {
                    Console.Write(i + " ");
                    j--;
                }
                while (j >= i);
                i--;
                Console.WriteLine();
            }
            while (i >= 1);

        }
    }
}