﻿/*
1
1 2
1 2 3
1 2 3 4
1 2 3 4 5
*/
using System;

namespace dowhile4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number pattern 4");
            int i = 1;
            do
            {
                int j = 1;
                do
                {
                    Console.Write(j + " ");
                    j++;
                }
                while (j <= i);
                i++;
                Console.WriteLine();
            }
            while (i <= 5);
        }
    }
}