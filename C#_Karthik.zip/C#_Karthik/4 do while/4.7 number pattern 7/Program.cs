﻿/*
5
5 4
5 4 3
5 4 3 2
5 4 3 2 1
*/
using System;

namespace dowhile7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number pattern 7");
            int i = 5;
            do
            {
                int j = 5;
                do
                {
                    Console.Write(j + " ");
                    j--;
                }
                while (j >= i);
                i--;
                Console.WriteLine();
            }
            while (i >= 1);
        }
    }
}