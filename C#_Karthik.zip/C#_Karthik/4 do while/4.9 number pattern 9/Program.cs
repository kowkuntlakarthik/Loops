﻿/*
5 5 5 5 5
4 4 4 4
3 3 3
2 2
1
*/
using System;

namespace dowhile9
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number pattern 9");
            int i = 5;
            do
            {
                int j = 1;
                do
                {
                    Console.Write(i + " ");
                    j++;
                }
                while (j <= i);
                i--;
                Console.WriteLine();
            }
            while (i >= 1);
        }
    }
}