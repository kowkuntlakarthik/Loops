﻿/*
5 4 3 2 1
5 4 3 2
5 4 3
5 4
5
*/
using System;

namespace dowhile10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number Pattern 10");
            int i = 1;
            do
            {
                int j = 5;
                do
                {
                    Console.Write(j + " ");
                    j--;
                }
                while (j >= i);
                i++;
                Console.WriteLine();
            }
            while (i <= 5);
        }
    }
}
