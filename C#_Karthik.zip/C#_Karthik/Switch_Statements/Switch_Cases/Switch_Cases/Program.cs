﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Switch_Cases
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Switch Statements");

            Console.Write("Enter Value 1: ");
            double value_1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter Value 2: ");
            double value_2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter the operation: ");
            string operations = Console.ReadLine();
            switch (operations)
            {
                case "+":
                   double addition = value_1 + value_2; ;
                    Console.WriteLine("Addition Value: " +  addition);
                    break;
                case "-":
                    double subtraction = value_1 - value_2;
                    Console.WriteLine("Subtraction value: " + subtraction);
                    break;
                case "*":
                    double multiplication = value_1 * value_2;
                    Console.WriteLine("Multiplication value: " + multiplication);
                    break;
                case "/":
                    double division = value_1 / value_2;
                    Console.WriteLine("Division value: " +  division);
                    break;
                case "%":
                    double percentage = value_1 % value_2;
                    Console.WriteLine("Percentage value: " + percentage);
                    break;
                default:
                    Console.WriteLine("No Operations done for the given values.");
                    break;

            }
        }
    }
}
