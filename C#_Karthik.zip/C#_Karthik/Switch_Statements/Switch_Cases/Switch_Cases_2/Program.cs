﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Switch_Cases_2  // performing  operation by using the result and number of operations to be done. and adding more values to the result and printing the total sum
{
    internal class Program
    {
        public static double addition;
        public static double addition_1;
        static void Main(string[] args)
        {
            Console.WriteLine("Switch Statements");

            Console.Write("Enter Value 1: ");
            double value_1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter Value 2: ");
            double value_2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter the operation (+ , - , *, /, %): ");
            string operations = Console.ReadLine();
            switch (operations)
            {
                case "+":
                    addition = value_1 + value_2;
                    Console.WriteLine("Addition Value: " + addition);
                    break;
                case "-":
                    double subtraction = value_1 - value_2;
                    Console.WriteLine("Subtraction value: " + subtraction);
                    break;
                case "*":
                    double multiplication = value_1 * value_2;
                    Console.WriteLine("Multiplication value: " + multiplication);
                    break;
                case "/":
                    double division = value_1 / value_2;
                    Console.WriteLine("Division value: " + division);
                    break;
                case "%":
                    double percentage = value_1 % value_2;
                    Console.WriteLine("Percentage value: " + percentage);
                    break;
                default:
                    Console.WriteLine("No Operations done for the given values.");
                    break;

            }

            Console.WriteLine("Randomly take few numbers and perform addition operation using the result for switch case addition");

            Console.Write("\nEnter the numbers for how many additions to do: ");
            int count = Convert.ToInt32(Console.ReadLine());
            double sum = addition;
            int i = 1;

            while (i <= count)
            {
                op:
                Console.Write("Enter the number to do addition: ");
                double number = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter the operation (+ , - , *, /, %): ");
                string operations_1 = Console.ReadLine();
                if (operations_1 == "+")
                {
                    sum += number;
                }
                else if (operations_1 == "-")
                {
                    sum -= number;
                }
                else if (operations_1 == "*")
                {
                    sum *= number;
                }
                else if (operations_1 == "/")
                {
                    sum /= number;
                }
                else if (operations_1 == "/")
                {

                    sum /= number;
                }
                else if(operations_1 == "%")
                {
                    sum %= number;
                }
                else
                {
                    Console.WriteLine("Invalid operation selected: " +  operations_1);
                    Console.Write(" Do you want to Continue (y/n): ");
                    string yn = Console.ReadLine();
                    if(yn.ToLower() == "y")
                    {
                        goto op;
                    }
                    else
                    {
                        Console.WriteLine("Exited from the operations.");
                    }
                }


                    //sum += add;
                    //addition_1 = addition + add;
                    Console.WriteLine("Result of selected operation: " + sum);
                    Console.WriteLine();
                    i++;
                }

                Console.WriteLine("Total sum: " + sum);
            }
        }
    }

