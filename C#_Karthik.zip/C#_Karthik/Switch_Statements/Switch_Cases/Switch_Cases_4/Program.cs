﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Switch_Cases_4  // performing  operation by using the result and number of operations to be done. and adding more values to the result and printing the total sum
{
    internal class Program
    {
        public static double result;
        public static double addition_1;
        static void Main(string[] args)
        {
            Console.WriteLine("Switch Statements");

            Console.Write("Enter Value 1: ");
            double value_1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter Value 2: ");
            double value_2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter the operation (+ , - , *, /, %): ");
            string operations = Console.ReadLine();
            switch (operations)
            {
                case "+":
                    result = value_1 + value_2;
                    Console.WriteLine("Addition Value: " + result);
                    break;
                case "-":
                     result = value_1 - value_2;
                    Console.WriteLine("Subtraction value: " + result);
                    break;
                case "*":
                    result = value_1 * value_2;
                    Console.WriteLine("Multiplication value: " + result);
                    break;
                case "/":
                    result = value_1 / value_2;
                    Console.WriteLine("Division value: " + result);
                    break;
                case "%":
                    result = value_1 % value_2;
                    Console.WriteLine("Percentage value: " + result);
                    break;
                default:
                    Console.WriteLine("No Operations done for the given values.");
                    break;

            }

            Console.WriteLine("Randomly take few numbers and perform addition operation using the result for switch case addition");

            Console.Write(" Do you want to Continue (y/n): ");
            string yn = Console.ReadLine();
            double sum = result;
            

            while (!(yn.ToLower() == "y"))
            {
            op:
                Console.Write("Enter the number to do next operation: ");
                double number = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter the operation (+ , - , *, /, %): ");
                string operations_1 = Console.ReadLine();
                if (operations_1 == "+")
                {
                    sum += number;
                }
                else if (operations_1 == "-")
                {
                    sum -= number;
                }
                else if (operations_1 == "*")
                {
                    sum *= number;
                }
                else if (operations_1 == "/")
                {
                    sum /= number;
                }
                else if (operations_1 == "/")
                {

                    sum /= number;
                }
                else if (operations_1 == "%")
                {
                    sum %= number;
                }
                else
                {
                    Console.WriteLine("Invalid operation selected: " + operations_1);
                    Console.Write(" Do you want to Continue (y/n): ");
                    string yn1 = Console.ReadLine();
                    if (yn1.ToLower() == "y")
                    {
                        goto op;
                    }
                    else
                    {
                        Console.WriteLine("Exited from the operations.");
                    }
                }
                


                //sum += add;
                //addition_1 = addition + add;
                Console.WriteLine("Result of selected operation: " + sum);

                Console.WriteLine();
                
            }
            Console.WriteLine("Exited from the final operations.");


            Console.WriteLine("Total sum: " + sum);
        }
    }
}

