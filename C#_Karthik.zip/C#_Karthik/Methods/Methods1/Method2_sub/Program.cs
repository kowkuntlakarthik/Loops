﻿using System;

namespace methods2
{
    class Program
    {

        //static void sub(int value1, int value2)
        //{
        //    int results = value1 - value2;
        //    Console.WriteLine("subtraction result: " + results);
        //}
        //static void Main(string[] args)
        //{
        //    sub(20, 10);
        //    sub(40, 20);
        //    sub(60, 10);
        //    sub(90, 29);
        //}

        static void Main(string[] args)
        {

            Program objprogram = new Program();
            objprogram.subtraction(20, 10);
        }
        public void subtraction(int value1, int value2)
        {
            int results = value1 - value2;
            Console.WriteLine("Subtraction results: " + results);
        }

    }
}