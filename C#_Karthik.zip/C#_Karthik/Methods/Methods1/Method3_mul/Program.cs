﻿using System;

namespace methods1
{
    class Program
    {

        static void Multiplication(int value1, int value2)
        {
            int results = value1 * value2;
            Console.WriteLine("Multiplication result: " + results);
        }
        static void Main(string[] args)
        {
            Multiplication(10, 20);
            Multiplication(30, 40);
            Multiplication(50, 60);
            Multiplication(70, 80);
        }
        
        //static void Main(string[] args)
        //{

        //    Program objprogram = new Program();
        //    objprogram.Multiplication(10, 20);
        //}
        //public void Multiplication(int value1, int value2)
        //{
        //    int results = value1 * value2;
        //    Console.WriteLine("Multiplication results: " + results);
        //}

    }
}