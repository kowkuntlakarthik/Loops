﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Methods class");
            addition objadd = new addition();
            objadd.add(10, 20);
            subtraction objsub = new subtraction();
            objsub.sub(99, 33);
        }
        public class addition
        {
            public void add(int value1, int value2)
            {
                int addresult = value1 + value2;
                Console.WriteLine("Addition result: " + addresult);
            }

        }
        public class subtraction
        {
            public void sub(int value3, int value4)
            {
                int subresults = value3 - value4;
                Console.WriteLine("Subtraction result: " + subresults);
            }
        }
    }
}
