﻿/*
1
1 2
1 2 3
1 2 3 4
1 2 3 4 5
*/
using System;

namespace whileloop4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number pattern 4");
            int i = 1;
            while (i <= 5)
            {
                int j = 1;
                while (j <= i)
                {
                    Console.Write(j + " ");
                    j++;
                }
                Console.WriteLine();
                i++;
            }
        }
    }
}