﻿/*
5 4 3 2 1
4 3 2 1
3 2 1
2 1
1
*/
using System;

namespace whileloop3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number pattern 3");
            int i = 5;
            while (i >= 1)
            {
                int j = i;
                while (j >= 1)
                {
                    Console.Write(j + " ");
                    j--;
                }
                Console.WriteLine();
                i--;
            }
        }
    }
}