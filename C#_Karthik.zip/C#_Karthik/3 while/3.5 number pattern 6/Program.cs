﻿/*
5
4 4
3 3 3
2 2 2 2
1 1 1 1 1
*/
using System;

namespace whileloop6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number pattern 6");
            int i = 5;
            while (i >= 1)
            {
                int j = 5;
                while ( j >= i)
                {
                    Console.Write(i + " ");
                    j--;
                }
                Console.WriteLine();
                i--;
            }
        }
    }
}