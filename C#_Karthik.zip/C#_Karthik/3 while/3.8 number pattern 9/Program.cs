﻿/*
5 5 5 5 5
4 4 4 4
3 3 3
2 2
1
*/
using System;

namespace whileloop9
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number pattern 9");
            int i = 5;
            while ( i >= 1)
            {
                int j = 1;
                while ( j <= i)
                {
                    Console.Write(i + " ");
                    j++;
                }
                Console.WriteLine();
                i--;
            }
        }
    }
}