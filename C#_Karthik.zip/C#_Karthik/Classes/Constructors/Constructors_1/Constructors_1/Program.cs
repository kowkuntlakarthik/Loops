﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Authentication.ExtendedProtection.Configuration;
using System.Text;
using System.Threading.Tasks;

namespace Constructors_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Constructors");

            studentinfo objstudent = new studentinfo();
            objstudent.displaystudent();
            

        }

         
    }
    public class studentinfo
    {
        public string sname;
        public int sclass;
        public int sage;
        public char schar;
        public studentinfo()
        {
            Console.Write("Enter student name: ");
            sname = Console.ReadLine();

            Console.Write("Enter class of a student: ");
            sclass = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter age of a student: ");
            sage = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter section of a student: ");
            schar = Convert.ToChar(Console.ReadLine());
        }

        public void displaystudent()
        {
            Console.WriteLine("Printing the student details");
            Console.WriteLine("Student name: " + sname);
            Console.WriteLine("Student class: " + sclass);
            Console.WriteLine("Student section: " + schar);
            Console.WriteLine("Student age: " + sage);
        }

        
    }
}
