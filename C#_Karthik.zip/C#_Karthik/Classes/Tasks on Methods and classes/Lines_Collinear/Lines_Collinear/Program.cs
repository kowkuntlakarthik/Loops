﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lines_Collinear
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Check the Lines are Collinear or not");


            Console.Write("\nEnter value for x1: ");
            double x1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter value for y1: ");
            double y1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("\nEnter value for x2: ");
            double x2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter value for y2: ");
            double y2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("\nEnter value for x3: ");
            double x3 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter value for y3: ");
            double y3 = Convert.ToDouble(Console.ReadLine());

            double m1 = ((y2 - y1) / (x2 - x1));
            double m2 = ((y3 - y2) / (x3 - x2));

            if (m1 == m2)
            {
                Console.WriteLine("Lines are Collinear");
            }
            else
            {
                Console.WriteLine("Lines are not collinear");
            }

        }
    }
}
