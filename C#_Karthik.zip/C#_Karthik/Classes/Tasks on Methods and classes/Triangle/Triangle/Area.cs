﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Triangle
{
    public class Area
    {
        public static double b;
        public static double h;
        public static double a;

        public static double AreaCalc()
        {
            Console.WriteLine("\nFinding the Area of a Triangle");
            b = Values.BaseInputValues();
            h = Values.HeightInputValue();

            double area = 0.5 * b * h;
            Console.WriteLine("Area of a Triangle: " + area);
            a = area;
            return area;
        }
    }
}
