﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Triangle
{
    public class Weight
    {
        public static double WeightCalc()
        {
            Console.WriteLine("\nWeight Calculation");

            Console.Write("Enter density value of a Material: ");
            double d = Convert.ToDouble(Console.ReadLine());

            double w = d * Volume.v;
            Console.WriteLine("Weight of a Prism: " + w);
            return w;

        }
    }
}
