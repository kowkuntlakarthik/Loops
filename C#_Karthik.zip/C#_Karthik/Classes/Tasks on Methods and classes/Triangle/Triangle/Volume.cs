﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Triangle
{
    public class Volume
    {

        public static double v;
        
        public static double VolumeCalc()
        {
            Console.WriteLine("\nVolume Calculation");
            v = Calculatevol();
            

            Console.WriteLine("Volume of a Trianlge: " + v);
            return v;


        }
        public static double Calculatevol()
        {
            

            double vol = Area.a * Area.h;
   
            return vol;

        }
    }
}
