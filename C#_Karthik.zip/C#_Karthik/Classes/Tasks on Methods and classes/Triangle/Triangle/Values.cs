﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Triangle
{
    public class Values
    {
        public static double BaseInputValues()
        {
            Console.Write("Enter value of base: ");
            double tbase = Convert.ToDouble(Console.ReadLine());
            return tbase;

        }
        public static double HeightInputValue()
        {
            Console.Write("Enter value of height: ");
            double theight = Convert.ToDouble(Console.ReadLine());
            return theight;

        }
    }
}
