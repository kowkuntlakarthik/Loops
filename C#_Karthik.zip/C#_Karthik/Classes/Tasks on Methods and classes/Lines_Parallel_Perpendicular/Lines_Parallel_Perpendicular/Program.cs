﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lines_Parallel_Perpendicular
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Check the Lines are Parallel or Perpendicular");

            
            Console.Write("\nEnter value for x1: ");
            double x1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter value for y1: ");
            double y1 = Convert.ToDouble(Console.ReadLine());
            
            Console.Write("\nEnter value for x2: ");
            double x2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter value for y2: ");
            double y2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("\nEnter value for x3: ");
            double x3 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter value for y3: ");
            double y3 = Convert.ToDouble(Console.ReadLine());

            Console.Write("\nEnter value for x4: ");
            double x4 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter value for y4: ");
            double y4 = Convert.ToDouble(Console.ReadLine());

            double m1 = ((y2 - y1) / (x2 - x1));
            double m2 = ((y4 - y3) / (x4 - x3));

            if (m1 == m2)
            {
                Console.WriteLine("Lines are Parlle1");
            }
            else
            {
                Console.WriteLine("Lines are Perpendicular");
            }

        }
    }
}
