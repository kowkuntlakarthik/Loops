﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Square
{
    internal class Weight
    {
        public static double WeightCalc()
        {
            Console.WriteLine("\nWeight Calculation");
            Console.Write("Enter density of a Material: ");
            double d = Convert.ToDouble(Console.ReadLine());

            double w = d * Volume.v;
            Console.WriteLine("Weight of a cube: " + w);
            return w;
        }
    }
}
