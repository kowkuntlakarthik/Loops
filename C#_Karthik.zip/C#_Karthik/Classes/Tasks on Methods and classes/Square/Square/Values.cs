﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace Square
{
    public class Values
    {
        public static double InputValues()
        {
            
            Console.Write("\nEnter lenght of a Square: ");
            double len = Convert.ToDouble(Console.ReadLine());
            return len;
        }
    }
}
