﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;

namespace Square
{
    public class Volume
    {
        public static double v;
        public static double VolCalc()
        {
            Console.WriteLine("\nVolume calculation");
            v = CalcVolume();
            Console.WriteLine("Volume of a Cube: " + v);
            return v;

        }
        public static double CalcVolume()
        {
            double vol = Area.l * Area.l * Area.l;
            return vol;
        }
    }
}
