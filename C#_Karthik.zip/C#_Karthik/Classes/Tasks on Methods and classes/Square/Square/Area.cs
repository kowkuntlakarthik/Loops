﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Square
{
    
    public class Area
    {
        public static double l;
        public static double AreaCalc()
        {
            Console.WriteLine("Finding the Area of a Square");
            l = Values.InputValues();

            //Area
            double a = l * l;
            Console.WriteLine("\nArea of a Square: " + a);

            //Surface Area
            double sa = 6 * l * l;
            Console.WriteLine("Surface area of a cube: " + sa);

            return a;


        }

    }
}
