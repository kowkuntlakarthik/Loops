﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Square
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Area, Volume and Weight of a square cube");

            //Area
            Area.AreaCalc();

            //Volume
            Volume.VolCalc();

            //Weight
            Weight.WeightCalc();
        }
    }
}
