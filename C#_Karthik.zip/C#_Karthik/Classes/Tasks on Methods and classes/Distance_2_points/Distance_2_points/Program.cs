﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Distance_2_points
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Distance between two points");
            Console.Write("Enter value of x1: ");
            double x1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value of x2: ");
            double x2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value of y1: ");
            double y1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value of y2: ");
            double y2 = Convert.ToDouble(Console.ReadLine());

            double d = Math.Sqrt(((x2 - x1) * (x2 * x1)) + ((y2 - y1) * (y2 - y1)));
            Console.WriteLine("Distance between two points: " + d);
        }
    }
}
