﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rectangle
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Finding the Area, Volume and Weight of a Rectangle");
            Console.WriteLine();

            //Area
            Area objarea = new Area();
            objarea.Areacalc();

            //Volume
            //Volume objvol = new Volume();
            //objvol.Volcalc();
            Volume.Volcalc();


            //Weight
            Weight objweight = new Weight();
            objweight.Weightcalc();

            //Weight1 objweight1 = new Weight1();
            //objweight1.Weightcalc();

        }
    }
}
