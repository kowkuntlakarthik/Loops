﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Rectangle
{
    public class Weight
    {
         public const double g = 9.81;
        //public static double d = 7830.5;
        //public double v = Volume.calculatevol(); 
        public double Weightcalc()
        {
            Console.WriteLine("\nFinding the weight of a Rectangle");
            double mass = Mass();

            double weight = mass * g;
            Console.WriteLine("Weight of a Rectangle: " + weight);
            return weight;


        }

        public double Mass()
        {

            //Volume objvol = new Volume();
            //double v = Volume.Volcalc();
            //double mass = v * d;
            Console.Write("\nEnter density value of a Material: ");
            double d = Convert.ToDouble(Console.ReadLine());
         
            double mass = Volume.calculatevol() * d;

            //double mass = Volume.Volcalc() * d;
            return mass;
        }

    }
}
