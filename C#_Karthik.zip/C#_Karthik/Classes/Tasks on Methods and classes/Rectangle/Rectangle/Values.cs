﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rectangle
{
    public class Values
    {
        public double Lenght()
        {
            Console.Write("Enter value of Length in mm: ");
            double len = Convert.ToDouble(Console.ReadLine());
            return len;
        }

        public double Width()
        {
            Console.Write("Enter value of Width in mm: ");
            double wid = Convert.ToDouble(Console.ReadLine());
            return wid;
        }

        public double Height()
        {
            Console.Write("Enter value of Height in mm: ");
            double hei = Convert.ToDouble(Console.ReadLine());
            return hei;
        }
        

    }
}
