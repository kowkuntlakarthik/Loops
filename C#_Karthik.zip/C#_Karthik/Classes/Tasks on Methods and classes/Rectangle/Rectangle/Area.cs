﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rectangle
{
    public class Area
    {
        public static double l;
        public static double w;
        public static double h;

        public double Areacalc()
        {
            Console.WriteLine("Area Calculation");
            Values objarea = new Values();
            l = objarea.Lenght();
            w = objarea.Width();
            h = objarea.Height();

            double TSA = 2 * ((l * w) + (l * h) + (w * h));
            Console.WriteLine("Total surface Area of a Rectangle: " + TSA);

            double LSA = 2 * (h * (l + w));
            Console.WriteLine("Lateral surface area of a Rectangle: " + LSA);

            return TSA;


        }

    }
}
