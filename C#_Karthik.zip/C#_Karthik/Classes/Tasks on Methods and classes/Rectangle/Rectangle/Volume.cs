﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rectangle
{
    public class Volume
    {
        //public static double Volcalc()
        //{
        //    Console.WriteLine("\nFinding the Volume of a Rectangle");
            

        //    double vol = Area.l * Area.w * Area.h;
        //    Console.WriteLine("Volume of a Rectangle: " + vol);
        //    return vol;
        //}

        //Another method
        public static void Volcalc()
        {
            Console.WriteLine("\nFinding the Volume of a Rectangle");
            double v = calculatevol();
            Console.WriteLine("Volume of a Rectangle: " + v);


        }

        public static double calculatevol()
        {
            double volume = Area.l * Area.w * Area.h;
            return volume;
        }

    }
}
