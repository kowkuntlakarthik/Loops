﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Circle
{
    public class Values
    {
        public double value()
        {
            Console.Write("Enter the value of radius in mm: ");
            double radius = Convert.ToDouble(Console.ReadLine());
            return radius;
        }
    }
}
