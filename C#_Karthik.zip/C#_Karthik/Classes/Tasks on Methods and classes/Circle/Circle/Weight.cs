﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Circle
{
    public class Weight
    {

        public static double WeightCalc()
        {
            
            double d = Density();
            double w = d * Volume.volresult;
            Console.WriteLine("Weight of a Cylinder: " + w);
            return w;

        }
        public static double Density()
        {
            Console.Write("Enter Density of a Material: ");
            double density = Convert.ToDouble(Console.ReadLine());
            return density;
        }
    }
}
