﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Circle
{
    public class Volume
    {
        //Area objarea = new Area();
        public static double volresult;
        public static double volcalc()
        {
            Console.WriteLine("Finding the volume of a Circle");
            double v = calculatevol();
            
            //double volume = v * calculatevol();

            Console.WriteLine("\nVolume of a circle: " + v);
            volresult = v;
            return v;

        }
        public static double calculatevol()
        {

            Console.Write("\nEnter value of Height h: ");
            double h = Convert.ToDouble(Console.ReadLine());

            double vol = Area.rarea1 * h;
            return vol;


        }
    }
}
