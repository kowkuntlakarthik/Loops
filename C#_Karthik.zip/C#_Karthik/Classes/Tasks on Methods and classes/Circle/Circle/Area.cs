﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Circle
{
    public class Area
    {
        public static double r;
        public static double rarea1;

        public static double areacalc()
        {
            Console.WriteLine("Area of a Circle");

            Values objvalue = new Values();
            r = objvalue.value();

            double rarea = Math.PI * (r * r);
            Console.WriteLine("Area of a Circle: " + rarea);
            rarea1 = rarea;
            //return rarea;

            double rcircum = 2 * Math.PI * r;
            Console.WriteLine("Circumference of a Circle: " + rcircum);

            return rarea;
        }
    }
}
