﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midpoint_Two_points
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Finding the Midpoint from given input values");
            Console.Write("Enter value of x1: ");
            double x1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value of x2: ");
            double x2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value of y1: ");
            double y1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value of y2: ");
            double y2 = Convert.ToDouble(Console.ReadLine());

            //double m =  (((x1 + x2) / 2.0), ((y1 + y2) / 2.0));
            double x = ((x1 + x2) / 2);
            double y = ((y1 + y2) / 2);

            Console.WriteLine("Midpoint: " + (x , y));


        }
    }
}
