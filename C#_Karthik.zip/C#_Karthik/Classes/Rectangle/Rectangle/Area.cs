﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rectangle
{
    internal class Area
    {

        double l = 0.0;
        double w = 0.0;
        double h = 0.0;
        public void Areacalc()
        {
            //Console.Write("Enter Lenght, width, height: ");

            Console.Write("Enter Width: ");
            l = Convert.ToDouble(Console.ReadLine());
            w = Convert.ToDouble(Console.ReadLine());
            h = Convert.ToDouble(Console.ReadLine());

            //Console.Write("Enter Height: ");

            double TSA = 2 * ((l * w) + (l * h) * (w * h));
            Console.WriteLine("Total Surface Area: " + TSA);

            double LSA = 2 * (h * (l + w));
            Console.WriteLine("Lateral Surface area: " + LSA);

        }

        public double Volume()
        {
            
            double volume = l * w * h;
            Console.WriteLine("Volume of a Cuboid: " + volume);
            return volume;

        }

        public void Weight()
        {
            //Area objvol = new Area();

            //double vol = objvol.Volume();
            ////Console.WriteLine("volume: " + vol);
            double vol = l * w * h;
            Console.Write("Enter density value : ");
            double density = Convert.ToDouble(Console.ReadLine());
            double mass = vol * density;
            Console.WriteLine("Weight of a cuboid: " + mass);
        }

    }
}
