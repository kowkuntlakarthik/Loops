﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sample
{
    public class Volume
    {
        public static double h;
        public static void VolCalc()
        {
            Console.WriteLine("Finding the Volume of a circle");
            double vol = calculate();

            Console.WriteLine("Volume of a Circle: " + vol);

        }
        public static double calculate()
        {
            h = Value.InputValuesHeight();

            double v = Area.r * h;
            
            return v;

        }

    }
}
