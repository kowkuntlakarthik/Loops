﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sample
{
    public class Area
    {
        public static double r;
        
        public static void AreaCalc()
        {
            //Console.WriteLine("Finding the Area & Circumference of a Circle");
            r = Value.InputValuesRadius();

            double circlearea = Math.PI * r * r;
            Console.WriteLine("Area of a circle: " + circlearea);
            r = circlearea;

            double circumferencearea = 2 * Math.PI * r;
            Console.WriteLine("Circumference of a circle: " +  circumferencearea);
        }
    }
}
