﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sample
{
    public class Value
    {
        public static double InputValuesRadius()
        {
            Console.WriteLine("Enter vales");
            Console.Write("Enter Radius value: ");
            double radius = Convert.ToDouble(Console.ReadLine());
            return radius;
        }
        public static double InputValuesHeight()
        {
            Console.Write("\nEnter height h of a cylinder: ");
            double height = Convert.ToDouble(Console.ReadLine());
            return height;
        }
    }
}
