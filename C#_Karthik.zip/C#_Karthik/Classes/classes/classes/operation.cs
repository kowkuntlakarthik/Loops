﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes
{
    internal class operations
    {
        public int Addition(int value1, int value2)
        {
            int results = value1 + value2;
            return results;
            //Console.WriteLine("Addition result: " + results);
        }
        public int subtraction(int value1, int value2)
        {
            int subresults = value1 - value2;
            return subresults;
           // Console.WriteLine("Subtraction results: " + subresults);
        }
        public int multi(int value1, int value2)
        {
            int multiresults = value1 * value2;
            return multiresults;
            //Console.WriteLine("Multiplication results: " + multiresults);
        }
        public int div(int value1, int value2)
        {
            int divresults = value1 / value2;
            return divresults;
            //Console.WriteLine("Division result: " + divresults);
        }
    }
}
