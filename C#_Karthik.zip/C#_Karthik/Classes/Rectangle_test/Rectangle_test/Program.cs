﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rectangle_test
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Values of a Rectangle");

            ////object for Area
            Area objareacalc = new Area();
            objareacalc.Areacalc();

            //Volume
            Volume objvolcalc = new Volume();
            objvolcalc.Volcalc();
            

        }
    }
}
