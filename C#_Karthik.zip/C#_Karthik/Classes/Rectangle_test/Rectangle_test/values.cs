﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace Rectangle_test
{
    public class Values
    {
        public double Length()
        {
            Console.Write("Enter Value of Lenght: ");
            double Len = Convert.ToDouble(Console.ReadLine());
            return Len;
        }
        public double Width()
        {
            Console.Write("Enter Value of Width: ");
            double Wid = Convert.ToDouble(Console.ReadLine());
            return Wid;
        }
        public double Height()
        {
            Console.Write("Enter Value of Height: ");
            double Hei = Convert.ToDouble(Console.ReadLine());
            return Hei;
        }
        
        
    }
}
