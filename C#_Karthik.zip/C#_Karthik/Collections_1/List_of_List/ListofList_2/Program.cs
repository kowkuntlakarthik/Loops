﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace ListofList_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("List of List, by taking input values");

            List<List<int>> listoflist = new List<List<int>>();

            Console.Write("Enter value for list: ");
            int f1 = Convert.ToInt32(Console.ReadLine());



            for (int i = 0; i < f1; i++)
            {

               // if (i == 0 && i <= f1)
                {
                    List<int> firstlist = new List<int>();
                    Console.Write("Enter how many records to be stored in firstlist: ");
                    int r1 = Convert.ToInt32(Console.ReadLine());
                    for (int j = 0; j < r1; j++)
                    {

                        Console.Write("Enter the" + j + " value: ");
                        int fl1 = Convert.ToInt32(Console.ReadLine());
                        firstlist.Add(fl1);

                    }
                    listoflist.Add(firstlist);

                }
            }
                
                /*else if (i == 1 && i <= f1)
                {
                    List<int> secondlist = new List<int>();
                    Console.Write("Enter how many records to be stored in secondlist: ");
                    int r2 = Convert.ToInt32(Console.ReadLine());
                    for (int k = 0; k < r2; k++)
                    {

                        Console.Write("Enter the" + k + " value: ");
                        int sl1 = Convert.ToInt32(Console.ReadLine());

                    }
                    listoflist.Add(secondlist);
                } */
            /* else if (i == 2 && i <= f1)
             {
                 List<int> thirdlist = new List<int>();
                 Console.Write("Enter how many records to be stored in thirdlist: ");
                 int r3 = Convert.ToInt32(Console.ReadLine());
                 for (int l = 0; l < r3; l++)
                 {

                     Console.Write("Enter the" + l + " value: ");
                     int tl1 = Convert.ToInt32(Console.ReadLine());

                 }
                 listoflist.Add(thirdlist);
             }*/



             Console.WriteLine("Printing the values");
             //printing the values
             for (int m = 0; m < listoflist.Count; m++)
             {
                 List<int> listvalues = listoflist[m];
                 for (int n = 0; n < listvalues.Count; n++)
                 {
                     Console.WriteLine("\nprinting values: " + listvalues[n]);
                 }



             }

           /* Console.WriteLine("List of List");

            List<List<int>> listoflist = new List<List<int>>();

            Console.Write("Enter how many list has to be recorded: ");
            int listnumber = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < listnumber; i++)
            {
                List<int> primarylist = new List<int>();
                Console.Write("Enter the number of values to be store in " + (i + 1) + " list: ");
                int value = Convert.ToInt32(Console.ReadLine());
                for(int j = 0; j < value; j++)
                {
                    Console.Write("Enter the value of " + (j + 1) + " record for " + (i + 1) + " list: ");
                    int recordvalue = Convert.ToInt32(Console.ReadLine());
                    primarylist.Add(recordvalue);
                }
                listoflist.Add(primarylist);
            }

            Console.WriteLine("\nPrinting values");

            for(int k = 0; k < listoflist.Count; k++)
            {
                Console.WriteLine("\nPrinting values of " + (k + 1) + " list");
                List<int> secondarylist = listoflist[k];
                for (int l = 0; l < secondarylist.Count; l++)
                {
                    Console.WriteLine("Value " + (l + 1) + " : " + secondarylist[l]);
                }
            }
            
            */

        }

    }
}
