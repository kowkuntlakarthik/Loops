﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace List_of_List
{
    internal class Program                                         
    {
        static void Main(string[] args)
        {
            Console.WriteLine("List of List using User input values");

            List<List<int>> listoflist = new List<List<int>>();

            Console.Write("Enter how many lists to be add: ");
            int list = Convert.ToInt32(Console.ReadLine());

            for(int i = 0; i < list; i++)
            {
                List<int> multiplelist = new List<int>();
                Console.Write("Enter how many values to be record in " + (i + 1) + " list: ");
                int r1 = Convert.ToInt32(Console.ReadLine());
                for(int j = 0; j < r1; j++)
                {
                    Console.Write("Enter value for " + (j + 1) + " record for " + (i + 1) + " list: ");
                    int listrecord = Convert.ToInt32(Console.ReadLine());
                    multiplelist.Add(listrecord);
                }
                listoflist.Add(multiplelist);

            }

            Console.WriteLine("Printing the values");

            for (int k = 0; k < listoflist.Count; k++)
            {

                Console.WriteLine("\nPrinting the " + (k + 1) + " list values");
                List<int> listsecond = listoflist[k];
                for(int l = 0; l < listsecond.Count; l++)
                {
                    Console.WriteLine((l + 1) + " values: " + listsecond[l]);
                }
            }

 
        }
    }
}
