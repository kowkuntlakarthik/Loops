﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListofList_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("List of List");

            List<List<int>> listoflist = new List<List<int>>();
            List<int> dummy1 = new List<int>();
            List<int> dummy2 = new List<int>();
            List<int> dummy3 = new List<int>();

            dummy1.Add(10); dummy1.Add(20); dummy1.Add(30); dummy1.Add(40); dummy1.Add(50);
            dummy2.Add(60); dummy2.Add(70); dummy2.Add(80); dummy2.Add(90); dummy2.Add(100);
            dummy3.Add(110); dummy3.Add(120); dummy3.Add(130); dummy3.Add(140); dummy3.Add(150);

            listoflist.Add(dummy1);
            listoflist.Add(dummy2);
            listoflist.Add(dummy3);

            for(int i = 0; i < listoflist.Count; i++)
            {
                Console.WriteLine("dummy" + (i + 1) + " values");
                List<int> listoflistvalue2 = listoflist[i];
                for(int j = 0; j < listoflistvalue2.Count; j++)
                {
                    Console.WriteLine("values data: " + listoflistvalue2[j]);
                }
            }

        }
    }
}
