﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace List_of_Dictionary
{
    internal class Program
    {
        public static int key;
        public static double value;
        static void Main(string[] args)
        {
            Console.WriteLine("List of Dictionary");

            List<Dictionary<int, double>> listofdictionary = new List<Dictionary<int, double>>();

            Dictionary<int, double> dictionarykeyvalue = new Dictionary<int, double>();
            
            Console.Write("Enter how many records to store in dictionary: ");
            int count = Convert.ToInt32(Console.ReadLine());

            for(int i = 0; i < count; i++)
            {
                Console.Write("\nEnter " + (i + 1) + " Key number to assign value: ");
                key = Convert.ToInt32(Console.ReadLine());

                if (dictionarykeyvalue.ContainsKey(key))
                {
                    Console.WriteLine("Entered key " + i + " already exist.Please check and enter key number.");
                    i--;
                }

                Console.Write("Enter value for " + (i + 1) + " key: ");
                value = Convert.ToDouble(Console.ReadLine());

                dictionarykeyvalue[key] = value;

                
            }
            //dictionarykeyvalue.Add(key, value);
            //foreach loop
            foreach (var result in dictionarykeyvalue)
            {
                Console.WriteLine("value for Key " + result.Key + " is: " + result.Value);
            }

            ////forloop
            //for(int j = 0; j < dictionarykeyvalue.Count; j++)
            //{
            //    Console.WriteLine("value for Key " + (j + 1) + " is: " + dictionarykeyvalue.ElementAt(j));
            //}

            //priting value by taking input as key

            Console.Write("Enter the key number to find its value: ");
            int d = Convert.ToInt32(Console.ReadLine());

            if(dictionarykeyvalue.TryGetValue(d, out double searchkey))
            {
                if(dictionarykeyvalue.TryGetValue(key , out double value))
                {
                    Console.WriteLine("Value for the entered key " + d + " is: " + dictionarykeyvalue[d]);
                }
                   
            }
            else
            {
                Console.WriteLine("Entered Key " + d + " does not exist. Please check and enter key value again.");
            }


            Console.WriteLine("\nList of Dictionary");
            listofdictionary.Add(dictionarykeyvalue);
           
            for (int k = 0; k < listofdictionary.Count; k++)
            {
                Dictionary<int, double> dict = listofdictionary.ElementAt(k);
                foreach(var dicvalue in dict)
                {
                    Console.WriteLine("List of dictionary values: " + dicvalue);

                }

            }
            



        }
    }
}
