﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsStoring
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Collection Storing....
            //List of List // List of Dictionary // List Of Class // List of Structure..//Structure of List..

            List<List<int>> listOfListInterger = new List<List<int>>();

            List<int> dummy1 = new List<int>();
            List<int> dummy2 = new List<int>();
            List<int> dummy3 = new List<int>();

            dummy1.Add(10); dummy2.Add(50); dummy3.Add(20);
            dummy1.Add(20); dummy2.Add(60); dummy3.Add(250);
            dummy1.Add(30); dummy2.Add(70); dummy3.Add(350);
            dummy1.Add(40); dummy2.Add(80); dummy3.Add(440);
            dummy1.Add(50); dummy2.Add(90); dummy3.Add(540);
            dummy1.Add(60); dummy2.Add(20); dummy3.Add(640);

            listOfListInterger.Add(dummy1);
            listOfListInterger.Add(dummy2);
            listOfListInterger.Add(dummy3);

            for (int i = 0; i < listOfListInterger.Count; i++)
            {
                List<int> integerData = listOfListInterger[i];

                for (int j = 0; j < integerData.Count; j++)
                {
                    Console.WriteLine("Print the information about interger value : " + integerData[j]);
                }
            }

            ////List Of Dictionary...
            List<Dictionary<int, double>> listOfDictionaryInterger = new List<Dictionary<int, double>>();

            Dictionary<int, double> keyValuePairs1 = new Dictionary<int, double>();
            Dictionary<int, double> keyValuePairs2 = new Dictionary<int, double>();
            Dictionary<int, double> keyValuePairs3 = new Dictionary<int, double>();

            //Assembly
            //Model1,model1,Model1,model1,Model1,model1,Model1,model1,Model1,model1,Model1,model1,Model1,model1,Model1,model1,Model1,model1,Nomeculature..

            keyValuePairs1.Add(10, 2.03);

            if (!keyValuePairs1.ContainsKey(10))
            {
                keyValuePairs1.Add(10, 2.03);
            }
            if (!keyValuePairs1.ContainsKey(10))
            {
                keyValuePairs1.Add(30, 2.03);
            }
            if (!keyValuePairs1.ContainsKey(10))
            {
                keyValuePairs1.Add(40, 2.03);
            }


            keyValuePairs1.Add(50, 2.03);
            keyValuePairs1.Add(60, 2.083);
            keyValuePairs1.Add(70, 2.0355);
            keyValuePairs1.Add(80, 2.0553);

            keyValuePairs1.Add(90, 2.05553);
            keyValuePairs1.Add(100, 2.0355);
            keyValuePairs1.Add(110, 2.0553);
            keyValuePairs1.Add(102, 2.0553);


            listOfDictionaryInterger.Add(keyValuePairs1);
            listOfDictionaryInterger.Add(keyValuePairs2);
            listOfDictionaryInterger.Add(keyValuePairs3);


            for (int i = 0; i < listOfDictionaryInterger.Count; i++)
            {
                Dictionary<int, double> keyValuePairs = listOfDictionaryInterger[i];

            }
            foreach (var keyValItem in listOfDictionaryInterger)
            {
                Dictionary<int, double> keyValPair = keyValItem;

                foreach (var item in keyValPair)
                {
                    Console.WriteLine("Printing the Dictionary Info" + item.Key + "===>" + item.Value);
                }
            }

            //List of Classes...

            List<Sample> listOfClasses = new List<Sample>();

            Sample obj = new Sample();
            listOfClasses.Add(obj);

            for (int i = 0; i < listOfClasses.Count; i++)
            {
                Sample objSameleClass = listOfClasses[i];

                bool isCHecking = objSameleClass.isCheck;
                int objInt = objSameleClass.value1;
            }

        }
    }

    class Sample
    {
        public int value1 = 10;
        public double value2 = 10.5;
        public string word = "Kisohore";
        public List<String> strings = new List<String>();
        public Dictionary<int, int> keyValuePairs = new Dictionary<int, int>();
        public bool isCheck = false;
    }

}