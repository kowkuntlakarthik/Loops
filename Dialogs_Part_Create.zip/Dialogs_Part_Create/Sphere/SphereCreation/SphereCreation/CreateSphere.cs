﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;
using NXOpenUI;
using NXOpen.UF;
using NXOpen.Utilities;

namespace SphereCreation
{
    internal class CreateSphere
    {
        public static void SphereOperations(Point3d originPoint, double sphdia)
        {
            try
            {
                NXOpen.Session theSession = NXOpen.Session.GetSession();
                NXOpen.Part workPart = theSession.Parts.Work;
                NXOpen.Part displayPart = theSession.Parts.Display;

                NXOpen.Features.Sphere nullNXOpen_Features_Sphere = null;
                NXOpen.Features.SphereBuilder sphereBuilder1;
                sphereBuilder1 = workPart.Features.CreateSphereBuilder(nullNXOpen_Features_Sphere);

                NXOpen.Point coordinates = workPart.Points.CreatePoint(originPoint);

                sphereBuilder1.CenterPoint = coordinates;

                sphereBuilder1.Diameter.SetFormula(sphdia.ToString());

                NXOpen.NXObject nXObject1;
                nXObject1 = sphereBuilder1.Commit();

                sphereBuilder1.Destroy();
            }
            catch (Exception ex)
            {
                UI.GetUI().NXMessageBox.Show("Error in CreateCone Method ", NXMessageBox.DialogType.Error, ex.Message);
            }

        }
    }
}
