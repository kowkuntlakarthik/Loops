﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;
using NXOpen.CableRouter.Managed;
using NXOpen.CAE.Connections;

namespace DesignFeatures
{
    public class DesignFeatureCreation
    {
        public static void Block(Point3d boriginPoint, double blenght, double bwidth, double bheight)
        {
            try
            {

                NXOpen.Session theSession = NXOpen.Session.GetSession();
                NXOpen.Part workPart = theSession.Parts.Work;
                NXOpen.Part displayPart = theSession.Parts.Display;


                NXOpen.Features.Feature nullNXOpen_Features_Feature = null;
                NXOpen.Features.BlockFeatureBuilder blockFeatureBuilder1;
                blockFeatureBuilder1 = workPart.Features.CreateBlockFeatureBuilder(nullNXOpen_Features_Feature);

                DesignFeaturesUI blockdim = new DesignFeaturesUI();

                blockFeatureBuilder1.SetOriginAndLengths(boriginPoint, blenght.ToString(), bwidth.ToString(), bheight.ToString());

                NXOpen.Features.Feature feature1;
                feature1 = blockFeatureBuilder1.CommitFeature();

                blockFeatureBuilder1.Destroy();
            }
            catch (Exception ex)
            {
                UI.GetUI().NXMessageBox.Show("Error in Block Method ", NXMessageBox.DialogType.Error, ex.Message);
            }
        }
        public static void Cylinder(Vector3d cylvector, Point3d cyloriginPoint, double cyldiameter, double cylheight)
        {
            try
            {
                NXOpen.Session theSession = NXOpen.Session.GetSession();
                NXOpen.Part workPart = theSession.Parts.Work;
                NXOpen.Part displayPart = theSession.Parts.Display;

                NXOpen.Features.Cylinder nullNXOpen_Features_Cone = null;
                NXOpen.Features.CylinderBuilder cylinderBuilder1;
                cylinderBuilder1 = workPart.Features.CreateCylinderBuilder(nullNXOpen_Features_Cone);


                cylinderBuilder1.Diameter.SetFormula(cyldiameter.ToString());
                cylinderBuilder1.Height.SetFormula(cylheight.ToString());

                NXOpen.Direction direction = workPart.Directions.CreateDirection(cyloriginPoint, cylvector, SmartObject.UpdateOption.WithinModeling);

                cylinderBuilder1.Axis.Direction = direction;
                NXOpen.Axis axis1 = cylinderBuilder1.Axis;
                NXOpen.Point point2 = workPart.Points.CreatePoint(cyloriginPoint);

                axis1.Point = point2;

                NXOpen.NXObject nXObject1;
                nXObject1 = cylinderBuilder1.Commit();

                cylinderBuilder1.Destroy();
            }
            catch (Exception ex)
            {
                UI.GetUI().NXMessageBox.Show("Error in Cylinder Method ", NXMessageBox.DialogType.Error, ex.Message);

            }

        }
        public static void Cone(Vector3d conevector, Point3d coneoriginpoint, double conebasedia, double conetopdia, double coneheight)
        {
            try
            {
                NXOpen.Session theSession = NXOpen.Session.GetSession();
                NXOpen.Part workPart = theSession.Parts.Work;
                NXOpen.Part displayPart = theSession.Parts.Display;

                NXOpen.Features.Cone nullNXOpen_Features_Cone = null;
                NXOpen.Features.ConeBuilder coneBuilder1;
                coneBuilder1 = workPart.Features.CreateConeBuilder(nullNXOpen_Features_Cone);

                coneBuilder1.BaseDiameter.SetFormula(conebasedia.ToString());

                coneBuilder1.TopDiameter.SetFormula(conetopdia.ToString());
                coneBuilder1.Height.SetFormula(coneheight.ToString());
                //coneBuilder1.SetOriginAndLengths(originPoint, basedia, topdia, height);

                NXOpen.Direction direction = workPart.Directions.CreateDirection(coneoriginpoint, conevector, SmartObject.UpdateOption.WithinModeling);

                coneBuilder1.Axis.Direction = direction;
                NXOpen.Axis axis1 = coneBuilder1.Axis;
                NXOpen.Point point2 = workPart.Points.CreatePoint(coneoriginpoint);
                //point2 = workPart.Points.CreatePoint(originPoint);
                axis1.Point = point2;

                NXOpen.NXObject nXObject1;
                nXObject1 = coneBuilder1.Commit();

                coneBuilder1.Destroy();
            }


            catch (Exception ex)
            {

                UI.GetUI().NXMessageBox.Show("Error in Cone Method ", NXMessageBox.DialogType.Error, ex.Message);

            }

        }
        public static void Sphere(Point3d sphereoriginpoint, double spheredia)
        {
            try
            {
                NXOpen.Session theSession = NXOpen.Session.GetSession();
                NXOpen.Part workPart = theSession.Parts.Work;
                NXOpen.Part displayPart = theSession.Parts.Display;

                NXOpen.Features.Sphere nullNXOpen_Features_Sphere = null;
                NXOpen.Features.SphereBuilder sphereBuilder1;
                sphereBuilder1 = workPart.Features.CreateSphereBuilder(nullNXOpen_Features_Sphere);

                NXOpen.Point coordinates = workPart.Points.CreatePoint(sphereoriginpoint);

                sphereBuilder1.CenterPoint = coordinates;

                sphereBuilder1.Diameter.SetFormula(spheredia.ToString());

                NXOpen.NXObject nXObject1;
                nXObject1 = sphereBuilder1.Commit();

                sphereBuilder1.Destroy();
            }
            catch (Exception ex)
            {
                UI.GetUI().NXMessageBox.Show("Error in Sphere Method ", NXMessageBox.DialogType.Error, ex.Message);
            }

        }
    }
}
