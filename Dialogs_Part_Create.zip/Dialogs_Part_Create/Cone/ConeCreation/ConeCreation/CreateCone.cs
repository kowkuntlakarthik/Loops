﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen.CableRouter.Managed;
using NXOpen;

namespace ConeCreation
{
    internal class CreateCone
    {
        public static void ConeOperations(Vector3d vector3D, Point3d originPoint, double basedia, double topdia, double height)
        {
            try
            {
                NXOpen.Session theSession = NXOpen.Session.GetSession();
                NXOpen.Part workPart = theSession.Parts.Work;
                NXOpen.Part displayPart = theSession.Parts.Display;

                NXOpen.Features.Cone nullNXOpen_Features_Cone = null;
                NXOpen.Features.ConeBuilder coneBuilder1;
                coneBuilder1 = workPart.Features.CreateConeBuilder(nullNXOpen_Features_Cone);

                coneBuilder1.BaseDiameter.SetFormula(basedia.ToString());

                coneBuilder1.TopDiameter.SetFormula(topdia.ToString());
                coneBuilder1.Height.SetFormula(height.ToString());
                //coneBuilder1.SetOriginAndLengths(originPoint, basedia, topdia, height);

                NXOpen.Direction direction = workPart.Directions.CreateDirection(originPoint, vector3D, SmartObject.UpdateOption.WithinModeling);

                coneBuilder1.Axis.Direction = direction;
                NXOpen.Axis axis1 = coneBuilder1.Axis;
                NXOpen.Point point2 = workPart.Points.CreatePoint(originPoint);
                //point2 = workPart.Points.CreatePoint(originPoint);
                axis1.Point = point2;

                NXOpen.NXObject nXObject1;
                nXObject1 = coneBuilder1.Commit();

                coneBuilder1.Destroy();
            }


            catch (Exception ex)
            {
                
               UI.GetUI().NXMessageBox.Show("Error in Cone Operations Method ", NXMessageBox.DialogType.Error, ex.Message);
                
            }
            
        }
    }
}
