﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;

namespace CylinderCreation
{
    internal class CreateCylinder
    {
        public static void CylinderOperations(Vector3d vector3D, Point3d originPoint, double cyldiameter, double cylheight)
        {
            try
            {
                NXOpen.Session theSession = NXOpen.Session.GetSession();
                NXOpen.Part workPart = theSession.Parts.Work;
                NXOpen.Part displayPart = theSession.Parts.Display;

                NXOpen.Features.Cylinder nullNXOpen_Features_Cone = null;
                NXOpen.Features.CylinderBuilder cylinderBuilder1;
                cylinderBuilder1 = workPart.Features.CreateCylinderBuilder(nullNXOpen_Features_Cone);


                cylinderBuilder1.Diameter.SetFormula(cyldiameter.ToString());
                cylinderBuilder1.Height.SetFormula(cylheight.ToString());

                NXOpen.Direction direction = workPart.Directions.CreateDirection(originPoint, vector3D, SmartObject.UpdateOption.WithinModeling);

                cylinderBuilder1.Axis.Direction = direction;
                NXOpen.Axis axis1 = cylinderBuilder1.Axis;
                NXOpen.Point point2 = workPart.Points.CreatePoint(originPoint);

                axis1.Point = point2;

                NXOpen.NXObject nXObject1;
                nXObject1 = cylinderBuilder1.Commit();

                cylinderBuilder1.Destroy();
            }
            catch (Exception ex)
            {
                UI.GetUI().NXMessageBox.Show("Error in Cylinder Operations Method ", NXMessageBox.DialogType.Error, ex.Message);
            }

        }
    }
}
