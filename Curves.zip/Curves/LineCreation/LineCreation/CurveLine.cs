﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;

namespace LineCreation
{
    public class CurveLine
    {
        public static void Main(string[] args)
        {

           Session thesession = Session.GetSession();
           PartCollection thepartcollection = thesession.Parts;
           Part thepart = thepartcollection.Work;
            

            //Line 1
            Point3d startpoint = new Point3d(10, 20, 30);
            Point3d endpoint = new Point3d(50, 100, 150);

            Point stpoint = thepart.Points.CreatePoint(startpoint);
            Point edpoint = thepart.Points.CreatePoint(endpoint);

            stpoint.SetVisibility(SmartObject.VisibilityOption.Visible);
            edpoint.SetVisibility(SmartObject.VisibilityOption.Visible);

            Line theline = thepart.Curves.CreateLine(startpoint, endpoint);
            theline.SetVisibility(SmartObject.VisibilityOption.Visible);



            //Line 2
            Point3d startpoint1 = new Point3d(100, 150, 848);
            Point3d endpoint1 = new Point3d(88, 516, 455);



             Point stpoint1 = thepart.Points.CreatePoint(startpoint1);
             Point edpoint1 = thepart.Points.CreatePoint(endpoint1);

             stpoint1.SetVisibility(SmartObject.VisibilityOption.Visible);
             edpoint1.SetVisibility(SmartObject.VisibilityOption.Visible);


             Line theline1 = thepart.Curves.CreateLine(startpoint1, endpoint1);
             theline1.SetVisibility(SmartObject.VisibilityOption.Visible);


        }

        public static int GetUnloadOption(string arg)
        {
            //return System.Convert.ToInt32(Session.LibraryUnloadOption.Explicitly);
            return System.Convert.ToInt32(Session.LibraryUnloadOption.Immediately);
            // return System.Convert.ToInt32(Session.LibraryUnloadOption.AtTermination);
        }



    }
}
