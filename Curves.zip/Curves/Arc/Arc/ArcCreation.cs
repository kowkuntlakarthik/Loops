﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;
using NXOpen.Annotations;
using NXOpen.CAE;

namespace Arc
{
    public class ArcCreation
    {
        public static double radius;
        public static Point3d centerpoint;
        public static double startangle;
        public static double endangle;
        //public static NXMatrix matrix;
        public static void Main(string[] args)
        {
            Session thesession = Session.GetSession();
            PartCollection thepartcollection = thesession.Parts;
            Part theworkpart = thepartcollection.Work;

            radius = 50;
            centerpoint = new Point3d(150, 115, 180);
            startangle = 45;
            endangle = 275;
            //matrix = new NXMatrix(0, 1, 0);

            Vector3d vectorx = new Vector3d(1, 0, 0);
            Vector3d vectory = new Vector3d(0, 1, 0);
            
            
            NXOpen.Arc arc = theworkpart.Curves.CreateArc(centerpoint, vectorx, vectory, radius, startangle, endangle);


        }

        public static int GetUnloadOption(string arg)
        {
            //return System.Convert.ToInt32(Session.LibraryUnloadOption.Explicitly);
            return System.Convert.ToInt32(Session.LibraryUnloadOption.Immediately);
            // return System.Convert.ToInt32(Session.LibraryUnloadOption.AtTermination);
        }

    }
}
