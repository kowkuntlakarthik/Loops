﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using NXOpen;
using NXOpen.BlockStyler;
using static NXOpen.Motion.HydrodynamicBearingBuilder;

namespace BlockCreation
{
    internal class BlockJournalCode
    {
        public static void BlockCode(Point3d boriginPoint, double blenght, double bwidth, double bheight)
        {
            try
            {

                NXOpen.Session theSession = NXOpen.Session.GetSession();
                NXOpen.Part workPart = theSession.Parts.Work;
                NXOpen.Part displayPart = theSession.Parts.Display;


                NXOpen.Features.Feature nullNXOpen_Features_Feature = null;
                NXOpen.Features.BlockFeatureBuilder blockFeatureBuilder1;
                blockFeatureBuilder1 = workPart.Features.CreateBlockFeatureBuilder(nullNXOpen_Features_Feature);

                BlockUI blockdim = new BlockUI();

                blockFeatureBuilder1.SetOriginAndLengths(boriginPoint, blenght.ToString(), bwidth.ToString(), bheight.ToString());

                NXOpen.Features.Feature feature1;
                feature1 = blockFeatureBuilder1.CommitFeature();

                blockFeatureBuilder1.Destroy();
            }
            catch (Exception ex)
            {
                UI.GetUI().NXMessageBox.Show("Error in CreateBlock Method ", NXMessageBox.DialogType.Error, ex.Message);
            }
        }

        

        }
    }

