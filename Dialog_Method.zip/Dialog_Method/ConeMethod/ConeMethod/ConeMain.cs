﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;
using NXOpenUI;
using NXOpen.UF;
using NXOpen.Utilities;

namespace ConeMethod
{
    public class ConeMain
    {
        public static void Main(string[] args)
        {
            ConeCode.ConeMethodCode(new Vector3d(-1, 0, 0), new Point3d(-50, -500, -100), 50, 30, 60);
            
        }
    }
}
