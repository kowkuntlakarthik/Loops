﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;
using NXOpen.UF;
using NXOpenUI;
using NXOpen.Utilities;

namespace Block._500._600._800.wcs
{
    public class BlockCode
    {
        public static void Main(string[] args)
        {
            Code.CodeMethod();
        }

    }
}
