﻿/*
5 4 3 2 1
4 3 2 1
3 2 1
2 1 
1
*/
using System;

namespace dowhile3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number pattern 3");
            int i = 5;
            do
            {
                int j = i;
                do
                {
                    Console.Write(j + " ");
                    j--;
                }
                while (j >= 1);
                i--;
                Console.WriteLine();
            }
            while (i >= 1);
        }
    }
}