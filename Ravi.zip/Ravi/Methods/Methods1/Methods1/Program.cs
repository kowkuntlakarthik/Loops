﻿using System;

namespace methods1
{
    class Program
    {

        /*static void Addition(int value1, int value2)
        {
            int results = value1 + value2;
            Console.WriteLine("Addition result: " + results);
        }
        static void Main(string[] args)
        {
            Addition(10, 20);
            Addition(30, 40);
            Addition(50, 60);
            Addition(70, 80);
        }
        */
        static void Main(string[] args)
        {
            
            Program objprogram = new Program();
            objprogram.Addition(10, 20);
        }
        public void Addition(int value1, int value2)
        {
            int results = value1 + value2;
            Console.WriteLine("Addition results: " + results);
        }
        
    }
}