﻿using System;

namespace methods1
{
    class Program
    {

        //static void division(int value1, int value2)
        //{
        //    int results = value1 / value2;
        //    Console.WriteLine("Division result: " + results);
        //}
        //static void Main(string[] args)
        //{
        //    division(30, 2);
        //    division(50, 4);
        //    division(90, 6);
        //    division(50, 8);
        //}

        static void Main(string[] args)
        {

            Program objprogram = new Program();
            objprogram.Division(40, 20);
        }
        public void Division(int value1, int value2)
        {
            int results = value1 / value2;
            Console.WriteLine("Division results: " + results);
        }

    }
}