﻿/*
5 4 3 2 1
5 4 3 2
5 4 3
5 4
5
*/
using System;

namespace whileloop10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number pattern 10");
            int i = 1;
            while ( i <= 5)
            {
                int j = 5;
                while ( j >= i)
                {
                    Console.Write(j + " ");
                    j--;
                }
                Console.WriteLine();
                i++;
            }
        }
    }
}