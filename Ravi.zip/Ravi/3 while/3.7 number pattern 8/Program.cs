﻿/*
1 1 1 1 1
2 2 2 2
3 3 3
4 4
5
*/
using System;

namespace whileloop8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("number pattern 8");
            int i = 1;
            while (i <= 5)
            {
                int j = i;
                while (j <= 5)
                {
                    Console.Write(i + " ");
                    j++;
                }
                Console.WriteLine();
                i++;
            }
        }
    }
}
