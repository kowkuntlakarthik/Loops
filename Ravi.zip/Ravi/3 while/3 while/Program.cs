﻿/*
1 2 3 4 5
2 3 4 5
3 4 5
4 5
5 */

using System;

namespace whileloop1 
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("number pattern 1");
            int i = 1;
            while (i <= 5)
            {
                int j = i;
                while ( j <= 5)
                {
                    Console.Write(j + " ");
                    j++;
                }
                Console.WriteLine();
                i++;
            }
        }
    }
}