﻿/*
1
2 2
3 3 3
4 4 4 4
5 5 5 5 5
*/
using System;

namespace whileloop5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number pattern 5");
            int i = 1;
            while (i <= 5)
            {
                int j = 1;
                while (j <= i )
                {
                    Console.Write(i + " ");
                    j++;
                }
                Console.WriteLine();
                i++;
            }
        }
    }
}