﻿/*
5
5 4
5 4 3
5 4 3 2 
5 4 3 2 1
*/
using System;

namespace whileloop7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number pattern 7");
            int i = 5;
            while ( i >= 1)
            {
                int j = 5;
                while ( j >= i )
                {
                    Console.Write(j + " ");
                    j--;
                }
                Console.WriteLine();
                i--;
            }
        }
    }
}