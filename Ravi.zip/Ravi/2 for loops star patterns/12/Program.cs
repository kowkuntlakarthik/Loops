﻿/*
        *
       **
      ***
     ****
    *****
   ******
  *******
 ********
*********
 ********
  *******
   ******
    *****
     ****
      ***
       **
        * 
*/
using System;

namespace starpattern11
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Star pattern 12");
            for (int i = 1; i <= 9; i++)
            {
                for (int j = 1; j <= 9 - i; j++)
                {
                    Console.Write(" ");
                }
                for (int k = 1; k <= i; k++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
            for (int l = 8; l >= 1; l--)
            {
                for (int m = 1; m <= 9 - l; m++)
                {
                    Console.Write(" ");
                }
                for (int n = 1; n <= l; n++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }

        }
    }
}