﻿/*
********
 ********
  ********
   ********
    ********
     ********
      ********
       ******** */
using System;

namespace starpattern5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Star Pattern 5");
            for(int i = 1; i <= 8; i++)
            {
                for(int j = 1; j <= i - 1; j++)
                {
                    Console.Write(" ");
                }
                for (int k = 1; k <= 8; k++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }
    }
}