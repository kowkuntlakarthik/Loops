﻿/*
*
**
* *
*  *
*   *
*    *
*     *
*      *
*       *
**********
*/
using System;

namespace starpattern10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Star pattern 10");
            Console.WriteLine("*");
            for(int i = 0; i < 7; i++)
            {
                Console.Write("*");
                for(int j = 1; j < 1+i; j++)
                {
                    Console.Write(" ");
                }
                Console.Write("*");
                Console.WriteLine();
            }
            
            for(int k = 0; k <=8; k++)
            {
                Console.Write("*");
            }

        }
    }
}