﻿/*
*******
*     *
*     *
*     *
*     *
*     *
*******
*/
using System;

namespace starpattern6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Star pattern 6");
            for(int i =1; i < 8; i++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
            for(int j = 1; j <= 5; j++)
            {
                for(int k = 1; k <= 1; k++)
                {
                    Console.Write("*     *");
                }
                Console.WriteLine();
            }
            for (int i = 1; i < 8; i++)
            {
                Console.Write("*");
            }
        }
    }
}