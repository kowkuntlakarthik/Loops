﻿/*     *
      **
     ***
    ****
   *****
  ******
 *******
******** */

using System;

namespace starpattern4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Star Patterns 4");
            
            for (int i = 1; i <= 8; i++)
            {
                for (int j = 1; j <= 8 - i; j++)
                {
                    Console.Write(" ");
                }
                for (int k = 1; k <= i; k++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
            
        }
    }
}