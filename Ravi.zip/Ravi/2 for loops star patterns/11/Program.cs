﻿/*

     *
    * *
   *   *
  *     *
 *       *
***********
*/



using System;

namespace starpattern11
{
     class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Star pattern 11");
            for(int i = 1; i<= 8; i++)
            {
                
            }
        }
    }
}