﻿
/*
 ********
  *******
   ******
    *****
     ****
      ***
       **
        * 
*/
using System;

namespace starpattern11
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("star pattern");
          
            for(int l = 8; l >= 1; l--)
            {
                for(int m = 1; m <= 9 - l; m++)
                {
                    Console.Write(" ");
                }
                for(int n = 1; n <= l; n++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
            
        }
    }
}