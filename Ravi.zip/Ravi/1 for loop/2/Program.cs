﻿using System;

namespace forloops2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("For loop");
            for (int i = 1; i <= 5; i++)
            {
                for(int j = 1; j <= 6-i; j++)
                {
                    Console.Write(j + " ");
                }
                Console.WriteLine();
            }

        }
    }
}

/*1 2 3 4 5

1 2 3 4

1 2 3

1 2

1*/