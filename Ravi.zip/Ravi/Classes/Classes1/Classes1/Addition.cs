﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes1
{
    internal class Addition
    {
        public int Add(int value1, int value2)
        {
            int addresult = value1 + value2;
            return addresult;
        }
    }
}
