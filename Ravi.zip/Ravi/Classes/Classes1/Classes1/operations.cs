﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes1
{
    internal class Operations
    {
        public void Opera()
        {

            //Addition
            Addition objadd = new Addition();
            int objaddresult = objadd.Add(10, 20);
            Console.WriteLine("\nAddition result = " + objaddresult);

            //Subtraction
            subtraction objsub = new subtraction();
            int objsubresult = objsub.sub(objaddresult, 20);
            Console.WriteLine("\nSubtraction result: " + objsubresult);

            //Multiplication
            Multiplcation objmul = new Multiplcation();
            int objmulresult = objmul.Multi(objsubresult, 18);
            Console.WriteLine("\nMultiplication result: " + objmulresult);

            //Division
            Division objdiv = new Division();
            int objdivresult = objdiv.Div(objmulresult, 4);
            Console.WriteLine("\nDivision result: " + objdivresult);

        }
    }
}
