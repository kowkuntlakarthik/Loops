﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes1
{
    internal class Multiplcation
    {
        public int Multi(int value1, int value2)
        {
            int multiresult = value1 * value2;
            return multiresult;
        }
    }
}
