﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            {
                Console.WriteLine("Classes");
                operations objAddition = new operations();
                int Addresult = objAddition.Addition(10, 20);
                Console.WriteLine("Addition result: " + Addresult);

                //subtraction
                operations objsubtraction = new operations();
                int subresult = objsubtraction.subtraction(Addresult, 5);
                Console.WriteLine("Subtraction result: " + subresult);

                //Multiplication
                operations objmulti = new operations();
                int multiresult = objmulti.multi(Addresult, subresult);
                Console.WriteLine("Multiplication result: " + multiresult);

                //Division
                operations objdiv = new operations();
                int divresult = objdiv.div(multiresult, 5);
                Console.WriteLine("Division result: " + divresult);


            }
        }
    }
}
