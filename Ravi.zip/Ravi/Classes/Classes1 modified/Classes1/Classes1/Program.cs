﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes1
{
    internal class Program
    {
        //static void Main(string[] args)
        public void Main(string[] args)
        {
            Console.WriteLine("Mathematical operations");
            Operations objops = new Operations();
            objops.Opera();
            //Opera();
        }
    }
}
