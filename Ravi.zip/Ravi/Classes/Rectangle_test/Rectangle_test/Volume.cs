﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Rectangle_test
{
    public class Volume
    {
        public double Volcalc()
        {

            //Values objvalue = new Values();
            //double l = objvalue.Length();
            //double w = objvalue.Width();
            //double h = objvalue.Height();

            //Area objareacalc = new Area();

            double volume = Area.l * Area.w * Area.h;
            Console.WriteLine("Volume: " + volume);
            //return volume;
            //Area objareacalc = new Area();
            //double vol = objareacalc.volumecalc();

            return volume;



        }
    }
}
