﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rectangle_test
{
    public class Area
    {
        public static double l;
        public static double w;
        public static double h;
        public double Areacalc()
        {
            Values objvalue = new Values();
            /*double */l = objvalue.Length();
            /*double */w = objvalue.Width();
            /*double */h = objvalue.Height();
           
            //Console.Write("Enter Lenght: ");
            //double l = Convert.ToDouble(Console.ReadLine());
            //Console.Write("Enter Width: ");
            //double w = Convert.ToDouble(Console.ReadLine());
            //Console.Write("Enter Height: ");
            //double h = Convert.ToDouble(Console.ReadLine());

            double TSA = 2 * ((l * w) + (l * h) + (w * h));
            Console.WriteLine("Total Surface Area: " + TSA);

            
            double LSA = 2 * (h * (l + w));
            Console.WriteLine("Lateral Surface area: " + LSA);

            return TSA;

        }
        //public double volumecalc()
        //{
        //    double volresult = l * w * h;
        //    Console.WriteLine("Volume: " + volresult);
        //    return volresult;

        //}
        

    }
}
