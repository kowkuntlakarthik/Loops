﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rectangle
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Area of a cuboid");
            Console.Write("Enter Lenght, width, height: ");
            //double l = Convert.ToDouble(Console.ReadLine());
            //double w = Convert.ToDouble(Console.ReadLine());
            //double h = Convert.ToDouble(Console.ReadLine());


            //Area
            Area objarea = new Area();
            objarea.Areacalc();
            objarea.Volume();
            objarea.Weight();
        }
    }
}

