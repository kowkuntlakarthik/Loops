﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("If statements");
            Console.Write("Enter value of x: ");
            double x = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value of y: ");
            double y = Convert.ToDouble(Console.ReadLine());
            if (x > y)
            {
                Console.WriteLine("X is grater than y");
            }
            else if (x < y)
            {
                Console.WriteLine("Y is greater than X");
            }
            else
            {
                Console.WriteLine("X and Y values are same");
            }
        }
    }
}
