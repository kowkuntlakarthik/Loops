﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dowhile
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Do While");
            Console.Write("Enter value: ");
            int i = Convert.ToInt32(Console.ReadLine());
            do
            {
                Console.WriteLine(i);
                i++;
            }
            while (i <= 5);
        }
    }
}
