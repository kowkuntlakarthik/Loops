﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Pattern");
            //int i = 1;
            for (int j = 0; j <= 5; j++)
            {
                for (int k = 1; k <= 5; k++)
                {
                    Console.Write((j + k)+ " ");
                    //i++;
                }
                Console.WriteLine();
            }
        }
    }
}
