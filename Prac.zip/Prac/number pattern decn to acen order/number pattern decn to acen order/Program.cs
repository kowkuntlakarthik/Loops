﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace number_pattern_decn_to_acen_order
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Printing numbers from decending order to ascending order");
            for(int i = 5; i >= 1; i--)
            {
                for(int j = 5; j >= 1; j--)
                {
                    Console.Write(j + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
