﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("For Loop");
            for (int i = 0; i <= 20; i++)
            {
                Console.WriteLine(i);
            }
            for (int i = 0; i <= 20; i++)
            {
                Console.Write(" " + i);
            }
        }
    }
}
