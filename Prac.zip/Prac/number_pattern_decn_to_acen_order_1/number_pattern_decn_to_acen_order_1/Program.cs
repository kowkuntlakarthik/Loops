﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace number_pattern_decn_to_acen_order_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Printing numbers from 20 to 1");
            /*for (int i = 0; i >= 4; i--)
            {
                for (int j = 20; j > 0; j--)
                {
                    Console.Write((j) + " ");
                }
                Console.WriteLine();
            }*/
            int i = 20;
            for (int j = 0; j < 4; j++)
            {
                for(int k = 0; k < 5; k++)
                {
                    Console.Write(i + " ");
                    i--;
                }
                Console.WriteLine();
            }
            
        }
    }
}
