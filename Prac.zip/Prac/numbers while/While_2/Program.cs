﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace While_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("While_2");
            int i = 20;
            while (i >= 1)
            {
                Console.Write(i + " ");
                if(i % 5 == 1)
                {
                    Console.WriteLine();
                }
                i--;
            }
            
            

        }
    }
}
