﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace While_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Printing stars in Pyramid format");
            int i = 5;
            int j = 1;
            while (j <= i)
            {
                int k = 1;
                
                while(k <= i - 1)
                {
                    Console.Write(" ");
                    k++;
                }
                int m = 1;
                    while (m <= i)
                    {
                        Console.Write("* ");
                        m++;
                    }
                
                Console.WriteLine();
                j++;
            }    

        }
    }
}
