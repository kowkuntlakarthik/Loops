﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace While_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("While loop");
            int i = 0;
            while (i <= 20)
            {
                Console.Write(i + " ");
                if (i % 5 == 0)
                {
                    Console.WriteLine();
                }
                i++;
            
            }
        }
    }
}
