﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace While_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Printing Stars");
            int i = 5;
            int j = 1;
            while (j <= i)
            {
                int k = 1;
                while (k <= j)
                {
                    Console.Write("* ");
                    k++;
                }
                Console.WriteLine();
                j++;

            }
           
        }
    }
}
