﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace While_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Pattern");
            //int i = 20;
            //while (i >= 1)
            //{
            //    Console.Write(i + " ");
            //    if(i % 5 == 1)
            //    {
            //        Console.WriteLine();

            //    }

            //    i--;
            //int rows = 5;
            //int row = 1;

            //while (row <= rows)
            //{
            //    int startNumber = 20 - (row - 1); // Starting number for the current row
            //    int col = 1;

            //    while (col <= 5)
            //    {
            //        Console.Write(startNumber - (col - 1) + " ");
            //        col++;
            //    }
            //    Console.WriteLine(); // Move to the next line after each row
            //    row++;
            int i = 5;
            int j = 1;
            while ( j <= i)
            {
                int k = 20 - (j - 1);
                int l = 1;
                while (l <= 5)
                {
                    Console.Write(k - (l - 1) + " ");
                    l++;
                }
                Console.WriteLine();
                j++;
            }

        }
    }
}
