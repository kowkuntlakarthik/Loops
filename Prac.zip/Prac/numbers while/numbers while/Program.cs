﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;

namespace numbers_while
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Printing numbers using while");
            Console.Write("Enter i value: ");
            int i = Convert.ToInt32(Console.ReadLine());
            while (i <= 10)
            {
                Console.Write(i + " ");
                i++;
            }
        }
    }
}
