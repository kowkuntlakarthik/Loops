﻿using System;

namespace stringoperations
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("String operations");
            Console.Write("Enter fname: ");
            string fname = Console.ReadLine();
            Console.Write("Enter lname: ");
            string lname = Console.ReadLine();
            string fullname = fname + lname;
            Console.WriteLine("Full name: " + fullname);
            Console.WriteLine("\nFull name with two variables: " + fname + " " + lname);
            Console.WriteLine("String Length");
            Console.WriteLine("fname string length: " + fname.Length);
            Console.WriteLine("lname string lenght: " + lname.Length);
            Console.WriteLine("full name string lenght: " + fullname.Length);
            Console.WriteLine("\nUpper case letters: " + fullname.ToUpper());
            Console.WriteLine("\nLower case letters: " + fullname.ToLower());
            Console.WriteLine("\nString Concatenation");
            Console.WriteLine("Full name: " + string.Concat(fname, lname));
            Console.WriteLine("Full name: " + string.Concat(fullname));
            Console.WriteLine();
            Console.WriteLine("String Interpolation");
            string sinterpolation = $"Entered person name: {fname} {lname}";
            Console.WriteLine("String interpolation: " + sinterpolation); 
            Console.WriteLine("Access string");
            Console.Write("\nEnter index number to find the character: ");
            int charindex = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("character position in the fname index position: " + fname[charindex]);
            Console.Write("\nEnter index number to find the character: ");
            int charindex1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Character position in the lname index position: " + lname[charindex1]);
            Console.Write("\nEnter index number to find the character: ");
            int charindex2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Character position in the fullname index position: " + fullname[charindex2]);
            Console.WriteLine();
            Console.Write("Enter character to find char index number: ");
            char letterindex = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("index position in fname: " + fname.IndexOf(letterindex));
            Console.Write("Enter character to find char index number: ");
            char letterindex1 = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("index position in lname: " + lname.IndexOf(letterindex1));
            Console.Write("Enter character to find char index number: ");
            char letterindex2 = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("index position in fullname: " + fullname.IndexOf(letterindex2));
            Console.WriteLine();
            Console.WriteLine("Special characters");
            string txt = "Hello \'K\' Hi";
            Console.WriteLine(txt);
            string txt1 = "Hello \"Karthik\" Hi";
            Console.WriteLine(txt1);
            string txt2 = "Hello \\Kowkuntla\\ Hi";
            Console.WriteLine(txt2);

            
        }
    }
}