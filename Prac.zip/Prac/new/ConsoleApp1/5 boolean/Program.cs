﻿using System;

namespace booleanoperations
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Boolean Operations");
            Console.Write("Enter value of x: ");
            double x = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter valoe of y: ");
            double y = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("bool result for > operator: " + (x > y));
            Console.WriteLine("bool result for < operator: " + (x < y));
            Console.WriteLine("bool result for == operator: " + (x == y));
            Console.WriteLine("bool result for != operator: " + (x != y));
            Console.WriteLine("bool result for >= operator: " + (x >= y));
            Console.WriteLine("bool result for <= operaotr: " + (x <= y));

        }
    }
}