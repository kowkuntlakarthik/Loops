﻿using System;
using System.Security.Cryptography.X509Certificates;

namespace helloworld
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Console.WriteLine("Variables");
            const int a = 1;
            //a = 2;
            //a = 3;
            Console.WriteLine("Integer value: " + a);
            Console.WriteLine(a);
            const double b = 2.1256976545d;
            //b = 4.4095d;
            Console.WriteLine("Double value: " + b);
            Console.WriteLine(b);
            char c = 'c';
            Console.WriteLine("Char value: " + c);
            Console.WriteLine(c);
            string d = "String";
            Console.WriteLine("String value: " + d);
            Console.WriteLine(d);
            bool e = true;
            Console.WriteLine("Boolean value: " + e);
            Console.WriteLine(e);        */
            /*Console.WriteLine("Display Variables");
            string fname = "Karthik ";
            String sname = "Kowkuntla";
            string fullname = fname + sname;
            Console.WriteLine(fullname);
            Console.WriteLine("Person name: " + fname + sname);*
            int a =1, b =2, c =3;
            Console.WriteLine(a + b + c);
            string d = "Karthik ", e = "Kowkuntla";
            Console.WriteLine(d + e);
            double f = 1.4095d, g = 2.4095d, h = 3.4095d; 
            Console.WriteLine(f + g + h);*/
            Console.WriteLine("Type casting");
            Console.Write("Enter ingteger value: ");
            int myint = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Integer value: " + myint);
            Console.WriteLine();
            Console.Write("Enter decimal value: ");
            double mydouble = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Decimal value: " + mydouble.ToString("00.000"));
            Console.WriteLine();
            Console.Write("Enter character: ");
            char mychar = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("Character value: " + mychar);
            Console.WriteLine();
            Console.Write("Enter string value: ");
            string mystring = Console.ReadLine();
            Console.WriteLine("String details: " + mystring);
            Console.WriteLine();
            Console.Write("Enter bool value: ");
            bool mybool = Convert.ToBoolean(Console.ReadLine());
            Console.WriteLine("Boolean value: " + mybool);

        }

    }
}