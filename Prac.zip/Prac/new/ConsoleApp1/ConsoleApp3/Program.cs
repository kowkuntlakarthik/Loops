﻿using System;

namespace mathoperations
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Math operations");
            Console.Write("Enter Value of x: ");
            double x = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value of y: ");
            double y = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("Maximum number: " + Math.Max(x, y));
            Console.WriteLine("Minimum number: " + Math.Min(x, y));
            Console.WriteLine("Square root of x: " + Math.Sqrt(x));
            Console.WriteLine("Square root of y: " + Math.Sqrt(y));
            Console.WriteLine("Absolute value of x: " + Math.Abs(x));
            Console.WriteLine("Absolute value of y: " + Math.Abs(y));
            Console.WriteLine("Round value of x: " + Math.Round(x));
            Console.WriteLine("Round value of y: " + Math.Round(y));

        }
    }
}