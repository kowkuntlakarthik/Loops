﻿using System;

namespace solution2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("operators");
            Console.WriteLine("Arthimatic operators");
            Console.Write("Enter value of x: ");
            double x = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value of y: ");
            double y = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value of a: ");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter value of b: ");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(" + operator: " + (x + y));
            Console.WriteLine(" - operator: " + (x - y));
            Console.WriteLine(" * operator: " + (x * y));
            Console.WriteLine(" / operator: " + (x / y));
            Console.WriteLine(" % operator: " + (x % y));
            Console.WriteLine("++ operator: " + ++x);
            Console.WriteLine("-- operator: " + --y);
            Console.WriteLine();
            Console.WriteLine("Assignment operator");
            Console.WriteLine("= operator: " + (x = y));
            Console.WriteLine("+= operator: " + (x += y));
            Console.WriteLine("-= operator: " + (x -= y));
            Console.WriteLine("*= operator: " + (x *= y));
            Console.WriteLine("/= operator: " + (x /= y));
            Console.WriteLine("= operator: " + (x %= y));
            Console.WriteLine("&= operator: " + (a &= b));
            Console.WriteLine("|= operator: " + (a |= b));
            Console.WriteLine("^= operator: " + (a ^= b));
            Console.WriteLine(">>= operator: " + (a >>= b));
            Console.WriteLine("<<= operator: " + (a <<= b));
            Console.WriteLine();
            Console.WriteLine("Comparison operator");
            Console.WriteLine("== operator: " + (x == y));
            Console.WriteLine("!= operator: " + (x != y));
            Console.WriteLine("> operator: " + (x > y));
            Console.WriteLine("< operator: " + (x < y));
            Console.WriteLine(">= operator: " + (x >= y));
            Console.WriteLine("<= operator: " + (x <= y));
            Console.WriteLine();
            Console.WriteLine("Logical operatoe");
            Console.WriteLine("&& operator: " + (x < a && y > b));
            Console.WriteLine("|| operator: " + (x < a || y > b));
            Console.WriteLine("! && operator: " + !(x < a && y > b));
            Console.WriteLine("! || operator: " + (x < a || y > b));
        }
    }
}