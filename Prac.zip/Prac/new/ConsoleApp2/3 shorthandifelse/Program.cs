﻿using System;

namespace shorthandifelse
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Shorthand if else statemant");
            Console.Write("Enter value of x: ");
            double x = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value of y: ");
            double y = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();
            string z = (x > y) ? "x is greater than y" : "x is less than y";
            Console.WriteLine("Result: " + z);
        }
    }
}
