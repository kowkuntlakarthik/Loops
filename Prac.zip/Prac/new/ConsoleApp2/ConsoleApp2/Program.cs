﻿using System;

namespace ifstatements
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("if statements");
            Console.Write("Enter value of x: ");
            double x = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value of y: ");
            double y = Convert.ToDouble(Console.ReadLine());
            if (x > y)
            {
                Console.WriteLine("x is greater than y");
            }
            else
            {
                Console.WriteLine("x is less than y");
            }
            

        }
    }
}