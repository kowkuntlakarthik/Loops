﻿using System;

namespace elseifstatements
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("elseif statements");
            Console.Write("\nEnter Value of x: ");
            double x = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value of y: ");
            double y = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine(" value: " + y);
            if(x > y)
            {
                Console.WriteLine("\nx is greater than y");
            }
            else if(x == y)
            {
                Console.WriteLine("\nx is equals to y");
            }
            else
            {
                Console.WriteLine("\nx is less than y");
            }
        }
    }
}