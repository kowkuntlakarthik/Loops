﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for_Loop2_even
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Even numbers");
            for (int i = 0; i <= 100; i = i + 2)
            {
                Console.Write(" " + i);
            }

            Console.Write("\nEnter value: ");
            int j = Convert.ToInt32(Console.ReadLine());
            for (int k = j; k <= 100; k = k + j)
            {
                Console.WriteLine(k);
            }
        }
    }
}
