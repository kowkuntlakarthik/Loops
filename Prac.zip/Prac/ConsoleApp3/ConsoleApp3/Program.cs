﻿using System;

namespace operators
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Operators");
            Console.Write("Enter value of x: ");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter value of y: ");
            int y = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\nArthimatic operators");
            Console.WriteLine(x + y);
            Console.WriteLine(x - y);
            Console.WriteLine(x * y);
            Console.WriteLine(x / y);
            Console.WriteLine(x % y);

            Console.WriteLine("\nAssignment operators");
            Console.WriteLine(x += 5);
            Console.WriteLine(y -= 10);
            Console.WriteLine(x *= 5);
            Console.WriteLine(y /= 10);
            Console.WriteLine(x %= y);
            Console.WriteLine(x &= 20);
            Console.WriteLine(y |= 10);
            Console.WriteLine(x ^= y);
            Console.WriteLine(x >>= y);
            Console.WriteLine(x <<= y);

            Console.WriteLine("\nComparison operator");
            Console.WriteLine(x == y);
            Console.WriteLine(x != y);
            Console.WriteLine(x > y);
            Console.WriteLine(x < y);
            Console.WriteLine(x >= y);
            Console.WriteLine(x <= y);

            Console.WriteLine("\nLogical operators");
            Console.WriteLine(x < 10 && y > 20);
            Console.WriteLine(x < 10 || y > 20);
            Console.WriteLine(!(x < 10 && y > 20));
            Console.WriteLine(!(x < 10 || y > 20));


        }
    }
}