﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pattern_numbers_des_to_asc
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("pattern in reverse");
            int i = 20;
            for(int j = 0; j < 4; j++)
            {
                for(int k = 0; k <= 4; k++)
                {
                    Console.Write((i - k) + " ");
                }
                i--;
                Console.WriteLine();
            }
            
        }
    }
}
