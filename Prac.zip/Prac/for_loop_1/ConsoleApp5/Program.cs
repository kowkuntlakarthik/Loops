﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Printing odd numbers");

            for (int k = 1; k <= 20; k = k + 2 )
            {
                Console.WriteLine(k);
            }
            Console.Write("Enter value: ");
            int m = Convert.ToInt32(Console.ReadLine());
            for (int n = m; n <= 100; n = n + 2)
            {
                Console.Write(" " + n);
            }

            

        }
    }
}
