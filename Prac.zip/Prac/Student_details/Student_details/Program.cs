﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_details
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Student details");
            //Student name
            Console.Write("Enter Student Name: ");
            string sname = Console.ReadLine();
            //Age
            Console.Write("Enter Age: ");
            int sage = Convert.ToInt32(Console.ReadLine());
            //Class
            Console.Write("Enter Class: ");
            string sclass = Console.ReadLine();
            //Roll Number
            Console.Write("Enter Roll number: ");
            string sroll = Console.ReadLine();
            //Assessment test
            Console.Write("Enter Assessment test: ");
            String sexam = Console.ReadLine();
            //Marks
            Console.Write("Marks in Telugu: ");
            double telugu = Convert.ToDouble(Console.ReadLine());
            Console.Write("Marks in Hindi: ");
            double hindi = Convert.ToDouble(Console.ReadLine());
            Console.Write("Marks in English: ");
            double english = Convert.ToDouble(Console.ReadLine());
            Console.Write("Marks in Maths: ");
            double maths = Convert.ToDouble(Console.ReadLine());
            Console.Write("Marks in Science: ");
            double science = Convert.ToDouble(Console.ReadLine());
            Console.Write("Marks in Social: ");
            double social = Convert.ToDouble(Console.ReadLine());
            //percent calculation
            
            double total = telugu + hindi + english + maths + science + social;
            Console.WriteLine("Obtained marks: " + total);
            const int totalm = 600;
            Console.WriteLine("Toal marls: " + totalm);
            double percent = (total / totalm) * 100;
            Console.WriteLine("Percentage: " + percent.ToString("00.00"));
            //Grade
            if (percent >= 75)
            {
                Console.WriteLine(sname + " Secured DISTINCTION with " + percent.ToString("00.00") + "% in " + sclass + "class");
            }
            else if (percent >= 60)
            {
                Console.WriteLine(sname + " Secured FIRST CLASS with " + percent.ToString("00.00") + "% in " + sclass + "class");
            }
            else if (percent >= 45)
            {
                Console.WriteLine(sname + " Secured SECOND CLASS with " + percent.ToString("00.00") + "% in " + sclass + "class");
            }
            else if (percent >= 35)
            {
                Console.WriteLine(sname + " Secured THIRD CLASS with " + percent.ToString("00.00") + "% in " + sclass + "class");
            }
            else if (percent >= 20)
            {
                Console.WriteLine(sname + " Secured FOURTH CLASS with " + percent.ToString("00.00") + "% in " + sclass + "class");
            }
            else
            {
                Console.WriteLine(sname + " did not secured passing marks, secured " + percent.ToString("00.00") + "% in " + sclass + "class");
            }


        }
    }
}
