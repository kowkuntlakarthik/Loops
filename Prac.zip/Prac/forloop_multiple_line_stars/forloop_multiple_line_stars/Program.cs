﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forloop_multiple_line_stars
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Printing Stars");
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                   
                        Console.Write("*");
                    
                }
                Console.WriteLine();
            }
        }
    }
}
