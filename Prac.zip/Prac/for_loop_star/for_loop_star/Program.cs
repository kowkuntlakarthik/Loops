﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for_loop_star
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Print stars");
            for (int i = 0; i < 5; i++)
            {

                Console.Write("* ");

            }

            Console.WriteLine("\nvertical");
            for (int j = 0; j < 5; j++)
            {
                Console.WriteLine("* ");
            }
        }
    }
}
