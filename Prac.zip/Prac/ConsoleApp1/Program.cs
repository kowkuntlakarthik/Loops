﻿using System;

namespace datatypes
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Data Types");
            int myint = 10;
            Console.WriteLine(myint);
            long mylong = 1445616516561561638L;
            Console.WriteLine(mylong);
            float myfloat = 3e2F;
            Console.WriteLine(myfloat);
            double mydouble = 4e2D;
            Console.WriteLine(mydouble);
            char mychar = 'A';
            Console.WriteLine(mychar);
            string mystring = "Hello";
            Console.WriteLine(mystring);
        }
    }
}