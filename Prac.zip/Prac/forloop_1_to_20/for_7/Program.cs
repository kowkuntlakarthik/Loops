﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Star pattern");
            int i = 5;
            for (int j = 5; j >= 1; j--)
            {
                for (int k = 1; k <= i; k++)
                {
                    Console.Write("* ");
                }
                i--;
                Console.WriteLine();
            }
        }
    }
}
