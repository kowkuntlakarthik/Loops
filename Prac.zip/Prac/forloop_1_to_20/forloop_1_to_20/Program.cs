﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forloop_1_to_20
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Printing numbers 1 to 2o using for loop");
            int i = 1;
            for (int j = 1; j <= 5; j++)
            {
                for(int k = 1; k <=5; k++)
                {
                    Console.Write(i + " ");
                    i++;
                }
                Console.WriteLine();
            }
        }
    }
}
