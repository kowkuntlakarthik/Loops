﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Numbers");
            for ( int i = 1; i <= 4; i++)
            {
                int j = 2 * i - 1;
                int k = 2 * i;
                for(int l = 1; l <= 4; l++)
                {
                    Console.Write(j + " " + k + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
