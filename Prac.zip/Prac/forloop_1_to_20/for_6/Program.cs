﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Printing Numbers");
            int i = 5;
            for (int j = 0; j <= 4; j++)
            {
                for (int k = 0; k <= j; k++)
                {
                    Console.Write("* ");

                }
                i++;
                Console.WriteLine();
            }
        }
    }
}
