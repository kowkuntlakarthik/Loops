﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Printing numbers");
            int i = 25;
            for(int j = 1; j <= 5; j++)
            {
                for(int k = 1; k <= 5; k++)
                {
                    Console.Write(i + " ");
                    if ( i % 5 == 1)
                    {
                        Console.WriteLine();
                    }
                    i--;
                }
            }
        }
    }
}
