﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Printing numbers");
            int i = 1;
            for ( int j = 0; j <= 4; j++)
            {
                for (int k = 0; k <= 4; k++)
                {
                    Console.Write((i + k) + " ");
                }
                i++;
                Console.WriteLine();
            }
        }
    }
}
