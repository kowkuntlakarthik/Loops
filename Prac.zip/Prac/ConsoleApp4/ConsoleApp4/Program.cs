﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("String length");
            Console.Write("Enter string: ");
            string name = Console.ReadLine();
            /*Console.WriteLine("String lenght: " + name.Length);
            Console.WriteLine("String in upper case: " + name.ToUpper());
            Console.WriteLine("String in Lower case: " + name.ToLower());
            Console.Write("Enter name1: ");
            string name1 = Console.ReadLine();
            /*Console.WriteLine("Enter name2: ");
            Console.WriteLine("Full name: " + name + name1);
            string name2 = name + name1;
            Console.WriteLine("name2: " + name2);
            string name3 = string.Concat(name, name1);
            Console.WriteLine("String.Concat: " + name3);

            Console.WriteLine("String Interpolation");
            string name4 = $"My full name: {name} {name1}";
            Console.WriteLine(name4);*/

            /*Console.WriteLine("String index number: " + name[2]);
            Console.Write("Enter position number: ");
            int mychar = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Char: " + name[mychar]);*/

            /*Console.WriteLine(name.IndexOf("k"));
            Console.Write("Enter char: ");
            char mychar = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("position number of the char: " + name.IndexOf(mychar));*/

            Console.WriteLine("Substring");
            Console.Write("Enter Char: ");
            Char mychar = Convert.ToChar(name.IndexOf(Console.ReadLine()));
            string lname = name.Substring(mychar);
            Console.WriteLine("Last name: " + lname);
            Console.Write("Enter Position number: ");
            int myint = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Last name: " + name.Substring(myint));
            
        }
    }
}
