﻿using System;

namespace methods
{
    class Program
    {
        static void Method()
        {
            Console.WriteLine("using methods");
        }
        static void Method1()
        {
            Console.WriteLine("printing lines to output");
        }
        static void Main()
        {
            Method();
            Method1();
        }
    }
}