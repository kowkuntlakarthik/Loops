﻿using System;

namespace Mrvalues
{
    class Program
    {
        static int Mvalues(int x, int y)
        {
            return x + y;
        }
        static double Mrvalues(double m, double n)
        {
            return m * n;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(Mvalues(5, 5));
            double z = Mrvalues(5.5364, 2.1569);
            Console.WriteLine(z.ToString("00.00"));
        }
        
    }
}