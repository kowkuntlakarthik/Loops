﻿using System;

namespace multipleparameters
{
    class Program
    {
        static void Multiple(string fname, int age)
        {
            Console.WriteLine(fname + " age is " + age);
        }
        static void Main(string[] args)
        {
            Multiple("test1", 1);
            Multiple("test2", 2);
            Multiple("test3", 3);
        }
    }
}