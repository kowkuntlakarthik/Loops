﻿using System;

namespace Multiple_return_values
{
    class Program
    {
        static double Mrvalues(double x, double y)
        {
            Console.WriteLine("Enter value of x: ");
            x = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter value of y: ");
            y = Convert.ToDouble(Console.ReadLine());
            return x + y;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Passing Multiple return");
            double x, y;
            //double z = Mrvalues(5.5, 3.5);
            double z = Mrvalues(x, y);
            Console.WriteLine(z);
        }

    }
}


//doubt//