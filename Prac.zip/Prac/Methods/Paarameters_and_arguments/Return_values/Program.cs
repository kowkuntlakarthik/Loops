﻿using System;

namespace returnvalues
{
    class Program
    {
        static int rvalues(int x)
        {
            return x + 3;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(rvalues(1));
            Console.WriteLine(rvalues(2));
            Console.WriteLine(rvalues(3));
            Console.WriteLine(rvalues(4));
        }
    }
}