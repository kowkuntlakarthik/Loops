﻿//using System;

//namespace namedarguments
//{
//    class Program
//    {
//        static void namedarg(string fname1, string fname2, string fname3)
//        {
//            Console.WriteLine("The youngest child: " + fname3);
//        }
//        static void Main(string[] args)
//        {
//            namedarg(fname1: "test1", fname2: "test2", fname3: "test3");
//        }
//    }
//}

using System;

namespace namedarguments
{
    class Program
    {
        static void arguments(string name1, string name2, string name3)
        {
            Console.WriteLine("Name3: " + name3);
            Console.WriteLine("Name1: " + name1);
            Console.WriteLine("Name2: " + name2);
        }
        static void Main(string[] args)
        {
            arguments(name1: "test1", name2: "test2", name3: "test3");
        }
        
    }
}