﻿using System;

namespace parametersandarguments
{
    class program
    {
        static void method(string fname)
        {
            Console.WriteLine(fname + " test");
        }

        static void Main(string[] args)
        {
            method("c#");
            method("NX");
            method("Customization");
        }
    }
}