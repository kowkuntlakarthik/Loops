﻿using System;

namespace parameter
{
    class Program
    {
        static void dparameter(string fname = "Default_Parameter")
        {
            Console.WriteLine(fname);
        }
        static void Main(String[] args)
        {
            dparameter("test");
            dparameter("test1");
            dparameter();
            dparameter("test2");
        }
    }
}