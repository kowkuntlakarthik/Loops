﻿using System;

namespace methodsoverloading
{
    class Program
    {
        static int plusmethod(int x, int y)
        {
            return x + y;
        }
        static double plusmethod(double x, double y)
        {
            return x + y;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Methods overloading");
            Console.WriteLine("int: " + plusmethod(5, 5));
            Console.WriteLine("double: " + plusmethod(1.2, 1.8));
        }
    }
}