﻿using System;

namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Arrays");
            string[] cars = { "Mercedes", "Benz", "Cars", "Trucks" };
            Console.Write("Enter value: ");
            string name = cars[(Convert.ToInt32(Console.ReadLine()))];
            Console.WriteLine("Brand name: " + name);
        }
    }
}