﻿using System;

namespace Array_Integers
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Integer values");
            int[] values = { 1, 2, 3, 4 };
            Console.Write("Enter position: ");
            int number = values[Convert.ToInt32(Console.ReadLine())];
            Console.WriteLine("Value in the entered position: " + number);
        }
    }
}