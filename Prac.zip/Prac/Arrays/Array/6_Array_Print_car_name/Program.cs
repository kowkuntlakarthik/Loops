﻿using System;

namespace printcarname
{
    class Program
    {
        static void printcarname()
        {
            
            string[] brand = { "Mercedes", "Benz", "Cars", "Vans", "Trucks" };
            Console.Write("Enter brand name: ");
            string name = Console.ReadLine();
            int value = Array.IndexOf(brand, name);
            Console.WriteLine("Brand name: " + value);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Printing car name using index value");
            printcarname();
            printcarname();
            printcarname();
        }
    }
}