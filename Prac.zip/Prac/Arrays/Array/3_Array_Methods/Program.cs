﻿using System;
using System.Security.Cryptography.X509Certificates;

namespace Methods_arrays
{
    class Vehicle  // base class (parent) 
    {
        public string brand = "Ford";  // Vehicle field
        public void honk()             // Vehicle method 
        {
            Console.WriteLine("Tuut, tuut!");
        }
    }

    class vechile1 : Vehicle
    {
        public string brand1 = "Aravind";  // Vehicle field

    }
    class Car : vechile1 // derived class (child)
    {
        public string modelName = "Mustang";  // Car field
    }//Derived Class

    class Program
    {
        static void Main(string[] args)
        {
            // Create a myCar object
            Car myCar = new Car();
            // Vehicle vehicle = new Vehicle();    
            // Call the honk() method (From the Vehicle class) on the myCar object
            // myCar.honk();
            string brandName = myCar.brand;
          string ModelName = myCar.modelName;
            string ModelName1 = myCar.brand1;


            // Display the value of the brand field (from the Vehicle class) and the value of the modelName from the Car class
            Console.WriteLine(myCar.brand + " " + myCar.modelName);
        }
    }
}