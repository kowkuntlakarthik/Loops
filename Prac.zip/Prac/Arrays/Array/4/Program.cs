﻿using System;

namespace arrayM
{
    class Program
    {
        static void Method2()
        {
            Console.WriteLine("car models");
            string[] cars = { "Mercedes", "Benz", "vans", "Trucks" };
            Console.Write("Enter car model: ");
            string name = Console.ReadLine();
            int index = Array.IndexOf(cars, name);
            Console.WriteLine("Brand name: " + index);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Arrays using Methods");

            Method2();
        }
    }
}
