﻿using System;

namespace array_methods
{
    class Program
    {
        static void printcarmodel()
        {
            Console.WriteLine("Printing Brand name");
            string[] brand = { "Mercedes", "Benz", "Vans", "Trucks" };
            Console.Write("Enter index value: ");
            string name = brand[Convert.ToInt32(Console.ReadLine())];
            Console.WriteLine("Brand Name: " + name);
            
        }
        static void printnumber()
        {
            Console.WriteLine("Printing number");
            int[] number = { 1, 2, 3, 4 };
            Console.Write("Enter index value: ");
            int value = number[Convert.ToInt32(Console.ReadLine())];
            Console.WriteLine("Value in the index position: " + value);
        }
        static void Main(string[] args)
        {
            printcarmodel();
            printnumber();

        }
    }
}