﻿using System;

namespace sortarrayint
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number Sort arrays");
            int[] numb = { 9030, 48, 28, 18, 98, 38, 8500 };
            /*for (int i = 0; i < numb.Length; i++)
            {
                Console.WriteLine(numb[i]);
            } */
            Array.Sort(numb);
            foreach (int i in numb)
            {
                Console.WriteLine(i);
            }


        }
    }
}