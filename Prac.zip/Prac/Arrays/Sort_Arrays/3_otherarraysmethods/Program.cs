﻿using System;

namespace otherarraymethods
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Other Array Methods");
            int[] mynumb = { 9030, 48, 28, 18, 98, 38, 8500 };
            Array.Sort(mynumb);
            foreach(int i in mynumb)
            {
                Console.WriteLine(i);
            }
            Console.Write("\nLength of the array: ");
            Console.WriteLine(mynumb.Length);
            Console.Write("Minimum number: ");
            Console.WriteLine(mynumb.Min());
            Console.Write("Maximum number: ");
            Console.WriteLine(mynumb.Max());
            Console.Write("Sum of array numbers: ");
            Console.WriteLine(mynumb.Sum());
        }
    }
}