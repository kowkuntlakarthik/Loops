﻿using System;

namespace sortarrays
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Sort Arrays");
            string[] cars = { "Mercedes", "Benz", "Volvo", "Trucks", "Vans", "Rolls", "Ferrari", "Jaguar" };
            Array.Sort(cars);
            foreach(string s in cars)
            {
                Console.WriteLine(s);
            }
        }
    }
}