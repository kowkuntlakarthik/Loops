﻿using System;

namespace foreachlooparray
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("for each loop through an array");
            string[] brand = { "Mercedes", "Benz", "Vans", "Trucks", "Buses", "Cars", "Jaguar", "Ferrari" };
            foreach (string i in brand)
            {
                Console.WriteLine(i);
            }
        }
    }
}