﻿using System;

namespace loopthroughanarray
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Loops through an Array");
            string[] brand = { "Mercedes", "Benz", "Volvo", "BMW", "Land Rover", "Range Rover", "Jaguar", "Ferrari" };
            for (int i = 0; i < brand.Length; i++)
            {
                Console.WriteLine(brand[i]);
            }
        }
    }
}