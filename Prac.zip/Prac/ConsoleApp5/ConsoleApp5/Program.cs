﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Numbers printing in pattern");
            /*for (int i = 0; i < 5; i++)
            {
                Console.Write(i + " ");
            }
            for (int j = 1; j < 5; j++)
            {
                Console.Write(j + " ");
            }*/
            for (int i = 1; i <= 5; i++)
            {
               for(int j = 1; j <= 5; j = j + 2)
                {
                    Console.Write(j + " ");
                }
                Console.WriteLine();
            }
            
        }
    }
}
