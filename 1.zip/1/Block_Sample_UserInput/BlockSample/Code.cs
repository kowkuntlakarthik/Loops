﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;
using NXOpen.UF;
using NXOpenUI;
using NXOpen.Utilities;
using NXOpen.Features;

namespace BlockSample
{
    internal class Code
    {
        public static double x;
        public static double y;
        public static double z;
        public static double l;
        public static double w;
        public static double h;
        public static int Main(string[] args)
        {

            ValuesInput();
            Code.CodeMethod();
            return 0;

        }

        public static void ValuesInput()
        {
            //Taking origin values from input
            Console.WriteLine("Enter Co-ordinate values: ");
            Console.Write("Enter x Co-ordinate value: ");
            x = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter y Co-ordinate value: ");
            y = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter z Co-ordinate value: ");
            z = Convert.ToDouble(Console.ReadLine());

            //Taking block dimensions from input
            Console.WriteLine("\nEnter block Dimensions");
            Console.Write("Enter Lenght of a block: ");
            l = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Width of a block: ");
            w = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Height of a block: ");
            h = Convert.ToDouble(Console.ReadLine());
        }

        public static void CodeMethod()
        {
            

            NXOpen.Session theSession = NXOpen.Session.GetSession();
            NXOpen.Part workPart = theSession.Parts.Work;
            NXOpen.Part displayPart = theSession.Parts.Display;

            
            NXOpen.Features.Feature nullNXOpen_Features_Feature = null;
            NXOpen.Features.BlockFeatureBuilder blockFeatureBuilder1;
            blockFeatureBuilder1 = workPart.Features.CreateBlockFeatureBuilder(nullNXOpen_Features_Feature);

            ////Taking origin values from input
            //Console.WriteLine("Enter Co-ordinate values: ");
            //Console.Write("Enter x Co-ordinate value: ");
            //double x = Convert.ToDouble(Console.ReadLine());
            //Console.Write("Enter y Co-ordinate value: ");
            //double y = Convert.ToDouble(Console.ReadLine());
            //Console.Write("Enter z Co-ordinate value: ");
            //double z = Convert.ToDouble(Console.ReadLine());

            ////Taking block dimensions from input
            //Console.WriteLine("\nEnter block Dimensions");
            //Console.Write("Enter Lenght of a block: ");
            //double l = Convert.ToDouble(Console.ReadLine());
            //Console.Write("Enter Width of a block: ");
            //double w = Convert.ToDouble(Console.ReadLine());
            //Console.Write("Enter Height of a block: ");
            //double h = Convert.ToDouble(Console.ReadLine());

            
            NXOpen.Point3d originPoint1 = new NXOpen.Point3d(Code.x, Code.y, Code.z);
            blockFeatureBuilder1.SetOriginAndLengths(originPoint1, Code.l.ToString(), Code.w.ToString(), Code.h.ToString());

            NXOpen.Features.Feature feature1;
            feature1 = blockFeatureBuilder1.CommitFeature();

            blockFeatureBuilder1.Destroy();
        }
        
        public static int GetUnloadOption(string arg)
        {
            //return System.Convert.ToInt32(Session.LibraryUnloadOption.Explicitly);
            return System.Convert.ToInt32(Session.LibraryUnloadOption.Immediately);
            // return System.Convert.ToInt32(Session.LibraryUnloadOption.AtTermination);
        }
        
    }
}


    

