﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;
using NXOpen.UF;
using NXOpenUI;
using NXOpen.Utilities;

namespace BlockSample
{
    internal class Code
    {
        public static void CodeMethod()
        {

            NXOpen.Session theSession = NXOpen.Session.GetSession();
            NXOpen.Part workPart = theSession.Parts.Work;
            NXOpen.Part displayPart = theSession.Parts.Display;


            NXOpen.Features.Feature nullNXOpen_Features_Feature = null;
            NXOpen.Features.BlockFeatureBuilder blockFeatureBuilder1;
            blockFeatureBuilder1 = workPart.Features.CreateBlockFeatureBuilder(nullNXOpen_Features_Feature);



            NXOpen.Point3d originPoint1 = new NXOpen.Point3d(0.0, 0.0, 0.0);
            blockFeatureBuilder1.SetOriginAndLengths(originPoint1, "100", "100", "100");

            NXOpen.Features.Feature feature1;
            feature1 = blockFeatureBuilder1.CommitFeature();

            blockFeatureBuilder1.Destroy();
        }
    }
}
