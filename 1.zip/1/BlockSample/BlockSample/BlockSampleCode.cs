﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;
using NXOpen.UF;
using NXOpenUI;
using NXOpen.Utilities;

namespace BlockSample
{
    public class BlockSampleCode
    {
        public static void Main(string[] args)
        {
            Code.CodeMethod();
        }

    }
}
