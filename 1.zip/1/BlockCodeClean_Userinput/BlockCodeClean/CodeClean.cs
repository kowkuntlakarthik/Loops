﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NXOpen;
using NXOpenUI;
using NXOpen.UF;
using NXOpen.Utilities;

namespace BlockCodeClean
{
    public class CodeClean
    {
        public static void Main(string[] args)
        {
            //BlockCode();
            InputValues.UserInputValues();
            
        }

        public static int GetUnloadOption(string arg)
        {
            //return System.Convert.ToInt32(Session.LibraryUnloadOption.Explicitly);
            return System.Convert.ToInt32(Session.LibraryUnloadOption.Immediately);
            // return System.Convert.ToInt32(Session.LibraryUnloadOption.AtTermination);
        }
        //public static void BlockCode()
        //{
            //NXOpen.Session theSession = NXOpen.Session.GetSession();
            //NXOpen.Part workPart = theSession.Parts.Work;
            //NXOpen.Part displayPart = theSession.Parts.Display;


            //NXOpen.Features.Feature nullNXOpen_Features_Feature = null;
            //NXOpen.Features.BlockFeatureBuilder blockFeatureBuilder1;
            //blockFeatureBuilder1 = workPart.Features.CreateBlockFeatureBuilder(nullNXOpen_Features_Feature);



            //NXOpen.Point3d originPoint1 = new NXOpen.Point3d(0.0, 0.0, 0.0);
            //blockFeatureBuilder1.SetOriginAndLengths(originPoint1, "100", "100", "100");

            //NXOpen.Features.Feature feature1;
            //feature1 = blockFeatureBuilder1.CommitFeature();

            //blockFeatureBuilder1.Destroy();
            



        //}
    }
}
